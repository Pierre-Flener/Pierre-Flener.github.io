%******************************************************************************
%*									      *
%*				prettyPrint.pl				      *
%*									      *
%*		Written by: Pierre Flener (24 May 1996)			      *
%*									      *
%******************************************************************************

% ppPgm(LP)
%	Pretty-print logic program LP.

ppPgm(LP) :-
	cutify(LP,CuteLP,_),
	reverse(CuteLP,RevLP),		% clauses are in reverse order
	ppClauses(RevLP).


% cutify(X,CuteX,Subst)
%	CuteX is a copy of term X where the unbound variables are replaced
%	by uppercase alphabetic atoms.  Subst is a list of (Name=Var) pairs,
%	where Var is a variable of X (as they appear first from left to
%	right in X) and Name is the alphabetic atom it was replaced with.
% Restriction: X may not contain more than 52 distinct variables.

cutify(X,CuteX,Subst) :-
	vars(X,VarsX),
	copy_term(X,CuteX),
	vars(CuteX,VarsCuteX),
	rename(VarsCuteX,VarsX,Subst,
		['A','B','C','D','E','F','G','H','I','J','K','L','M',
		 'N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
		 'AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ',
		 'AK','AL','AM','AN','AO','AP','AQ','AR','AS','AT',
		 'AU','AV','AW','AX','AY','AZ']).


% rename(CopyA,A,Subst,B)
%	Replace all the variables of list CopyA by terms drawn from list B.
%	Subst is a list of (Name=Var) pairs, where Var is the variable of A
%	at the same position as the variable in CopyA that was replaced by
%	aterm from B.

rename([],[],[],_).
rename([V1|Vars1],[V2|Vars2],Subst,[T|Terms]) :-
	V1=T,!,
	Subst=[(T=V2)|TSubst],
	rename(Vars1,Vars2,TSubst,Terms).
rename([_|Vars1],[_|Vars2],Subst,[T|Terms]) :-
  % i.e.V1~=T,
	rename(Vars1,Vars2,Subst,[T|Terms]).


% ppClauses(Clauses)
%	Pretty-print the clause list Clauses.

ppClauses([]).
ppClauses([Clause|Clauses]) :-
	Clause=if(Head,Body),
	tab(3),print(Head),
	(Body=true -> true ; write(' <-- ')),
	ppConj(Body),nl,
	ppClauses(Clauses).


% ppConj(Conj)
%	Pretty-print the (possibly flat) conjunction Conj.

ppConj(true) :- !.
ppConj(and(Conj1,Conj2)) :-
	!,ppConj(Conj1),write(','),
	ppConj(Conj2).
ppConj(neg(Atom)) :-			% it's a negative atom
	!,write('~'),print(Atom).
ppConj(Atom) :-				% it's a positive atom
	print(Atom).


% ppTuple(Tuple)
%	Pretty-print the terms of the list Tuple as a tuple between < and >.

ppTuple(Tuple) :-
	write('<'),
	ppTuple2(Tuple),
	write('>').


% ppTuple2(Tuple)
%	Pretty-print the terms of the list Tuple as a tuple without < and >.

ppTuple2([]).
ppTuple2([Term]) :-
	!,print(Term).
ppTuple2([Term1,Term2|Tuple]) :-
	print(Term1),write(','),
	ppTuple2([Term2|Tuple]).


% ppList(Terms)
%	Pretty-print the term list Terms, one term per line.

ppList([]).
ppList([Term|Terms]) :-
	print(Term),nl,
	ppList(Terms).


% ppDecl(Pred,ParamTypes)
%	Pretty-print Pred and the name:type declaration-list ParamTypes.

ppDecl(Pred,ParamTypes) :-
	tab(3),write(Pred),write('('),ppPTs(ParamTypes),write(')'),nl.

ppPTs([]).
ppPTs([Name:Type]) :-
	!,writeString(Name),write(':'),write(Type).
ppPTs([Name1:Type1,Name2:Type2|ParamTypes]) :-
	writeString(Name1),write(':'),write(Type1),write(','),
	ppPTs([Name2:Type2|ParamTypes]).


% Hook for printing out ground Peano-numbers as natural numbers (for print/1).
%
%portray(s(P)) :-
%	ground(P),
%	peano2Nat(s(P),N),
%	write(N).

% Hook for printing out second-order atoms w/0 the $atom functor (for print/1).

portray('$atom'(Atom)) :-
	print(Atom).
