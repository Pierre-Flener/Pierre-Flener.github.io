%******************************************************************************
%*									      *
%*				 phase1.pl				      *
%*									      *
%*		 Written by: Pierre Flener (14 June 1996)		      *
%*		With: Halime Buyukyildiz and Serap Yilmaz		      *
%*									      *
%******************************************************************************

:- dynamic ip/2.
:- dynamic rp/2.
:- dynamic ap/2.
:- dynamic di/2.

% phase1(Pred,ParamTypes,Hints,Info,SOclauses)
%	SOclauses is a second-order logic program for predicate Pred, whose
%	parameter name:type pairs are ParamTypes.  Hints contains preferences
%	for the parameter roles and the DecR instance of CurrPred.
%	Info contains information about the actual decisions of this phase.
%	Remark: this is hardwired for the divide-and-conquer template!

phase1(Pred,ParamTypes,Hints,Info,SOclauses) :-
	selectParamRoles(Pred,ParamTypes,Hints,IPpos,RPposs,APposs,Y,Z),
	Arity is 1 + Y + Z,
	(length(ParamTypes,A), A ~= Arity -> fail;
	       (selectDecR(Pred,IPpos,Hints,DecRinfo,HX,T),
	        Info=info(IPpos,RPposs,APposs,DecRinfo,Arity,_,_,
	                  formVars(Y,Z,HX,T)),
	        instTemplate(Pred,Info,SOclauses))).


% selectParamRoles(ParamTypes,Hints,IPinfo,RPinfos,APinfos,Y,Z)

selectParamRoles(Pred,ParamTypes,hints(IPname,RPnames,APnames,_),
			IPinfo,RPinfos,APinfos,Y,Z) :- !,
	getIPinfo(Pred,ParamTypes,IPname,IPinfo),
	getRPinfos(Pred,ParamTypes,IPinfo,RPnames,RPinfos,Y),
	getAPinfos(Pred,ParamTypes,IPinfo,RPinfos,APnames,APinfos,Z).
selectParamRoles(Pred,ParamTypes,_,IPinfo,RPinfos,APinfos,Y,Z) :-
	getIPinfo(Pred,ParamTypes,"",IPinfo),
	getRPinfos(Pred,ParamTypes,IPinfo,[],RPinfos,Y),
	getAPinfos(Pred,ParamTypes,IPinfo,RPinfos,[],APinfos,Z).


% getIPinfo(Pred,ParamTypes,HIPname,IPinfo)

getIPinfo(Pred,ParamTypes,HIPname,IPinfo) :-
	selectIPdefaults(ParamTypes,HIPname,IPDefaults),
 	asksIP('Induction Parameter?',IPDefaults,IPDefaults,
	       Pred,ParamTypes,IPinfo).


% selectIPdefaults(ParamTypes,HIPname,IPDefaults)

selectIPdefaults(ParamTypes,[],IPdefaults):-
	selectauxIPdefaults(ParamTypes,[],IPdefaults).

selectIPdefaults(ParamTypes,HIPname,[HIPname|TIPdefaults]):-
	HIPname ~= [],
	selectauxIPdefaults(ParamTypes,HIPname,TIPdefaults).

selectauxIPdefaults([],_,[]).

selectauxIPdefaults([Name:_|TParamTypes],Name,IPDefaults):-
	selectauxIPdefaults(TParamTypes,Name,IPDefaults).
	
selectauxIPdefaults([Name:Type|TParamTypes],HIPname,[Name|TIPDefaults]) :-
	 Name ~= HIPname,
	 inductivetype(Type),
	 selectauxIPdefaults(TParamTypes,HIPname,TIPDefaults).

selectauxIPdefaults([Name:Type|TParamTypes],HIPname,IPDefaults) :-
	HIPname ~= Name, 
	\+(inductivetype(Type)),
	selectauxIPdefaults(TParamTypes,HIPname,IPDefaults).

inductivetype(Type):-
	(Type = list(_);
	 Type = nat;
	 Type = int).

% asksIP(Question,AllIPDefaults,IPDefaults,Pred,ParamTypes,IPinfo)

asksIP(Question,AllIPDefaults,IPDefaults,Pred,ParamTypes,IPinfo) :-
	IPDefaults = [Default|_],
	ask(Question,Default,AnswerStr),
	(AnswerStr = "back" -> !, fail;
				(myPhrase(variable(IPname), AnswerStr),
				 memberCheck(AllIPDefaults,IPname) ->
					(assert(ip(Pred,IPname)),
					 constructIPinfo(ParamTypes,IPname,
					                IPinfo));
					asksIP(Question,AllIPDefaults,
					  IPDefaults,Pred,ParamTypes,IPinfo))).
asksIP(Question,AllIPDefaults,IPDefaults,Pred,ParamTypes,IPinfo) :- 
	retract(ip(Pred,IPname)),
	mefface(IPname,IPDefaults,NewIPDefaults),
	asksIP(Question,AllIPDefaults,NewIPDefaults,Pred,ParamTypes,IPinfo).

%mefface(E,L,R) R is list L without its first, existing occurrence of term E,
% if E not exists then R is list L.

mefface(_,[],[]).
mefface(E,[E|R],R).
mefface(E,[HL|TL],[HL|TR]) :-
 	E~=HL,
	mefface(E,TL,TR).

% constructIPinfo(ParamTypes,IPname,IPinfo)

constructIPinfo(ParamTypes,IPname,IPinfo) :-
	constructauxIPinfo(ParamTypes,IPname,1,IPinfo).

% constructauxIPinfo(ParamTypes,IPname,N,IPinfo)

constructauxIPinfo([IPname:Type|_],IPname,N,pi(N,IPname,Type)).
constructauxIPinfo([Name:_|TParamTypes],IPname,N,IPinfo) :-
	Name ~= IPname,
	N1 is N+1,
	constructauxIPinfo(TParamTypes,IPname,N1,IPinfo).


% getRPinfos(Pred,ParamTypes,IPinfo,HRPnames,RPinfos,Y)
% getRPinfos(s,["L":list(int),"S":list(int)],pi(1,"L",list(int)),[],RPinfos,Y).

getRPinfos(Pred,ParamTypes,IPinfo,HRPnames,RPinfos,Y) :-
	check_selectRPdefaults(ParamTypes,IPinfo,HRPnames,RPDefaults),
	(RPDefaults =[] -> (RPinfos =[], Y=0);
	    asksRP('Result Parameter(s)?',RPDefaults,RPDefaults,Pred,
			ParamTypes,RPinfos,Y)).
		

% check_selectRPdefaults(Pred,ParamTypes,IPinfo,HRPnames,RPDefaults)

check_selectRPdefaults(ParamTypes,pi(N,IPname,_),HRPnames,RPDefaults) :-
	((HRPnames = [HH], HH = IPname)-> NHRPnames = [];
	                       NHRPnames = HRPnames),
	selectRPparams(ParamTypes,N,LRPs),
	mpowerset(LRPs,TRPDefaults),
	(NHRPnames ~= [] -> puthintP(NHRPnames,TRPDefaults,RPDefaults);
		       	RPDefaults = TRPDefaults).


% selectRPparams(ParamTypes,N,LRPs)

selectRPparams([],_,[]).
selectRPparams([_:_|TPT],1,LRPs) :-
	selectRPparams(TPT,0,LRPs).
selectRPparams([Name:Type|TPT],N,LRPs) :-
	N ~= 1,
	N1 is N-1,
	(inductivetype(Type)-> LRPs = [Name|TLRPs];
	                      LRPs = TLRPs),
	selectRPparams(TPT,N1,TLRPs).

% constructRPinfos(ParamTypes,RPnames,RPinfos,Y1,Y)

constructRPinfos(_,[],[],Y,Y).
constructRPinfos(ParamTypes,[HRPname|TRPnames],[HRPinfo|TRPinfos],Y1,Y):-
	constructauxRPinfo(ParamTypes,HRPname,1,HRPinfo),
	NY1 is Y1+1,
	constructRPinfos(ParamTypes,TRPnames,TRPinfos,NY1,Y).


% constructauxRPinfo(ParamTypes,RPname,N,RPinfo)

constructauxRPinfo([RPname:Type|_],RPname,N,pi(N,RPname,Type)).
constructauxRPinfo([Name:_|TParamTypes],RPname,N,RPinfo):-
	Name ~= RPname,
	N1 is N+1,
	constructauxRPinfo(TParamTypes,RPname,N1,RPinfo).


% asksRP(Question,AllRPDefaults,RPDefaults,Pred,ParamTypes,RPinfos,Y)


asksRP(Question,AllRPDefaults,RPDefaults,Pred,ParamTypes,RPinfos,Y) :-
	RPDefaults = [Default|_],
        convertdef(Default,DefaultStr),
	ask(Question,DefaultStr,AnswerStr),
	(AnswerStr = "back" -> !, fail;
		      myPhrase(variablesList(RPnames), AnswerStr),
		      (RPnames =[] -> RPinfos =[], Y = 0 ;
				 (memberPCheck(AllRPDefaults,RPnames) ->
					(
					 assert(rp(Pred,RPnames)),
					 constructRPinfos(ParamTypes,RPnames,
					             RPinfos,0,Y));
					asksRP(Question,AllRPDefaults,
				   RPDefaults,Pred,ParamTypes,RPinfos,Y)))).
asksRP(Question,AllRPDefaults,RPDefaults,Pred,ParamTypes,RPinfos,Y) :- 
	(rp(Pred,ORPnames) ->
	    (retract(rp(Pred,ORPnames)),
	     effaceP(ORPnames,RPDefaults,NewRPDefaults));
	     NewRPDefaults = RPDefaults),  
	(NewRPDefaults ~= [] ->     
	     asksRP(Question,AllRPDefaults,NewRPDefaults,Pred,
		        ParamTypes,RPinfos,Y)).

% getAPinfos(Pred,ParamTypes,IPinfo,RPinfos,HAPnames,APinfos,Z)

% getAPinfos(d,["L":list(int),"S":list(int),"A1":int,"A2":list(int)],
%pi(1,"L",list(int)),[pi(2,"S",list(int))],[],AP,Z).

getAPinfos(Pred,ParamTypes,IPinfo,RPinfos,HAPnames,APinfos,Z) :-
	getIRPnames(IPinfo,RPinfos,IRPnames),
	selectAPdefaults(ParamTypes,IRPnames,HAPnames,APDefaults),
	(APDefaults = [] -> (APinfos=[],Z=0);
			(asksAP('Auxiliary Parameter(s)?',APDefaults,
			         APDefaults,Pred,ParamTypes,APinfos,Z))).

% getIRPnames(IPinfo,RPinfos,IRPnames)

getIRPnames(pi(_,Name,_),RPinfos,[Name|RPnames]) :-
	getRPnames(RPinfos,RPnames).
 
getRPnames([],[]).
getRPnames([pi(_,Name,_)|TRPinfos],[Name|TRPnames]) :-
	getRPnames(TRPinfos,TRPnames).


% selectAPdefaults(ParamTypes,IRPnames,HAPnames,APDefaults)

selectAPdefaults(ParamTypes,IRPnames,HAPnames,APDefaults) :-
	(HAPnames = [HH] ->
        (memberPCheck(IRPnames,HH) -> NHAPnames = [] ;
	                         NHAPnames = HAPnames);
        (memberPCheck(IRPnames,HAPnames) -> NHAPnames = [] ;
	                         NHAPnames = HAPnames)),
	selectAPparams(ParamTypes,IRPnames,LAPs),
	mpowerset(LAPs,TAPDefaults),
	(NHAPnames ~= [] -> puthintP(NHAPnames,TAPDefaults,APDefaults);
			APDefaults = TAPDefaults).


% selectAPparams(ParamTypes,IRPnames,LAPs)

selectAPparams([],_,[]).
selectAPparams([Name:_|TPT],IRPnames,LAPs) :-
	memberCheck(IRPnames,Name),
	selectAPparams(TPT,IRPnames,LAPs).
selectAPparams([Name:_|TPT],IRPnames,[Name|TLAPs]) :-
	\+(memberCheck(IRPnames,Name)),
	selectAPparams(TPT,IRPnames,TLAPs).


% constructAPinfos(ParamTypes,APnames,APinfos,Z1,Z)

constructAPinfos(_,[],[],Z,Z).
constructAPinfos(ParamTypes,[HAPname|TAPnames],[HAPinfo|TAPinfos],Z1,Z) :-
	constructauxAPinfo(ParamTypes,HAPname,1,HAPinfo),
	NZ1 is Z1+1,
	constructAPinfos(ParamTypes,TAPnames,TAPinfos,NZ1,Z).


% constructauxAPinfo(ParamTypes,APname,N,APinfo)

constructauxAPinfo([APname:Type|_],APname,N,pi(N,APname,Type)).
constructauxAPinfo([Name:_|TParamTypes],APname,N,APinfo) :-
	Name ~= APname,
	N1 is N+1,
	constructauxAPinfo(TParamTypes,APname,N1,APinfo).


% asksAP(Question,AllAPDefaults, APDefaults,Pred,ParamTypes,APinfos,Z)

asksAP(Question,AllAPDefaults, APDefaults,Pred,ParamTypes,APinfos,Z) :-
	APDefaults = [Default|_],
	convertdef(Default,DefaultStr),
	ask(Question,DefaultStr,AnswerStr),
	(AnswerStr = "back" -> !, fail;
			myPhrase(variablesList(APnames), AnswerStr),
			(APnames=[] -> APinfos =[],Z=0;
			         (memberPCheck(AllAPDefaults,APnames) -> 
				        (
					 assert(ap(Pred,APnames)),
					 constructAPinfos(ParamTypes,APnames,
					             APinfos,0,Z));
					asksAP(Question,AllAPDefaults,
				   APDefaults,Pred,ParamTypes,APinfos,Z)))).

asksAP(Question,AllAPDefaults, APDefaults,Pred,ParamTypes,APinfos,Z):-
	(ap(Pred,APnames)->
	    (retract(ap(Pred,APnames)),
	     effaceP(APnames,APDefaults,NewAPDefaults));
	     NewAPDefaults = APDefaults),
	(NewAPDefaults ~= [] ->     
	         asksAP(Question,AllAPDefaults,NewAPDefaults,
		                               Pred,ParamTypes,APinfos,Z)).


% convertdef(Default,DefaultStr)

convertdef(Default,DefaultStr):-
	convertdefaux(Default,TDefaultStr),
	NTDefaultStr = [91|TDefaultStr],
	append(NTDefaultStr,"]",DefaultStr).

convertdefaux([HD],HD) :- !.
convertdefaux([HD|TD],DefaultStr) :-
	convertdefaux(TD,TDStr),
	append(",",TDStr,NTDStr),
	append(HD,NTDStr,DefaultStr).


% puthintP(Hint,Defaults,[hint|TNDefaults])

puthintP(Hint,Defaults,[Hint|TNDefaults]) :-
	effaceP(Hint,Defaults,TNDefaults).


% effaceP(PN,Tdefaults,TNDefaults)

effaceP(_,[],[]).
effaceP(PN,[N|Tdefaults],TNDefaults) :-
	eqPL(PN,N),
	effaceP(PN,Tdefaults,TNDefaults).
effaceP(PN,[N|Tdefaults],[N|TNDefaults]) :-
	\+(eqPL(PN,N)),
	effaceP(PN,Tdefaults,TNDefaults).


% eqPL(LN1,LN2)

eqPL([],[]).
eqPL(LN1,LN2):-
	LN1 = [_|TN1],
	TN1 = [],
	LN1 = LN2.
eqPL([Name|TN1],LN2) :-
	TN1 ~= [],
	efface(Name,LN2,RLN2),
	eqPL(TN1,RLN2).

% memberPCheck(NDefaults,Pnames)


memberPCheck([HL|_],PN) :-
	eqPL(HL,PN).
memberPCheck([HL|TL],PN) :-
	\+(eqPL(HL,PN)),
	memberPCheck(TL,PN).


% mpowerset(As,Ss) iff Ss denotes all subsets of As
% where As is a list and Ss is a list of lists of elements occuring in As.

mpowerset(As,Ss) :-
	findall(S,(msubset(S,As), S \== []),RSs),
	reverse(RSs,Ss).
	

% subset(S,As) iff S is a subset of As
% where As and S are lists.

msubset([],[]).
msubset(S,[H|T]) :-
	S=[H|V],
	msubset(V,T).
msubset(S,[_|T]) :-
	msubset(S,T).


%******************************************************
%   Predicates related to SelectDecR
%******************************************************

% selectDecR(Pred,IPinfo,Hints,DecRinfo,HX,T)

selectDecR(Pred,pi(N,IPname,Type),hints(IPname,_,_,HDecR),DecRinfo,HX,T) :-
	HDecR ~= [],
	check_selectDecRdefaults(pi(N,IPname,Type),HDecR,DecRDefaults),
	asksDecR('Decomposition Operator?',DecRDefaults,
	          Pred,pi(N,IPname,Type),DecRinfo,HX,T).

selectDecR(Pred,IPinfo,_,DecRinfo,HX,T) :-
	check_selectDecRdefaults(IPinfo,true,DecRDefaults),
	asksDecR('Decomposition Operator?',DecRDefaults,
	               Pred,IPinfo,DecRinfo,HX,T).

% checkeqDecR(DecR1,DecR2,Args1,Arg2) holds iff DecR2 is a variant
%	of DecR1 where both are conjunctions and their variables
%	are instantiated to alphabetic atoms and Args are the arguments of
%	DecR1 and DecR2 respectively.
%	mode(+,+,?,?)
%	checkeqDecR(and(headtail('Ayse',['Naber'],'iyilik'),
%	partition('iyilik','Naber','optum','bye')),
%	and(headtail('L',['HL'],'TL'),partition('TL','HL','TL1','TL2')),L1,L2).

checkeqDecR(true,true,[],[]) :-!.
checkeqDecR(Literal1,Literal2,Arglist1,Arglist2) :-
	functor(Literal1,F1,N1),
	F1\=and,!,
	functor(Literal2,F2,N2),
	F2=F1,
	N1=N2,
	constituents2(Literal1,Arglist1),
	constituents2(Literal2,Arglist2),
	checkeqArgs(Arglist1,Arglist2).
checkeqDecR(and(Conj11,Conj12),and(Conj21,Conj22),Arglist1,Arglist2) :-
	checkeqDecR(Conj11,Conj21,Arglist11,Arglist21),
	checkeqDecR(Conj12,Conj22,Arglist12,Arglist22),
	append(Arglist11,Arglist12,Arglist1),
	append(Arglist21,Arglist22,Arglist2),
	checkeqArgs(Arglist1,Arglist2).


% checkeqArgs(Args1,Args2) holds iff elements of list Args1 is
%	a variant of list Args2.
%	mode(+,+)

checkeqArgs([],[]).
checkeqArgs([Arg1|RestArgs1],[Arg2|RestArgs2]) :-
	positions(Arg1,RestArgs1,Ps),
	positions(Arg2,RestArgs2,Ps),
	checkeqArgs(RestArgs1,RestArgs2).

%check_selectDecRdefaults(IPinfo,HDecR,DecRDefaults)

check_selectDecRdefaults(pi(_,IPname,Type),HDecR,DecRDefaults) :-
	finddefaultDecR(Type,TDecRDefaults),
	name(Name,IPname),
	changeDecRDefaults(Name,TDecRDefaults,DecRDefaults),
        (HDecR ~= true -> puthintDecR(HDecR,PDecRDefaults,DecRDefaults);
	                  DecRDefaults = PDecRDefaults).

% changeDecRDefaults(Name,TDecRDefaults,DecRDefaults)

changeDecRDefaults(_,[],[]).
changeDecRDefaults(Name,[decRdef(Def,IP)|TDecRDefaults],
			[decRdef(Def1,Name)|TDecRDefaults1]) :-
	changeName(Name,Def,Def1,IP),
	changeDecRDefaults(Name,TDecRDefaults,TDecRDefaults1).



changeName(_,true,true,_).
changeName(Name,Literal1,Literal2,IP) :-
	Literal1 =.. [F1|_],
	F1 ~= and,
	changeNameL(Name,Literal1,Literal2,IP).

changeName(Name,and(Conj1,Conj2),ConjR,IP) :-
	changeName(Name,Conj1,ConjR1,IP),
	changeName(Name,Conj2,ConjR2,IP),
	ConjR = and(ConjR1,ConjR2).

changeNameL(Name,Literal1,Literal2,IP) :-
	Literal1 =.. [F1|Args1],
	changeNameaux(Name,Args1,Args2,IP),
	Literal2 =.. [F1|Args2].

changeNameaux(_,[],[],_).

changeNameaux(Name,[HA1|TA1],[HA2|TA2],IP) :-
	atomic(HA1), HA1 ~= [],!,
	changeIP(Name,IP,HA1,HA2),
	changeNameaux(Name,TA1,TA2,IP).
changeNameaux(Name,[HA1|TA1],[HA2|TA2],IP) :-
	\+(atomic(HA1)),
	functor(HA1,_,N), N>0,!,
	changeName(Name,HA1,HA2,IP),
	changeNameaux(Name,TA1,TA2,IP).
changeNameaux(Name,[HA1|TA1],[HA2|TA2],IP) :-
	list(HA1),
	changeNameaux(Name,HA1,HA2,IP),
	changeNameaux(Name,TA1,TA2,IP).

changeIP(Name,IP,HA1,HA2):-
	name(Name,Nname),
	name(IP,[Ipname]),
	name(HA1,SHA1),
	changeinlist(SHA1,Ipname,Nname,SHA2),
	name(HA2,SHA2).

%changeinlist("HL1",'L',"List",HList1").
changeinlist([],_,_,[]).
changeinlist([H1|T1],H,NH,L2):-
	H1 = H,
	changeinlist(T1,H,NH,T2),
	append(NH,T2,L2).
changeinlist([H1|T1],H,NH,[H1|T2]):-
	H1 ~= H,
	changeinlist(T1,H,NH,T2).

%asksDecR(Question,AllDecRDefaults,DecRDefaults,Pred,IPinfo,DecRinfo,HX,T) 

asksDecR(Question,DecRDefaults,Pred,IPinfo,DecRinfo,HX,T) :-
	(DecRDefaults ~=[] -> 
	     (DecRDefaults=[decRdef(Default,_)|_],
	      convertdefDecR(Default,DefaultStr));
		   DefaultStr = []),
	 ask(Question,DefaultStr,AnswerStr), 
	 (AnswerStr = "back" -> !, DecRinfo = AnswerStr, fail;
	      (myPhrase(fconjunction(DecR),AnswerStr),
	       constructDecRinfo(IPinfo,DecR,DecRinfo,HX,T),
	       IPinfo = pi(_,IP,_),
	       name(IPname,IP),
	       DecRdef = decRdef(DecR,IPname),
	       assert(di(Pred,DecRdef)))).

asksDecR(Question,DecRDefaults,Pred,IPinfo,DecRinfo,HX,T) :- 
	 retract(di(Pred,ODecRdef)),
   	 effaceDecR(ODecRdef,DecRDefaults,NewDecRDefaults),
         asksDecR(Question,NewDecRDefaults,Pred,IPinfo,DecRinfo,HX,T).


%constructDecRinfo(IPinfo,DecR,DecRinfo,HX,T)

constructDecRinfo(IPinfo,DecR,decRinfo(NDecR,HLs,TLs),HX,T):-
	constructauxDecRinfo(IPinfo,DecR,decRinfo(NDecR,HLs,TLs)),
	length(HLs,HX),
	length(TLs,T).


%constructauxDecRinfo(IPinfo,DecR,decRinfo(NDecR,HLs,TLs))

constructauxDecRinfo(pi(_,Name,Type),DecR,DecRinfo):-
	name(NName,Name),
	checkName(NName,DecR),
	getHTs(Name,DecR,SHLs,STLs),
	checkinHs(Name,SHLs,NSHLs),
	checkinTs(Name,STLs,NSTLs),
	headType(pi(_,Name,Type),HType),
	Types = types(HType,Type),
	varDecRinfo(DecR,NSHLs,NSTLs,Types,DecRinfo).

checkinHs(Name,SLs,NSLs):-
	length(SLs,L), L < 2 -> NSLs = SLs ;
	              checkinHsaux(Name,SLs,NSLs).

checkinTs(Name,SLs,NSLs):-
	length(SLs,L), L < 2 -> NSLs = SLs ;
	              checkinTsaux(Name,SLs,NSLs).

checkinHsaux(Name,[H1|T1],L2):-
	H1 = [72|Name] -> L2 = T1;
	                  L2 = [H1|T1].
checkinTsaux(Name,[H1|T1],L2):-
	H1 = [84|Name] -> L2 = T1;
	                  L2 = [H1|T1].

headType(pi(_,_,list(T)),T):-!.
headType(pi(_,_,Type),T):- T=Type.	

checkName(Name,Literal):-
	Literal =.. [Pred|TLArgs],
	Pred ~= and,
	findArgs(TLArgs, LArgs),
	memberCheck(LArgs,Name).
checkName(Name,and(Conj1,Conj2)):-
	(\+checkName(Name,Conj1)) ->
	    checkName(Name,Conj2); 
	            true.

varDecRinfo(DecR,SHLs,STLs,types(HType,TType),decRinfo(VDecR,HInfos,TInfos)):-
	varArgs(SHLs,HLs,HType,HInfos),
	varArgs(STLs,TLs,TType,TInfos),
	varDecR(SHLs,HLs,DecR,TVDecR),
	varDecR(STLs,TLs,TVDecR,VDecR).

varArgs([],[],_,[]).
varArgs([H1|T1],[H2|T2],Type,[HI|TI]):-
	var(H2),
	HI = pi(H2,H1,Type),
	varArgs(T1,T2,Type,TI).

varDecR([],[],NDecR,NDecR).
varDecR([SH|ST],[VH|VT],DecR,VDecR):-
	name(H,SH),
	varauxDecR(DecR,TDecR,H,VH),
	varDecR(ST,VT,TDecR,VDecR).

%varauxDecR(true,true,_,_).
varauxDecR(Literal,NLiteral,H,VH):-
	functor(Literal,_,0),
	H = Literal,
	NLiteral = VH.

varauxDecR(Literal,NLiteral,H,_):-
	functor(Literal,_,0),
	H ~= Literal,
	NLiteral = Literal.

varauxDecR(Literal,NLiteral,H,VH):-
	functor(Literal,Pred,N), N > 0,
	Pred ~= and,
	Literal =.. [Pred|Args],
	varauxDecR1(Args,NArgs,H,VH),
	NLiteral =.. [Pred|NArgs].

varauxDecR(and(Conj1,Conj2),and(NConj1,NConj2),H,VH):-
	varauxDecR(Conj1,NConj1,H,VH),
	varauxDecR(Conj2,NConj2,H,VH).

varauxDecR1([],[],_,_).
varauxDecR1([H1|T1],[H2|T2],H,VH):-
	(\+var(H1), H1 ~=[] ->
	    varauxDecR(H1,H2,H,VH) ;
	    H2 = H1),
	varauxDecR1(T1,T2,H,VH).

%getHTs("L",moto('L','HL','TL'),["HL"],["TL"]).

getHTs(_,true,[],[]).

getHTs(Name,Literal,SHLs,STLs) :-
	Literal =.. [Pred|TLArgs], 
	Pred ~= and,
	findArgs(TLArgs,LArgs),
	stringArgs(LArgs,SLArgs),
	checkHs(Name,SLArgs,USHLs),
	checkTs(Name,SLArgs,USTLs),
	sort(USHLs,SHLs),
	sort(USTLs,STLs).

getHTs(Name,and(Conj1,Conj2),SHLs,STLs) :-
	getHTs(Name,Conj1,SHL1s,STL1s),
	getHTs(Name,Conj2,SHL2s,STL2s),
	append(SHL1s,SHL2s,USHLs),
	sort(USHLs,SHLs),
	append(STL1s,STL2s,USTLs),
	sort(USTLs,STLs).

findArgs([],[]).
findArgs([H1|T1],LArgs):-
	  functor(H1,_,0), 
          LArgs = [H1|TLArgs],
	  findArgs(T1,TLArgs).

findArgs([H1|T1],LArgs):-
	functor(H1,P,N), N ~= 0,
	  H1 =.. [P|H1Args],
	  findArgs(H1Args,TH1Args),
	  findArgs(T1,TLArgs),
	  append(TH1Args,TLArgs,LArgs).

stringArgs([],[]).
stringArgs([H|T],[HS|TS]):-
	name(H,HS),
	stringArgs(T,TS).

checkHs(_,[],[]).
checkHs(Name,[HSArg|TSArgs],[HSArg|TSHLs]):-
	eqbegin(HSArg,[72|Name]),!,
	checkHs(Name,TSArgs,TSHLs).

checkHs(Name,[_|TSArgs],SHLs):-
	checkHs(Name,TSArgs,SHLs).	

checkTs(_,[],[]).
checkTs(Name,[HSArg|TSArgs],[HSArg|TSTLs]):-
	eqbegin(HSArg,[84|Name]),!,
	checkTs(Name,TSArgs,TSTLs).
checkTs(Name,[_|TSArgs],STLs):-
	checkTs(Name,TSArgs,STLs).	

eqbegin(_,[]).
eqbegin([H1|T1],[H1|T2]):-
	eqbegin(T1,T2).


% effaceDecR(DecRinfo,NDecRDefaults,NewDecRDefaults)

effaceDecR(_,[],[]).
effaceDecR(DecRinfo,[Def|TNDefaults],NDefaults) :-
	DecRinfo=decRdef(DecR,_),
	Def=decRdef(DDecR,_),
	cutify(DecR,CutDecR,_),
	cutify(DDecR,CutDDecR,_),
	checkeqDecR(CutDecR,CutDDecR,_,_),!,
	effaceDecR(DecRinfo,TNDefaults,NDefaults).
effaceDecR(DecRinfo,[Def|TNDefaults],[Def|TNNDefaults]) :-
	effaceDecR(DecRinfo,TNDefaults,TNNDefaults).


% puthintDecR(HDecR,DecRDefaults,NDecRDefaults)

 puthintDecR(HDecR,DecRDefaults,NDecRDefaults) :-
	effacehintDecR(HDecR,DecRDefaults,RDecRDefaults,DecRinfo),
 	NDecRDefaults=[DecRinfo|RDecRDefaults].
	
effacehintDecR(HdecR,DecRDefaults,RDecRDefaults,DecRinfo) :-
	memberDecRCheck(DecRDefaults,HdecR,DecRinfo),
	effaceDecR(DecRinfo,DecRDefaults,RDecRDefaults).

	
% finddefaultDecR(Type,DecRDefaults)

finddefaultDecR(Type,DecRDefaults) :-
	(bagof(decRdef(DecR,IP),Type^decPrim(DecR,Type,
				IP),DecRDefaults);
	DecRDefaults = []).


% convertdefDecR(Default,DefaultStr).

convertdefDecR(Literal,DefaultStr) :-
	nameDecr(Literal,DefaultStr).

nameDecr(true,"true").
nameDecr(CuteL,DefaultStr) :-	
	functor(CuteL,F,_),
	F ~= and,
	nameDecRL(CuteL,DefaultStr).

nameDecr(and(Conj1,Conj2),DefaultStr):-
	nameDecr(Conj1,Conj1Str),
	(Conj2 ~= true -> (nameDecr(Conj2,Conj2Str),
				append(",",Conj2Str,TempConj2Str),
				append(Conj1Str,TempConj2Str,DefaultStr));
			DefaultStr = Conj1Str).

nameDecRL(CuteL,DefaultStr):-
	functor(CuteL,F,N),
	(F = headtail -> 
		(CuteL =.. [F|Args],
		Args=[A1,A2,A3],
		name(A1,A1Str),
		namelist(A2,A2Str),
		name(A3,A3Str),
		append(A1Str,"=[",T1),
		append(A2Str,"|",T2),
		append(T1,T2,T3),
		append(A3Str,"]",T4),
		append(T3,T4,DefaultStr));
		(name(F,FStr),
		argstring(CuteL,N,1,ArgStr),
		(infunct2(F) -> (CuteL =.. [F|Args],
		                 Args = [A1,A2],
				 nameS(A1,AS1),
				 nameS(A2,AS2),
		                 append(AS1,FStr,FTStr),
				 append(FTStr,AS2,DefaultStr));
		               ( 
                                argstring(CuteL,N,1,ArgStr),
				append(FStr,"(",FTStr),
		                append(ArgStr,")",ATStr),
		                append(FTStr,ATStr,DefaultStr))))).
infunct2(F) :- F='=';
	      F='\=';
	      F='~=';
	      F='=/='.

namelist([],[]).
namelist([H],Str) :- !, 
	name(H,Str).
namelist([H|TL],Str) :-
	name(H,HStr),
	namelist(TL,TStr),
	append(",",TStr,Temp),
	append(HStr,Temp,Str).

nameS(L,S) :-
	functor(L,_,0),
	name(L,S).
nameS(L,S):-
	functor(L,_,N),
	N>0,
	nameDecRL(L,S).

argstring(Literal,1,Nth,ArgString) :-!,
	arg(Nth,Literal,A),
	nameS(A,ArgString).

argstring(Literal,N,Nth,ArgString) :- 
	arg(Nth,Literal,A),
	nameS(A,NthArg),
	Nnew is N-1,
	Nthnew is Nth+1,
	argstring(Literal,Nnew,Nthnew,TArgString),
	append(NthArg,",",NthTemp),
	append(NthTemp,TArgString,ArgString).



%***********************************************************
% Predicates related to instantiation of template
%    Written by: Serap Yilmaz (14 May 1996)
%***********************************************************

%converttoname(L,N)
%N is list of the names of the strings in the term of the form 
%rp(Position,Name,Type) in list L.
%mode(+,?)

converttoname([],[]):- !.
converttoname([H|T],[H2|T2]) :-
	arg(2,H,NameStr), %rp(Position,Name,Type)
	name(H2,NameStr),
	converttoname(T,T2).


%instantparamnames(ParamNames,Term,Term2)
%e.g Term=foo(X,Y,Z,T)
%e.g ParamNames=['A','B','C','D']
%e.g Term2=foo('A','B','C','D')
%mode(+,+,?)

instantparamnames(ParamNames,Term,Term2) :-
	instantparamnames(ParamNames,Term,1,Term2).

instantparamnames([],Term,_,Term).
instantparamnames([Name|Rest],Term,Count,Head) :-
	arg(Count,Term,Name),
	NewCount is Count + 1,
	instantparamnames(Rest,Term,NewCount,Head).

%processterm(Pos,Term,SubTerms,NewTerm)
%Vars is the list of terms in term Term at positions Pos
%NewTerm is Term with at positions Pos Term is instantiated
%with Subterms
%mode(+,+,+,-),(+,-,+,+),(+,+,+,+)
 
processterm([],Term,[],Term).
processterm([Pos1|RestPos],Term,[SubTerm1|RestSub],Term2) :-
	arg(Pos1,Term,SubTerm1),
	processterm(RestPos,Term,RestSub,Term2).


%recursivecalls(ListofTX,Pred,Arity,APs,IPpos,APpos,Listofreccalls) 
%Listofreccalls is the list of recursive calls constituted of
%predicates whose name is Pred, arity is Arity, and parameters are
%determined according to the positions of IPpos and APpos
%mode(+,+,+,+,+,?)


recursivecalls([],_,_,_,_,_,[]).
recursivecalls([HTX|TTX],Pred,Arity,APs,IPpos,APpos,[RecCall|RestRecCalls]) :-
	functor(Term,Pred,Arity),	%construct pred(_,_,_,...,_)
	arg(IPpos,Term,HTX), % instantiate first arg by HTX
	processterm(APpos,Term,APs,RecCall),
	recursivecalls(TTX,Pred,Arity,APs,IPpos,APpos,RestRecCalls).


%collectvars(PosList,Reccalls,Vars)
%Vars is the columnwise listed result parameters of Reccalls
%mode(+,+,?)

collectvars([],_,[]).
collectvars([Count|Rest],Reccalls,Vars) :-
	columnwisecollect(Reccalls,Count,Vars1),
	collectvars(Rest,Reccalls,Vars2),
	append(Vars1,Vars2,Vars).


%columnwisecollect(Reccalls,Count,Vars1)
%Vars1 is the list of variables at the Countth position of recursive
%calls
%mode(+,+,?)

columnwisecollect([],_,[]). %cut
columnwisecollect([H|T],Count,Vars1) :-
	arg(Count,H,A),
	columnwisecollect(T,Count,Varlist),
	append([A],Varlist,Vars1).
	

%makeconj(Literallist,Conj)
%makes a conjunction Conj built outof the literal list Literal
%mode(+,?) or (-,+) 

makeconj([],true).
makeconj([Literal],Literal) :- !.
makeconj([HLiteral1,HLiteral2|Rest],and(HLiteral1,Conj)) :-
	makeconj([HLiteral2|Rest],Conj).

%replaceatom(Term1,Atom,Var,Term2) 
%Term2 is Term1 in which the first occurrence of Atom is replaced by Var
%mode(?,+,+,+) or (+,+,+,?)

replaceatom(Atom,Atom,Var,Var) :-
	atom(Atom),
	var(Var),!.
replaceatom(Term1,Atom,Var,Term2) :-
	Term1 ~= Atom,
	Term1 =..[F|Ts1],
	replaceatomaux(Ts1,Atom,Var,Ts2),
	Term2 =..[F|Ts2].

replaceatomaux([],_,_,[]).
replaceatomaux([T1|Ts1],Atom,Var,[T2|Ts2]) :-
	\+var(T1),!,
	replaceatom(T1,Atom,Var,T2),
	replaceatomaux(Ts1,Atom,Var,Ts2).
replaceatomaux([T1|Ts1],Atom,Var,[T1|Ts2]) :-
	replaceatomaux(Ts1,Atom,Var,Ts2).


%convertconjht(Conj,NewConj)
%NewConj is Conj in which any literal whose functor is "headtail"
%is replaced by the equality "="
%e.g. convertconjht(headtail(L,[H],T),L=[H|T])
%mode(+,+)

convertconjht(true,true).
convertconjht(headtail(L,Hs,T), L = L1 ):-
	append(Hs,T,L1).
convertconjht(Literal,Literal):- 
	functor(Literal,P,_), 
	P ~= and, P ~= headtail.
convertconjht(and(Conj1,Conj2),and(NConj1,NConj2)) :-
	convertconjht(Conj1,NConj1),
	convertconjht(Conj2,NConj2).

%conversion for new format of HeadInfos,TailInfos called in instTemplate 
convertPIs([],[]).

convertPIs([H1|T1], [H2|T2]):-
	H2 = pi(H1,_,_),
	convertPIs(T1,T2).

%instTemplate(Pred,Info,DecRinfo,SOClauses)
%SOClauses is an instantiation of generalized Template for predicate Pred
%using the infos Info, DecRinfo
%mode(+,+,+,+)
%instTemplate(sort,info(IPinfo,RPinfos,APinfos,decRinfo(halves('L',T1,T2),
%       [],[pi(T1,_,_),pi(T2,_,_)]),
%       2,DSArgs,DPCArgs,formVars(1,0,0,2)),SOClauses).
%instTemplate(sort,info(IPinfo,RPinfos,APinfos,decRinfo('L'=[H|T],
%	[pi(H1,_,_)],[pi(T,_,_)]),
%       2,DSArgs,DPCArgs,formVars(1,0,1,1)),SOClauses).


instTemplate(Pred,Info,SOClauses) :-
	Info=info(IPinfo,RPinfos,APinfos,DecRinfo,Arity,DSArgs,DPCArgs,FormVars),
	FormVars=formVars(Y,Z,HX,T),
	functor(Head,Pred,Arity), % construct head of the clauses
	columnwisecollect(RPinfos,1,YPos), %collect pos of result parameters
	columnwisecollect(APinfos,1,ZPos),%collect poss of auxiliary parameters
	processterm(YPos,Head,Yvars,_), %find the result parameters of the Head
        processterm(ZPos,Head,Zvars,_), %find the aux. parameters of the Head
	DecRinfo=decRinfo(DecR,HeadInfos,TailInfos), %construct recur. calls
        convertPIs(ListofTX,TailInfos),
	IPinfo = pi(IPPos,_,_),
        recursivecalls(ListofTX,Pred,Arity,Zvars,IPPos,ZPos,Listofcalls),
	collectvars(YPos,Listofcalls,Vars), %Vars is list of result params
	name(Pred,PredString),
	DPCPredStr=[68,80,67|PredString],
	name(DPCPredName,DPCPredStr), %construct e.g. 'DPCsort'
	ArityofDPCPred is HX+Y*T+Y+Z,
	functor(Term2,DPCPredName,ArityofDPCPred), % e.g.'DPCsort'(_,_,_)
	convertPIs(ListofHX,HeadInfos),
	append(ListofHX,Vars,HXVars),
	append(HXVars,Yvars,HXVarsYvars),
	append(HXVarsYvars,Zvars,Paramnames2),
	instantparamnames(Paramnames2,Term2,InstTerm2), %e.g. DPCsort'(HL,TS,S)
	SecondOrderAtom='$atom'(InstTerm2), % e.g.'$atom'('DPCsort'(HL,TS,S))
	InstTerm2 =..[_|Args2],
	DPCArgs=Args2, %take DPCArgs
	append(Listofcalls,[SecondOrderAtom],ListofPreds),
	makeconj(ListofPreds,Conj), %construct body conjunction except DecR
	IPinfo = pi(_,IPname,_),
	name(Name,IPname),
	arg(IPPos,Head,IPvar),
	replaceatom(DecR,Name,IPvar,DecRinst), %instantiate the IP of DecR 
        convertconjht(DecRinst,NDecRinst),
	Body1=and(NDecRinst,Conj),
	Clause1=if(Head,Body1),
        DSPredStr=[68,83|PredString],
	name(DSPredname,DSPredStr), 
	functor(Term3,DSPredname,Arity),
        Head =.. [_|Params],
	instantparamnames(Params,Term3,InstTerm3), % e.g. 'DSsort'(L,S)
	SecondOrderAtom2='$atom'(InstTerm3), % e.g.'$atom'('DSsort'(L,S))
	InstTerm3 =..[_|Args3],
	DSArgs=Args3, %take DSArgs
	Clause2=if(Head,SecondOrderAtom2),
	append([Clause1],[Clause2],SOClauses).


%decomposition primitives for lists and natural numbers.

decPrim(headtail('L',['HL'],'TL'),list(_),'L').
%decPrim(and(headtail('L',['HL'],'T'),partition('T','HL','TL1','TL2')),
%         list(int),'L').
%decPrim(and(headtail('L',['HL'],'T'),partition('T','HL','TL1','TL2')),
%         list(nat),'L').
decPrim(and(headtail('L',['H1','H2'],'T'),halves('L','TL1','TL2')),
	list(_),'L').
decPrim(and('N'=s('TN'),'HN'='N'),nat,'N').
