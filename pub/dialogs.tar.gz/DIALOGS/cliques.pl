%**************************************************
%*    Written by: Esra Erdem (14 May 1996)     *
%**************************************************

% powerset(As,Ss) iff Ss denotes all subsets of As except the empty set
% where As is a list of atoms and Ss is a list of lists of atoms.
 
powerset(As,Ss):-findall(S,(subsetG(S,As), S\==[]),Ss).

subsetG([],[]).
subsetG(S,[H|T]) :-
	S=[H|V],
	subsetG(V,T).
subsetG(S,[_|T]) :-
	subsetG(S,T).

subsetV([],_).
subsetV([H|T],L2):-
	delete(H,L2,NewL2),
	subsetV(T,NewL2).

delete(E,[E|R],R).
delete(E,[HL|TL],[HL|TR]) :-
	delete(E,TL,TR).



%-----------------------------------------
%-----------------------------------------


% equalSets(L1,L2) iff L1 and L2 represent the same set
% where L1 and L2 are lists of elements of same type.

equalSets([],[]).
equalSets(L,S):-length(L,X), length(S,X), haveSameElts(L,S).

% haveSameElts(L1,L2) iff L1 and L2 have the same elements
% where L1 and L2 are lists of elements of same type.

haveSameElts([],_).
haveSameElts([HL|TL],S):- member(S,HL), haveSameElts(TL,S).


%-----------------------------------------


% complete(As,L,M,Cl) iff the component L is complete, i.e. a clique, via compatibility w.r.t. M, and Cl is an atom denoting Pos, the positions of atom in L, and their msg MsgL
% where L is a non-empty list of atoms, As is a list of atoms, Cl is an atom, and M ...

connected(b,d,_).
connected(d,b,_).
connected(a,c,_).
connected(c,a,_).

%complete(_,[],_,clique([],_)).
%complete(As,[HL|TL],M,clique([HPos|TPos],_)):-
%			      findall(T, connected(HL,T,M), Ts),
%                              subsetV(TL,Ts),
%                              select([HPos],As,[HL]),
%                              complete(As,TL,M,clique(TPos,_)).
complete(As,L,M,clique(Pos,MsgL)):-
                      msg(L,MsgL),
                      admissible(MsgL,M),
                      select(Pos,As,L).


% completeComponents(As,Ss,M,CCs) iff CCs denotes the complete components among the subsets Ss of As, where connectedness is via compatibility w.r.t. the given costruction mode M
% where Ss and CCs are non-empty lists of lists of atoms, As is alist of atoms, and M is ...

completeComponents(As,Ss,M,CCs):-completeComponents(As,Ss,M,[],CCs).


% completeComponents(As,Ss,M,CurCCs,CCs) iff CCs denotes the complete components among the subsets Ss of As, where connectedness is via compatibility w.r.t. the given costruction mode M, and CurCCs denotes the currently detected complete components
% where Ss, CurCCs, and CCs are non-empty lists of lists of atoms, As is alist of atoms, and M is ...

completeComponents(_,[],_,CurCCs,CurCCs):-!.
completeComponents(As,[HSs|TSs],M,CurCCs,CCs):-complete(As,HSs,M,Cl),!,
                                               TempCCs=[Cl|CurCCs],
                                               completeComponents(As,TSs,M,TempCCs,CCs).
completeComponents(As,[_|TSs],M,CurCCs,CCs):-completeComponents(As,TSs,M,CurCCs,CCs).


%-----------------------------------------
%-----------------------------------------


% sumLength(S,L) iff L is the sum of lengths of lists X in "clique(X,_)"s of S
% where S is a list of atoms of "clique/2" and L is an integer.

sumLength(L,S):-sumLength(L,0,S).
sumLength([],S,S).
sumLength([clique(HS,_)|TS],T,L):-length(HS,LHS),
                         T1 is T+LHS,
                         sumLength(TS,T1,L).


%-----------------------------------------


% union(L1,L2,L3) iff L3 is the union of lists L1 and L2
% where L1,L2, and L3 are lists of elements of same type.

union([],L,L):-!.
union(L,[],L):-!.
union([HL1|TL1],L2,L3):-member(L2,HL1),!,
                        union(TL1,L2,L3).
union([HL1|TL1],L2,[HL1|L3]):-union(TL1,L2,L3).


% unionall(S,U) iff U is the union of all lists occuring in "clique/2"s of S
% where S is a list of atoms of "clique/2", and U is a list of atoms.


unionall(S,SU):-unionall(S,[],SU).
unionall([],U,U):-!.
unionall([clique(HS,_)|TS],TU,SU):-union(HS,TU,TU1),
                         unionall(TS,TU1,SU).


%-----------------------------------------


% intersection(L1,L2,L3) iff L3 is the intersection of L1 and L2
% where L1, L2, and L3 are lists of elements of same type.
 
intersection([],_,[]):-!.
intersection(_,[],[]):-!.
intersection([HL1|TL1],L2,[HL1|TL3]):-member(L2,HL1), !,
                                      intersection(TL1,L2,TL3).
intersection([_|TL1],L2,L3):-intersection(TL1,L2,L3).


% intersectionall(S,I) iff I is the intersection of all lists occuring in "clique/2"s ofS
% where S is a list of atoms of "clique/2", and I is a list of atoms.


intersectionall([clique(S,_)],S):-!.
intersectionall([clique(HS1,_),clique(HS2,_)|TS],I):-intersectionall([clique(HS2,_)|TS],NI),
                                 intersection(HS1,NI,I).


%-----------------------------------------


% partition(As,CCs,S) iff S is a partition of As into cliques, where each clique is an element of CCs
% where As is a list of atoms, and CCs and S are lists of atoms of "clique/2"

partition(As,CCs,S):- length(As,LAs),
                      subsetG(S,CCs),
                      sumLength(S,LAs),
                      unionall(S,SU),
                     
                      equalSets(SU,As),  
                      intersectionall(S,[]).  


%-----------------------------------------

% findSmallest(L,S) iff S is one of the smallest lists in L
% where L is a non-empty list of lists of elements of type X, and S is a list of of elements of type X.

findSmallest(L,S):-findTheSmallest(L,SC),
                   findEqual(L,SC,S).

% findEqual(L,L1,L2) iff L2 is a list, in L, equal in length with L1, a member of L
% where L is a non-empty list of lists of elements of type X, and L1 and L2 are non-empty lists of elements of type X.

findEqual(L,L1,L2):-length(L1,X),member(L,L2),length(L2,X). 


% findTheSmallest(L,S) iff S is the smallest list in L
% where L is a non-empty list of lists of elements of type X, and S is a list of of elements of type X.

findTheSmallest([L],L):-!.
findTheSmallest([HL1,HL2|TL],SC):-findTheSmallest([HL2|TL],NSC),!,
                               smaller(HL1,NSC,SC).

% smaller(L1,L2,SL) iff SL is the smallest of L1 and L2
% where L1, L2, and SL are lists of the same type elements.

smaller(X,Y,X):-length(X,LX),
                length(Y,LY),
                LX =< LY,!.
smaller(_,Y,Y).


%-----------------------------------------


% cliques(As,CCs,Cls) iff Cls is a partition  of As into a least number of cliques, where each clique is an element of CCs
% where As is a list of elements of type X, and CCs and Cls are lists of lists of elements of type X. 

cliques(As,CCs,Cls):-findall(S,partition(As,CCs,S),Cs),!,
                     findSmallest(Cs,Cls).


%-----------------------------------------
%-----------------------------------------


% getCliques(As,M,Cls) iff Cls is a partition of the given atoms As into a least number of cliques w.r.t. the given construction mode M
% where Cls and As are lists of atoms, and M is ...

getCliques([],_,[]):-!.
getCliques(As,M,Cls):-powerset(As,Ss),     
                      completeComponents(As,Ss,M,CCs),
                      length(As,N),iota(N,Ps),
                      cliques(Ps,CCs,Cls).




%**************************************************
%*      Predicates related to admissibility       *
%*    Written by: Serap Yilmaz (16 May 1996)      *
%**************************************************

%separateArgs(Args,Count,List1,List2)
%List1 is first Count arguments of list Args, List2 is the rest

separateArgs(Args,0,[],Args):-!.
separateArgs([T1|Tail1],Count,[T1|Tail2],Rest):-
        Count >= 1,
        NewCount is Count-1,
        separateArgs(Tail1,NewCount,Tail2,Rest). 


%separateArgs2(Args,Count1,Count2,List1,List2)
%List1 is list of lists whose length are Count2+1
%List2 is the rest of Args, that is Args=[flatten(List1),List2]
%used in admissibleDPC

separateArgs2(Args,_,0,[],Args):-!.
separateArgs2(Args,T,Count,[FirstTyY|Tail2],Zlist):-
         TY_Y is T+1, %to take TS1,TS2,..TSt,S
         separateArgs(Args,TY_Y,FirstTyY,Rest), %Rest=[TR1,TR2,...,TRt,Zs]
         NewCount is Count-1,
         separateArgs2(Rest,T,NewCount,Tail2,Zlist).      


%unionofConstituents(List,ConstList)
%ConstList is the list of constituents of terms in List
%mode(+,-)
%used in admissibleDS(DPC)

unionofConstituents([],[]). %clause indexing
unionofConstituents([H|T],ConstList) :-
        constituents2(H,ConstH),
        unionofConstituents(T,ConstListT),
        append(ConstH,ConstListT,ConstList).           


%admissible(Atom,Mode)
%checks if Atom is admissible with given Mode=mode(_) or Mode=mode(_,_,_,_)

admissible(Atom,Mode):-
	Mode=mode(_,_),!, %mode(Y,Z)
	admissibleDS(Atom,Mode).
admissible(Atom,Mode):-
	Mode=mode(_,_,_,_),  %mode(Y,Z,HX,T)
	admissibleDPC(Atom,Mode).


%admissibleDS(DSex,Mode)
%checks if DSex is admissible with given form Mode=mode(Y,Z)
%mode(+,+)
%e.g.admissible([true,[],[]],mode(1,_)).
%e.g.admissible([B1>=B2,[B2],[B1,B2],B1],mode(1,_)).
%e.g.admissible([B1>B2,[B1,B2],[B1,B2]],mode(1,_)).
%e.g.not admissible([B1>B2,[B1,B2],[B3,B2]],mode(1,_)).
%e.g.not admissible([P,[HL|TL],[HL|TL]],mode(1,_)).

admissibleDS(Atom,Mode):-
         Mode=mode(Y,_),
         Atom=[F|Args],
         legalconj(F),
         admissCond(Y,Args).


%admissCond(Args,Y) holds iff Args satisfy the admissibility 
%condition of DS.
%mode(+,+)

admissCond(Y,Args):-
         Args=[IP|RestofArgs], %Args=[X,Y1,Y2,..,Yy,Z1,Z2,...Zz]
         separateArgs(RestofArgs,Y,Ylist,Zlist),
         unionofConstituents(Zlist,ConstZlist),
         constituents2(IP,ConstIP),
         append(ConstIP,ConstZlist,ConstIPZlist),
         append(ConstIPZlist,[0,nil],Constituents),
         admissCond2(Ylist,Constituents).


%admissCond2(Constituents,Ylist) iff constituents of every term in Ylist
%is a subset of the Constituents
%mode(+,+)

admissCond2([],_).
admissCond2(Ylist,Constituents) :-
         Ylist=[Y1|RestofYlist],
         constituents2(Y1,ConstY1),
         subset2(ConstY1,Constituents),
         admissCond2(RestofYlist,Constituents).


%admissibleDPC(DPCex,Mode) checks if DPCex is admissible with given 
%Mode=mode(Y,Z,HX,T)
%mode(+,+)
%e.g.admissible([B1=<B2,B2,[B1],[B1,B2],B1],mode(1,_,1,1)).
%e.g.admissible([B1>B2,B1,[B2],[B2,B1]],mode(1,_,1,1)). 
%e.g.not admissible([B1>B3,B1,[B3],[B2,B1]],mode(1,_,1,1)).

admissibleDPC(Atom,Mode):-
         Mode=mode(0,_,_,_),!, %no aux. parameters
         Atom=[F|_], %updated:Args omitted
         legalconj(F).
admissibleDPC(Atom,Mode):-
         Mode=mode(Y,_,HX,T), %Y>0,updated:Z omitted
         Atom=[F|Args],
         legalconj(F),
         separateArgs(Args,HX,HXlist,RestArgs), %take HX terms
	 Count is Y*T,                          
         separateArgs(RestArgs,Count,ListofTY,RestArgs2), %take Tys
	 separateArgs(RestArgs2,Y,ListofY,Zlist), %take Ys and Zs
         unionofConstituents(Zlist,ConstZlist),
         unionofConstituents(HXlist,ConstHXlist),
	 unionofConstituents(ListofTY,ConstTY),
         constituents2(F,ConstF),
         admissDPCcond(ListofY,ListofTY,ConstTY,
         	ConstHXlist,ConstZlist,ConstF,T).


%admissDPCcond(ListofY,ListofTY,ConstTY,ConstHXlist,ConstZlist,ConstF,T)
%iff terms in the parameters are such that they satisfy the admissibility condition of DPC

admissDPCcond([],[],_,_,_,_,_). 
admissDPCcond([HY|RestofYlist],ListofTY,ConstTY,ConstHX,ConstZ,ConstF,T):-
         separateArgs(ListofTY,T,TYs,RestofTYlist),
         unionofConstituents(TYs,ConstTYlist),
         constituents2(HY,ConstofY),
         append(ConstofY,ConstF,ConstofYF),
         subset2(ConstTYlist,ConstofYF),
         append(ConstHX,ConstZ,ConstHXZ),
         append(ConstHXZ,ConstTY,ConstHXZTYlist),
         append(ConstHXZTYlist,[0,nil],Consts),
         subset2(ConstofY,Consts),
         admissDPCcond(RestofYlist,RestofTYlist,ConstTY,
         		ConstHX,ConstZ,ConstF,T).    
         

%legalconj(F) iff F is a legal conjunction
%that is F is not variable, not a literal with equality atom, it is flat conjunction
%mode(+)

legalconj(F):- \+var(F),F=true,!.
legalconj(F):-
         \+var(F),literal(F),!.
legalconj(F):- 
         \+var(F),F=and(Literal,Conj),
         literal(Literal),
         legalconj(Conj).


%literal(L) iff L is a literal
%mode(+)
 
literal(L):-
        compoundterm(L),!.
literal(L):-
        L=neg(Atom),
        compoundterm(Atom).


%compoundterm(T) iff T is compound prolog term
%mode(+)

compoundterm(T):-
        functor(T,F,Arity),
        F \= '=',
        Arity>0.

           
% constituents2(T,Ls)
%	Ls is the list of constituents of term T
%	(repetitions included), as they appear in T from left to right.
% NB. Computing the *set* of constituents would be less efficient.

constituents2(T,Ls) :-
	constituents2(T,Ls,[]).

constituents2(T,[T|Ls],Ls) :-
	var(T),!.
constituents2(T,[T|Ls],Ls) :-
	atomic(T),T\=[],!.
constituents2(T,Ls,Acc) :-
	T=..[_|Ts],
	constituents21(Ts,Ls,Acc).

constituents21([],Ls,Ls).
constituents21([T|Ts],Ls,Acc) :-
        constituents21(Ts,Acc1,Acc),
        constituents2(T,Ls,Acc1).


%subset2(L1,L2) holds iff list L1 is a subset of list L2
%L1 and L2 might include variables

subset2([],_). %clause indexing
subset2([H|T],L2):-
	member2(H,L2),
	subset2(T,L2).


%member2(E,L) holds iff term E is a member of list L
%if E is a variable, member2(E,L) holds iff there exists 
%a variable V in  L s.t. E==V.

member2(E,[T|_]):- 
	E==T,!.
member2(E,[_|TL]):-
	member2(E,TL).

