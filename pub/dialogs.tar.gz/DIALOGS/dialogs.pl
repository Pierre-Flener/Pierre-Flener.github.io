%******************************************************************************
%*									      *
%*  DIALOGS - Dialog-based Inductive and Abductive LOGic program Synthesizer  *
%*									      *
%*				 dialogs.pl				      *
%*									      *
%*		Written by: Pierre Flener (14 June 1996)		      *
%*									      *
%******************************************************************************


%%% Initializations

:- [library(not),phase1,phase2,utilities,
	primitives,prettyPrint,grammar,cliques].
:- dynamic short/1.
:- dynamic dialMode/1.
:- dynamic introduced/1.


%%% Specifier-level commands

aloud :-
	retractall(dialMode(_)),
	assert(dialMode(aloud)).
mute :-
	retractall(dialMode(_)),
	assert(dialMode(mute)).


% d, dialogs
%	Synthesis of a logic program through dialog.

d :-
	dialogs.

dialogs :-
	aloud,
	cleanup,			% only needed during DIALOGS design
	ask('Predicate declaration?',"",PredDeclStr),
	myPhrase(pred(Pred,ParamTypes),PredDeclStr),
	dialogs(Pred,ParamTypes,hints("",[],[],""),[],[],Pred,Pgm),
	writeln('A possible program is:'),
	ppPgm(Pgm),
	ask('Do you want another logic program?',"yes",AnswerStr),
	(AnswerStr="yes" ->
	 (writeln('Backtracking...'),fail)
	;
	 (cleanup,aloud,writeln('No (more) programs.'))
	).


cleanup :-
	retractall(di(_,_)),
	retractall(ip(_,_)),
	retractall(rp(_,_)),
	retractall(ap(_,_)),
	retractall(short(_)),
	retractall(introduced(_)).


% dialogs(CurrPred,ParamTypes,Hints,Infos,StartPgm,TopPred,Pgm)
%	Pgm is a logic program for predicate TopPred, obtained by adding
%	some clauses for predicate CurrPred (whose parameter name:type pairs
%	are ParamTypes) to the logic program StartPgm.  Hints contains
%	preferences for some decisions of phase 1.  Infos contains information
%	about the chain of D&C-defined predicates in StartPgm.  Shortcuts
%	for some predicates of StartPgm are asserted as short/1 facts.

dialogs(CurrPred,ParamTypes,Hints,Infos,StartPgm,TopPred,Pgm) :-
	phase1(CurrPred,ParamTypes,Hints,Info,SOclauses),
	append(StartPgm,SOclauses,CurrPgm),
	append(Infos,[Info],NewInfos),
	phase2(CurrPgm,NewInfos,TopPred,Pgm).
