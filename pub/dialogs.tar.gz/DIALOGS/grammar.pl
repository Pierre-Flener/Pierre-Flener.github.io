%******************************************************************************
%*									      *
%*				 grammar.pl				      *
%*									      *
%*		Written by: Pierre Flener (14 June 1996)		      *
%*			With: Halime Buyukyildiz			      *
%*									      *
%******************************************************************************

% myPhrase(PhraseType,List)
%	Deterministic version of the built-in phrase/2.

myPhrase(PhraseType,List) :-
	phrase(PhraseType,List),!.


%%% Definite Clause Grammar for parsing predicate declarations.

pred(Pred,ParamsTypes)	--> preFunct(Pred) , "(" , 
				variablesTypes(ParamsTypes) , ")".

preFunct(F)		--> low(C) , string(Cs) , {name(F,[C|Cs])}.

variablesTypes(LVT)	--> variableType(VT) , {LVT=[VT]}.
variablesTypes(LVT)	--> variableType(VT) , "," , variablesTypes(VTs) ,
				{LVT=[VT|VTs]}.

variableType(VT)	--> variable(V) , ":" , type(T), {VT=V:T}.

variable(V)	--> upp(C) , string(Cs) , {V=[C|Cs]}.

type(T)		--> "atom" , {T=atom} ;
		    "nat"  , {T=nat}  ;
		    "int"  , {T=int}  ;
		    "term" , {T=term} ;
		    "list(" , type(ST) , ")" , {T=list(ST)}.

variablesList(Vs) --> "[]",{Vs = []}.
variablesList(Vs) --> "[", variables(Vs),"]".
				      
variables(Vs)	--> variable(V) , {Vs=[V]}.
variables(Vs)	--> variable(V) , "," , variables(TVs) , {Vs=[V|TVs]}.
						
string(S)	--> [], {S=[]}.
string(S)	--> any(C) , string(Cs) , {S=[C|Cs]}.

any(C)		--> num(C) , !.
any(C)		--> upp(C) , !.
any(C)		--> low(C) , !.

num(C)		--> [C] , {48=<C , C=<57}.
upp(C)		--> [C] , {65=<C , C=<90}.
low(C)		--> [C] , {97=<C , C=<122}.


%%% Definite Clause Grammar for parsing terms.

term(T)		--> lconstr(T).
term(T)		--> nInfix(T).
term(T)		--> infix(T).

lconstr(T)	--> tvariable(V) , "=[" , tvariables(Hs) , "|" , 
			tvariable(TV) , "]" , {T=headtail(V,Hs,TV)}.

tvariable(V)	--> upp(C) , string(Cs) , {name(V,[C|Cs])}.

tvariables(VT)	--> tvariable(V) , {VT=[V]}.
tvariables(VT)	--> tvariable(V) , "," , tvariables(TVT) , {VT=[V|TVT]}. 

nInfix(T)	--> constant(T).
nInfix(T)	--> tvariable(T).
nInfix(T)	--> preFunct(F) , "(" , terms(Ts), ")" , {T=..[F|Ts]}.
nInfix(T)	--> list(T).
nInfix(T)	--> "(" , term(T) , ")".

infix(T)	--> nInfix(T1) , inFunct(F) , term(T2) , {T=..[F,T1,T2]}.

constant(A)	--> atomC(N) , {name(A,N)}.
constant(P)	--> integerC(N) , {name(I,N) , nat2Peano(I,P)}.

inFunct(F)	--> "="   , {F='=' }.
inFunct(F)	--> "\="  , {F='\='}.	% unsound inequality
inFunct(F)	--> "~="  , {F='~='}.	% suspicious inequality
inFunct(F)	--> "=/=" , {F='=/='}.	% attempt at sound inequality
inFunct(F)	--> ">"   , {F=gt}.
inFunct(F)	--> "<"   , {F=lt}.
inFunct(F)	--> ">="  , {F=ge}.
inFunct(F)	--> "<="  , {F=le}.

atomC(A)	--> low(C) , string(Cs) , {A=[C|Cs]}.

integerC(I)	--> num(N) , {I=[N]}.
integerC(I)	--> num(N) , integerC(Ns) , {I=[N|Ns]}.

list(L)		--> "[]" , {L=[]}.
list(L)		--> "[" , terms(L) , "]".
list(L)		--> "[" , terms(Hs) , "|" , variable(V) , "]", {append(Hs,V,L)}.

terms(LT)	--> term(T) , {LT=[T]}.
terms(LT)	--> term(T) , "," , terms(Ts), {LT=[T|Ts]}.


%%% Definite Clause Grammar for parsing flat conjunctions

fconjunction(D)	--> term(T) , {D=T}.
fconjunction(D)	--> term(T) , "," , fconjunction(TD) , {D=and(T,TD)}.
