%******************************************************************************
%*									      *
%*				 phase2.pl				      *
%*									      *
%*		Written by: Pierre Flener (29 May 1996)			      *
%*									      *
%******************************************************************************

% phase2(CurrPgm,Infos,TopPred,Pgm)
%	Pgm is a logic program for predicate TopPred, obtained from the
%	second-order logic program CurrPgm by instantiating the unknown
%	operators of its second-order clauses.  Infos contains information
%	about the chain of D&C-defined predicates in CurrPgm.  Shortcuts
%	for some predicates of CurrPgm are asserted as short/1 facts.

phase2(CurrPgm,Infos,TopPred,Pgm) :-
%		writeln('Current program: '),ppPgm(CurrPgm),
	abduce(CurrPgm,Infos,TopPred,DSev,DPCev),
	induce(DSev,DPCev,Infos,DSinsts,DPCinsts),
	evaluate(DPCinsts,DSinsts,DPCev,DSev,CurrPgm,Infos,TopPred,Pgm).

% -------------------------------------------------------------------------- %

% abduce(Pgm,Infos,TopPred,DSev,DPCev)
%	DSev and DPCev are lists of abduced tuples for the DS-R and DPC-R
%	predicate variables occurring in (the last two clauses of) Pgm,
%	whose top-level predicate is TopPred.  Infos contains information
%	about the chain of D&C-defined predicates in Pgm.

abduce(Pgm,Infos,TopPred,DSev,DPCev) :-
	Infos=[info(pi(IPpos,_,IPtype),_,_,_,Arity,_,_,_)|_],
	findall(couple(DSexs,DPCexs),
		(buildGoal(TopPred,Arity,IPpos,IPtype,Goal),
%			cutify(Goal,CuteGoal,_),
%			write('***Now proving goal: <-- '),ppConj(CuteGoal),nl,
		 pgmClause(Pgm,Goal,Body),
		 demo(Body,Pgm,Ass,Res,MaybeLast),
		 (MaybeLast=none -> Last=Goal ; Last=MaybeLast),
		 askQuery(Goal,Ass,Res,DSexs,DPCexs,Last)),
		Couples),
	retractOpShorts,
	unzip(Couples,DSev,DPCev).


% buildGoal(Pred,Arity,Pos,Type,Goal)
%	Goal is a most-general goal/atom for predicate Pred of arity Arity,
%	and this for various most-general values of the induction parameter,
%	which is at argument position Pos and of type Type.

buildGoal(Pred,Arity,Pos,Type,Goal) :-
	functor(Goal,Pred,Arity),
	mostGenForm(Type,Form),
	arg(Pos,Goal,Form).

mostGenForm(nat,0).
mostGenForm(nat,s(0)).
mostGenForm(nat,s(s(0))).
mostGenForm(nat,s(s(s(0)))).
mostGenForm(list(_),[]).
mostGenForm(list(_),[_]).
mostGenForm(list(_),[_,_]).
mostGenForm(list(_),[_,_,_]).


% demo(Goal,Pgm,Ass,Res,Last)
%	Flat conjunction Res is the residue of SLD-resolving conjunction Goal
%	with respect to second-order logic program Pgm;  flat conjunction Ass
%	has the assumptions (with introduced predicates, which are skipped)
%	of this process.  Last is the last unfolded atom whose predicate is
%	defined in Pgm, and 'none' if no such unfolding occurred.

demo(true,_,Ass,Res,Last) :-		% empty goal
	!,Ass=true,Res=true,Last=none.
demo(and(G1,G2),Pgm,Ass,Res,Last) :-	% conjunctive goal
	!,demo(G1,Pgm,Ass1,Res1,_),
	demo(G2,Pgm,Ass2,Res2,Last),
	conjoin(Ass1,Ass2,Ass),
	conjoin(Res1,Res2,Res).
demo('$atom'(Atom),Pgm,Ass,Res,Last) :-	% second-order & positive literal
	legalShort(Atom,Body),		% there is a "legal" shortcut
%		cutify(c(Atom,Body),c(CuteAtom,CuteBody),_),
%		write('Trying shortcut during unfolding: '),
%		print(CuteAtom),write(' <-- '),ppConj(CuteBody),nl,
	demo(Body,Pgm,Ass,Res,Last).
demo('$atom'(Atom),_,Ass,Res,Last) :-	% second-order & positive literal
	!,\+legalShort(Atom,_),		% there is no "legal" shortcut
	Ass=true,
	Res='$atom'(Atom),
	Last=none.
demo(neg(Atom),_,Ass,Res,Last) :-	% first-order & negative literal
	!,introduced(Atom),		% but introduced
	Ass=neg(Atom),			% other negation is disallowed
	Res=true,
	Last=none.
demo(Atom,_,Ass,Res,Last) :-		% first-order & positive literal
	introduced(Atom),!,		% and introduced
	Ass=Atom, 
	Res=true,
	Last=none.
demo(Atom,_,Ass,Res,Last) :-		% first-order & positive literal
	primitive(Atom),!,		% not introduced, but Dialogs primitive
	call(Atom),			% it must succeed
	Ass=true,
	Res=true,
	Last=none.
demo(Atom,Pgm,Ass,Res,Last) :-		% first-order & positive literal
	short(if(Atom,Body)),		% there is a shortcut
%		cutify(c(Atom,Body),c(CuteAtom,CuteBody),_),
%		write('Trying shortcut during unfolding: '),
%		print(CuteAtom),write(' <-- '),ppConj(CuteBody),nl,
	demo(Body,Pgm,Ass,Res,Last).
demo(Atom,Pgm,Ass,Res,Last) :-		% first-order & positive literal
	\+short(if(Atom,Body)),		% there is no shortcut
	pgmClause(Pgm,Atom,Body),
	demo(Body,Pgm,Ass,Res,MaybeLast),
	(MaybeLast=none -> Last=Atom ; Last=MaybeLast).


% legalShort(Atom,Body)
%	Body is the body (under substitution \theta) of an asserted shortcut
%	whose head is a variant (under \theta) of Atom.

legalShort(Atom,Body) :-
	copy_term(Atom,CopyBefore),
	numbervars(CopyBefore,1,N),
	short(if(Atom,Body)),
	copy_term(Atom,CopyAfter),
	numbervars(CopyAfter,1,N).


% pgmClause(Pgm,Head,Body)
%	Logic program Pgm has a clause whose head matches atom Head,
%	and whose body matches conjunction Body.

pgmClause([Clause|_],Head,Body) :-
	copy_term(Clause,NewClause),	% needed???
	NewClause=if(Head,Body).
pgmClause([_|Pgm],Head,Body) :-
	pgmClause(Pgm,Head,Body).


% askQuery(Goal,Ass,Res,DSexs,DPCexs,Last)
%	DSexs or DPCexs is a list of abduced tuples for the DS-R or DPC-R
%	predicate variable (if any) occurring in flat conjunction Res, which
%	is the residue of proving conjunction Goal, the assumptions being in
%	the flat conjunction Ass.  At least one of DSexs and DPCexs is empty.
%	Last is the last unfolded atom whose predicate is defined in Pgm.

askQuery(_,_,Res,DSexs,DPCexs,_) :-
	Res=true,!,			% no Residue
	DSexs=[],
	DPCexs=[].
askQuery(Goal,Ass,Res,DSexs,DPCexs,Last) :-
	Res='$atom'(ResAtom),		% Residue has 1! SOatom
  % offline (via shortcuts, w/o updating introduced/1):
	collect(AllAnswers,Goal), % danger(?): this may instantiate Goal...
	pruneConjs(AllAnswers,Ass,AnswersOff),
	(AnswersOff=[] ->
  % online:
	 (vars(Goal,GoalVars),
	  cutify(q(GoalVars,Goal,Ass),q(CuteGoalVars,CuteGoal,CuteAss),Subst1),
	  write('What conditions on '),ppTuple(CuteGoalVars),
	  write(' must hold such that '),print(CuteGoal),
	  write(' holds'),
	  (CuteAss=true -> true ; (write(', assuming '),ppConj(CuteAss))),
	  writeln('?'),
	  read_term([variable_names(Subst2)],AnswerDisj),
	  AnswerDisj~=false, AnswerDisj~=stopit,
	  rebind(Subst2,Subst1),
	  disjList(AnswerDisj,Answers1),
	  commaAnds(Answers1,Answers),
	  updateIntros(Answers)
	 )
	;(Answers=AnswersOff
%		,writeln('Using shortcut(s) instead of querying...')
	 )
	),
  % whether online or offline, continue here:
	ResAtom=..[ResPred|Args],
	name(ResPred,ResPredStr),
	(ResPredStr=[68,83|_] ->		% "DS..."
	 (buildDSexsShorts(Answers,ResAtom,Last,Args,Ass,DSexs),
	  DPCexs=[]
	 )
	;(DSexs=[],				% "DPC..."
	  buildDPCexsShorts(Answers,ResAtom,Last,Args,Ass,DPCexs)
	 )
	).


% collect(Cs,H)
%	List Cs contains all the conjunctions that are the bodies of
%	asserted shortcuts with head H.

collect(Cs,H) :-
	collect(Cs1,[],H),
	reverse(Cs1,Cs).

collect(Cs,Accu,H) :-
	short(if(H,C)),	% danger(?): this may (further) instantiate H...
	\+ \+ demo(C,[],_,true,_),	% it's provable
	\+ memberCheck2(Accu,C),!,
	collect(Cs,[C|Accu],H).
collect(Cs,Cs,_).


% pruneConjs(Conjs1,Conj,Conjs2)
%	Conjs2 is Conjs1 where only the flat conjunctions containing all the
%	literals of flat conjunction Conj are retained, but without those
%	literals of Conj.

pruneConjs([],_,[]).
pruneConjs([Conj1|Conjs1],Conj,[Conj2|Conjs2]) :-
	pruneConj(Conj,Conj1,Conj2),!,
	pruneConjs(Conjs1,Conj,Conjs2).
pruneConjs([_|Conjs1],Conj,Conjs2) :-
	pruneConjs(Conjs1,Conj,Conjs2).

% pruneConj(Conj,Conj1,Conj2)
%	Conj2 is flat conjunction Conj1 without all the literals of
%	flat conjunction Conj.

pruneConj(true,Conj1,Conj2) :-
	!,Conj2=Conj1.
pruneConj(and(Lit,Conj),Conj1,Conj2) :-
	!,pruneLit(Conj1,Lit,IntConj),
	pruneConj(Conj,IntConj,Conj2).
pruneConj(Lit,Conj1,Conj2) :-
	pruneLit(Conj1,Lit,Conj2).

% pruneLit(Conj1,Lit,Conj2)
%	Conj2 is flat conjunction Conj1 without literal Lit.

pruneLit(and(Lit1,Conj1),Lit,Conj2) :-
	Lit==Lit1,!,
	Conj2=Conj1.
pruneLit(and(Lit1,Conj1),Lit,Conj2) :-
  % i.e.Lit\==Lit1,
	!,pruneLit(Conj1,Lit,IntConj),
	(IntConj=true -> Conj2=Lit1 ; Conj2=and(Lit1,IntConj)).
pruneLit(Lit1,Lit,Conj2) :-
	Lit==Lit1,
	Conj2=true.


% updateIntro(Conj)
%	Declare every predicate of conjunction Conj that is not a Prolog
%	primitive as an introduced predicate.

updateIntro(and(Conj1,Conj2)) :-
	!,updateIntro(Conj1),
	updateIntro(Conj2).
updateIntro(true) :- !.
updateIntro(Atom) :-
	functor(Atom,Pred,Arity),
	functor(MostGenAtom,Pred,Arity),
	(sysPrim(MostGenAtom) ->
	  true					% it is a Prolog-primitive
	;(retractall(introduced(MostGenAtom)),	% it's not a Prolog-primitive
	  assert(introduced(MostGenAtom))
	 )
	).

updateIntros([]).
updateIntros([Conj|Conjs]) :-
	updateIntro(Conj),
	updateIntros(Conjs).


% buildDSexsShorts(Answers,ResAtom,Atom,Args,Ass,DSexs)
%	DSexs is a list of abduced tuples for the DS-R predicate variable
%	occurring in residue atom ResAtom (of arguments Args), namely one
%	for each conjunctive answer in Answers, which were obtained for
%	the query extracted from the top-level atom Atom (of predicate R)
%	and the conjunctive assumptions Ass.  Shortcuts for DS-R and R are
%	asserted as well.

buildDSexsShorts([],_,_,_,_,[]).
buildDSexsShorts([Answer|Answers],ResAtom,Atom,Args,Ass,[DSex|DSexs]) :-
	copy_term(q(Answer,ResAtom,Atom,Args,Ass),
		  q(CAnswer,CResAtom,CAtom,CArgs,CAss)),
	conjoin(CAnswer,CAss,CBody),
%		cutify(t(CResAtom,CAtom,CBody),
%			t(CuteResAtom,CuteAtom,CuteBody),_),
%		write('Abducing/asserting evidence:  '),
%		print(CuteResAtom),write(' <-- '),ppConj(CuteBody),nl,
	retractall(short(if(CResAtom,CBody))),
	assert(short(if(CResAtom,CBody))),
%		write('Asserting shortcut: '),
%		print(CuteAtom),write(' <-- '),ppConj(CuteBody),nl,
	retractall(short(if(CAtom,CBody))),
	assert(short(if(CAtom,CBody))),
	demo(CAnswer,[],NewAnswer,true,_),	% DIALOGS-primitive elimination
	conjoin(NewAnswer,CAss,NewBody),
	DSex=[NewBody|CArgs],
	buildDSexsShorts(Answers,ResAtom,Atom,Args,Ass,DSexs).


% buildDPCexsShorts(Answers,ResAtom,Atom,Args,Ass,DPCexs)
%	DPCexs is a list of abduced tuples for the DPC-R predicate variable
%	occurring in residue atom ResAtom (of arguments Args), namely one
%	for each conjunctive answer in Answers, which were obtained for
%	the query extracted from the top-level atom Atom (of predicate R)
%	and the conjunctive assumptions Ass.  Shortcuts for DPC-R and R are
%	asserted as well.

buildDPCexsShorts([],_,_,_,_,[]).
buildDPCexsShorts([Answer|Answers],ResAtom,Atom,Args,Ass,[DPCex|DPCexs]) :-
	copy_term(q(Answer,ResAtom,Atom,Args,Ass),
		  q(CAnswer,CResAtom,CAtom,CArgs,CAss)),
	conjoin(CAnswer,CAss,CBody),
%		cutify(q(CResAtom,CAtom,CBody,CAnswer),
%			q(CuteResAtom,CuteAtom,CuteBody,CuteAnswer),_),
%		write('Abducing/asserting evidence: '),
%		print(CuteResAtom),write(' <-- '),ppConj(CuteAnswer),nl,
	retractall(short(if(CResAtom,CAnswer))),
	assert(short(if(CResAtom,CAnswer))),
%		write('Asserting shortcut: '),
%		print(CuteAtom),write(' <-- '),ppConj(CuteBody),nl,
	retractall(short(if(CAtom,CBody))),
	assert(short(if(CAtom,CBody))),
	demo(CAnswer,[],NewAnswer,true,_),	% DIALOGS-primitive elimination
	DPCex=[NewAnswer|CArgs],
	buildDPCexsShorts(Answers,ResAtom,Atom,Args,Ass,DPCexs).


% retractOpShorts
%	Retract all shortcuts for the operators of the current predicate.

retractOpShorts :-
	short(if(Head,_)),
	functor(Head,Pred,Arity),
	name(Pred,PredStr),
	(PredStr=[68,83|_] ; PredStr=[68,80,67|_]),!,	% "DS..." or "DPC..."
	functor(GenH,Pred,Arity),
	retractall(short(if(GenH,_))),
	retractOpShorts.
retractOpShorts.


% unzip(Couples,List1,List2)
%	List[1,2] is the concatenation of the lists in the [1st,2nd]
%	argument positions in the couple/2 elements of list Couples.

unzip([],[],[]).
unzip([couple(Xs,Ys)|Couples],List1,List2) :-
	unzip(Couples,SuffList1,SuffList2),
	append(Xs,SuffList1,List1),
	append(Ys,SuffList2,List2).

% -------------------------------------------------------------------------- %

% induce(DSev,DPCev,Infos,DSinsts,DPCinsts)
%	DSinsts and DPCinsts are the conjunctive instances of the DS-R
%	and DPC-R predicate variables obtained by applying the MSG Method
%	to the corresponding tuples in lists DSev and DPCev.  Infos has
%	information about the chain of D&C-defined predicates in the
%	program currently being synthesized.
% Simplifying assumption: admissibility is an equivalence relation, in
% which case all connected components of a graph are strongly connected,
% hence cliques.

induce(DSev,DPCev,Infos,DSinsts,DPCinsts) :-
%		writeln('Entering MSG Method with the following evidence'),
%		writeln('DS evidence'),ppList(DSev),nl,
%		writeln('DPC evidence'),ppList(DPCev),nl,
	append(_,[info(_,_,_,_,_,DSargs,DPCargs,FormVars)],Infos),!,
	FormVars=formVars(Y,Z,HX,T),
	reverse(DSev,DSev1),	% make counterpart positions coincide
	reverse(DPCev,DPCev1),	% make counterpart positions coincide
	getCompos(DPCev1,mode(Y,Z,HX,T),DPCcliques),		% step 1
%		writeln('Step1: DPC cliques'),ppList(DPCcliques),nl,
	prune(DPCcliques,DSev1,mode(Y,Z),DPCcliques1,DSev2),	% step 2
%		writeln('Step2: New DS evidence'),ppList(DSev2),nl,
%		writeln('Step2: New DPC cliques'),ppList(DPCcliques1),nl,
	buildInsts(DPCcliques1,DPCargs,DPCinsts),		% step 3
%		writeln('Step3: DPC instances'),ppList(DPCinsts),nl,
	getCompos(DSev2,mode(Y,Z),DScliques),			% step 4
%		writeln('Step4: DS cliques'),ppList(DScliques),nl,
	buildInsts(DScliques,DSargs,DSinsts).			% step 4
%		,writeln('Step4: DS instances'),ppList(DSinsts),nl.


% getCliques(Atoms,Mode,Cliques)
%	see file cliques.pl by Esra Erdem


% getCompos(Atoms,Mode,Compos)
%	Compos is the list of connected components (through the admissibility
%	relation based on mode Mode, which is *assumed* to be an equivalence
%	relation) of the atom list Atoms.

getCompos(Atoms,Mode,Compos) :-
	components(Atoms,1,Mode,[],Compos).

components([],_,_,Cs,Cs).
components([A|As],Pos,Mode,Cs,NewCs) :-
	placement(Cs,A,Pos,Mode,IntCs),
	NewPos is Pos + 1,
	components(As,NewPos,Mode,IntCs,NewCs).

placement([],A,Pos,_,[clique([Pos],A)]).
placement([C|Cs],A,Pos,Mode,NewCs) :-
	C=clique(Ps,OldMSG),
	msg(OldMSG,A,NewMSG),
	(admissible(NewMSG,Mode) ->
	 (NewC=clique([Pos|Ps],NewMSG),
	  NewCs=[NewC|Cs])
	;(placement(Cs,A,Pos,Mode,TailNewCs),
	  NewCs=[C|TailNewCs])
	).


% prune(DPCcliques,DSev,DSmode,DPCcliques1,DSev1)
%	DPCcliques1 has the cliques of DPCcliques whose counterpart subsets
%	in DSev do not have admissible msg's (according to mode DSmode).
%	DSev1 has the tuples of DSev that do not have counterparts among
%	the tuples for DPC or whose counterparts do not participate in a
%	clique of DPCcliques1.

prune(DPCcliques,DSev,DSmode,DPCcliques1,DSev1) :-
	eliminate(DPCcliques,DSev,DSmode,DPCcliques1,ElimDSps),
	sort(ElimDSps,Pos),
	length(DSev,DScount),
	iota(DScount,AllPos),
	ordDiff(AllPos,Pos,RemPos),
	select(RemPos,DSev,DSev1).

eliminate([],_,_,[],[]).
eliminate([Clique|DPCcliques],DSev,DSmode,DPCcliques1,ElimDSps) :-
	Clique=clique(Positions,_),
	reverse(Positions,RevPos),
	select(RevPos,DSev,Counterpart),
	msg(Counterpart,MSG),
	(admissible(MSG,DSmode) ->
	  eliminate(DPCcliques,DSev,DSmode,DPCcliques1,ElimDSps)
	;(eliminate(DPCcliques,DSev,DSmode,TailDPCcliques1,TailElimDSps),
	  DPCcliques1=[Clique|TailDPCcliques1],
	  append(Positions,TailElimDSps,ElimDSps)
	 )
	).


% buildInsts(Cliques,Vars,Insts)
%	Conjunctions Insts are built from the variables Vars and the
%	msgs of the cliques Cliques.

buildInsts([],_,[]).
buildInsts([Clique|Cliques],Vars,[Inst|Insts]) :-
	Clique=clique(_,[Conj|Terms]),
	zip(Vars,Terms,Eqs),
	conjoin(Eqs,Conj,Inst),
	buildInsts(Cliques,Vars,Insts).

% -------------------------------------------------------------------------- %

% evaluate(DPCinsts,DSinsts,DPCev,DSev,CurrPgm,Infos,TopPred,Pgm)
%	Program Pgm (for top-level predicate TopPred) is obtained from
%	current program CurrPgm by instantiating its predicate variables
%	DS-R and DPC-R based on their instances DSinsts and DPCinsts;
%	this instantiation is either direct or through recursive synthesis
%	(in which case some of DSev are used to instantiate DS-R).  Infos
%	contains information about the chain of D&C-defined predicates
%	in CurrPgm.

%evaluate([],_,DPCev,DSev,CurrPgm,Infos,TopPred,Pgm) :-	% w=0 --> reject
% A better (and automated) heuristic is needed here!
evaluate(_,_,DPCev,DSev,CurrPgm,Infos,TopPred,Pgm) :-
%		write('Please evaluate MSG Method results: '),
		writeln('Need for recursive synthesis? [y/n]'),
		readLine(Answer),Answer="y",
	!,writeln('Need for recursive synthesis detected!'),
	append(_,[info(IPinfo,RPinfos,APinfos,DecRinfo,
			_,DSargs,_,formVars(Y,Z,_,T))],Infos),!,
	feasible(Y,T),
	append(PrefixPgm,[SOrecClause,SOnonRecClause],CurrPgm),!,
	SOrecClause=if(Head,SObody),
	assert(introduced(Head)),
  % construct NewPred
	functor(Head,CurrPred,Arity),
	name(CurrPred,[C|Cs]),			% e.g. "r..."
	UppC is C - 32,				% e.g.  R
	name(NewPred,[100,112,99,UppC|Cs]),	% e.g. "dpcR..."
  % construct NewParamTypes
	RPinfos=[pi(_,RPname,RPtype)],
	NewIPname=[84|RPname],			% "T..."
	DecRinfo=decRinfo(_,HeadInfos,_),	% comment until phase1 ready
	IPinfo=_,				% comment until phase1 ready
%		IPinfo=pi(_,_,list(ElemType)),
%		HeadInfos=[pi(_,"H",ElemType)],
%		DecRinfo=_,
	reverse(APinfos,RevAPinfos),
	buildDNs(RevAPinfos,SomeDecls,[],SomeAPnames,[]),
	reverse(HeadInfos,RevHeadInfos),
	buildDNs(RevHeadInfos,NewParamTypes,[NewIPname:RPtype,
			RPname:RPtype|SomeDecls],APnames,SomeAPnames),
  % construct Hints
	Hints=hints(NewIPname,[RPname],APnames,""),
  % construct IntPgm
	getSO(SObody,NewPred,IncBody,Inst),
	assert(introduced(Inst)),
	instSO([Inst],if(Head,IncBody),[RecClause]),
	length(DSev,DScount),
	length(DPCev,DPCcount),
	Delta is DScount - DPCcount,
	firstM(Delta,DSev,PreDSev),
	getCompos(PreDSev,mode(Y,Z),DScliques),
	buildInsts(DScliques,DSargs,DSinsts),
	elimSO(SOnonRecClause,IncNonRecClause),
	instSO(DSinsts,IncNonRecClause,NonRecClauses),
	functor(GenH,CurrPred,Arity),
	retractall(introduced(GenH)),
	retractall(introduced(Inst)),
	append(PrefixPgm,[RecClause|NonRecClauses],IntPgm),
		writeln('So far, the synthesized program is:'),
		ppPgm(IntPgm),
		writeln('Calling DIALOGS with the predicate declaration'),
		ppDecl(NewPred,NewParamTypes),
	mute,
	dialogs(NewPred,NewParamTypes,Hints,Infos,IntPgm,TopPred,Pgm).
evaluate(DPCinsts,DSinsts,_,_,CurrPgm,_,_,Pgm) :-	% w>0 --> accept
	append(PrefixPgm,[SOrecClause,SOnonRecClause],CurrPgm),!,
	SOrecClause=if(Head,_),		% allow primitive elimination
	retractall(introduced(Head)),	% by declaring CurrPred as an
	assert(introduced(Head)),	% introduced predicate
	elimSO(SOrecClause,IncRecClause),
	instSO(DPCinsts,IncRecClause,RecClauses),
	elimSO(SOnonRecClause,IncNonRecClause),
	instSO(DSinsts,IncNonRecClause,NonRecClauses),
	functor(Head,Pred,Arity),	% restore CurrPred as a
	functor(GenH,Pred,Arity),	% non-introduced predicate,
	retractall(introduced(GenH)),	% for backtracking synthesis
	append(RecClauses,NonRecClauses,NewClauses),
	append(PrefixPgm,NewClauses,Pgm).


% feasible(Y,T)
%	Decide whether the underlying d&c schema is powerful enough to
%	support a recursive call to the synthesizer.

feasible(1,1) :- !.
feasible(_,_) :-
	writeln('However, this prototype implementation cannot handle this'),
	writeln('particular situation, as its divide-and-conquer schema is'),
	writeln('not powerful enough.  We are sorry for the inconvenience.'),
	fail.


% buildDNs(ParamInfos,Decls,AccuDecls,Names,AccuNames)
%	Decls is Name:Type pairs extracted from ParamInfos <> AccuDecls;
%	Names is Names extracted from ParamInfos <> AccuNames;

buildDNs([],Decls,Decls,Names,Names).
buildDNs([pi(_,Name,Type)|ParamInfos],Decls,AccuDecls,Names,AccuNames) :-
	buildDNs(ParamInfos,Decls,[Name:Type|AccuDecls],Names,[Name|AccuNames]).


% getSO(SOconj,Pred,IncConj,Atom)
%	IncConj is SOconj without the second-order atom at the end,
%	and Atom is that second-order atom where the predicate variable
%	is replaced by predicate Pred.

getSO('$atom'(SOatom),Pred,true,Atom) :-
	SOatom=..[_|Args],
	Atom=..[Pred|Args].
getSO(and(Lit,SOconj),Pred,IncConj,Atom) :-
	getSO(SOconj,Pred,IntConj,Atom),
	(IntConj=true -> IncConj=Lit ; IncConj=and(Lit,IntConj)).


% elimSO(SOclause,IncClause)
%	IncClause is SOclause without the second-order atom at the end of
%	its body.

elimSO(if(Head,SObody),if(Head,IncBody)) :-
	makeFO(SObody,IncBody).

makeFO('$atom'(_),true).
makeFO(and(Lit,SOconj),IncBody) :-
	makeFO(SOconj,IntBody),
	(IntBody=true -> IncBody=Lit ; IncBody=and(Lit,IntBody)).


% instSO(Insts,IncClause,Clauses)
%	Clauses contains the clauses obtained by conjoining the flat
%	conjunctions Insts to the body (a flat conjunction) of IncClause;
%	these clauses are syntactically simplified on-the-fly by elimination
%	of the DIALOGS primitives.

instSO([],_,[]).
instSO([Inst|Insts],IncClause,[Clause|Clauses]) :-
        IncClause=if(Head,IncBody),
        conjoin(IncBody,Inst,Body),
        copy_term(if(Head,Body),if(CHead,CBody)),
        demo(CBody,[],NewBody,true,_),    % DIALOGS-primitive elimination
        Clause=if(CHead,NewBody),
        instSO(Insts,IncClause,Clauses).
