%******************************************************************************
%*									      *
%*				 primitives.pl				      *
%*									      *
%*		Written by: Pierre Flener (20 May 1996)			      *
%*									      *
%******************************************************************************

%:- dynamic '=/='/2.
%:- dynamic nat/1, list/1.
%:- dynamic add/3, mult/3.
%:- dynamic member/2.
%:- dynamic lt/2, gt/2, le/2, ge/2.
%:- dynamic partition/4, halves/3.


%%% Constructive inequality   [?]
%%% (attempt at sound inequality for inductively defined types)

'=/='([],[_|_]).
'=/='([_|_],[]).
'=/='([A|_],[B|_]) :- A\=B.
'=/='(0,s(_)).
'=/='(s(_),0).
'=/='(s(A),s(B)) :- '=/='(A,B).


%%% Type-checking primitives that may be used in answers   [?]

% nat(N)
%	N is a Peano-integer.

nat(0).
nat(s(_)).			% for pseudo-integers
%nat(s(N)) :- nat(N).


% list(L)
%	L is a list.

list([]).
list([_|_]).			% for pseudo-lists
%list([_|T]) :- list(T).


%%% Primitives for Peano integers that may be used in answers

% add(A,B,S)
%	S is the sum of Peano-integers A and B.
% OK for all modes, except (-,-,-).

add(0,B,B).
add(s(A),B,s(S)) :-
	add(A,B,S).


% mult(A,B,P)
%	P is the product of Peano-integers A and B.
% OK for (+,+,-) only. (why?)

mult(0,_,0).
mult(s(A),B,P) :-
	mult(A,B,Int),
	add(Int,B,P).


%%% Primitives for Peano-numbers that are obtained by parsing of answers

% lt(A,B)
%	Peano-number A is strictly less (<) than Peano-number B.

lt(0,s(_)).
lt(s(A),s(B)) :-
	lt(A,B).


% gt(A,B)
%	Peano-number A is strictly greater (>) than Peano-number B.

gt(A,B) :- lt(B,A).


% le(A,B)
%	Peano-number A is less or equal (<=) to Peano-number B.

le(A,A).
le(A,B) :- lt(A,B).


% ge(A,B)
%	Peano-number A is greater or equal (>=) to Peano-number B.

ge(A,B) :- le(B,A).


%%% Decomposition primitives that are known to DIALOGS

% partition(L,H,S,B)
%	S is the elements of integer-list T that are <  than Peano-number H;
%	B is the elements of integer-list T that are >= than Peano-number H.

partition([],_,[],[]).
partition([H|T],P,[H|S],B) :-
	lt(H,P),
	partition(T,P,S,B).
partition([H|T],P,S,[H|B]) :-
	ge(H,P),
	partition(T,P,S,B).


% halves(L,F,S)
%	F is the first half of list L; S is the corresponding suffix of L.
%	If L is of uneven length, then the element in the middle goes into S.

halves(L,F,S) :-
	halves(L,L,F,S).

halves(L,[],[],L).
halves(L,[_],[],L).
halves([HL11|TL1],[_,_|TTL2],[HL11|TF],S) :-
	halves(TL1,TTL2,TF,S).


%%% List of known primitives

% primitive(Atom)
%	The most-general atom Atom has a known primitive predicate.

primitive(Atom) :-
	sysPrim(Atom),!.
primitive(Atom) :-
	known(Atom).

sysPrim(_'='_).		% equality (unifiability)
sysPrim(_'\='_).	% unsound inequality:
			% no substitution can be found to make X and Y the same
sysPrim(_'~='_).	% suspicious inequality:
			% X is not identical to Y now, and never will be
sysPrim(length(_,_)).	% length of a list
sysPrim(append(_,_,_)).	% concatenation of two lists

known('=/='(_,_)).
known(nat(_)).
known(list(_)).
known(add(_,_,_)).
known(mult(_,_,_)).
known(lt(_,_)).
known(gt(_,_)).
known(le(_,_)).
known(ge(_,_)).
known(partition(_,_,_,_)).
known(halves(_,_,_)).
