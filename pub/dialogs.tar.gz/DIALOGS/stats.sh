echo
echo Word count of source files:
cat *.pl | wc
echo
echo Word count of comments in source files:
egrep -h '(%.*$)|(^$)' *.pl | wc
echo
