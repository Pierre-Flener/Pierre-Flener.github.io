%******************************************************************************
%*									      *
%*				 phase0.pl				      *
%*									      *
%*	 	Written by: Serap Yilmaz  (1997)		              *
%******************************************************************************




% d, dialogsII
%	Schema-guided inductive synthesis of a logic program through dialog.

d2 :-   
        ask('Predicate declaration?',"",PredDeclStr),
	myPhrase(pred(Pred,ParamTypes),PredDeclStr),
	schemaGuidedDialogs(Pred,ParamTypes).

schemaGuidedDialogs(Pred,ParamTypes) :-
	findall(S,lpschema(S,_,_,_,_,_,_,_,_,_),SDefaults), %all available schemas
	schemaGuidedDialogs(SDefaults,Pred,ParamTypes).


schemaGuidedDialogs([],_,_) :- writeln('There is no other schema!').

schemaGuidedDialogs([FirstSchema|RestSchema],Pred,ParamTypes) :-
	writeln([FirstSchema|RestSchema]),
        name(FirstSchema,SchemaStr),
	ask('Schema?',SchemaStr,SAnswerStr),
	name(ASchema,SAnswerStr),
	bagof(T,strategy(ASchema,T),TDefaults),
	(schemaGuidedDialogs(ASchema,TDefaults,Pred,ParamTypes) -> 
	 ask('Do you want another synthesis with a different schema?',"yes",AnswerStr), 
	 (AnswerStr="yes" -> schemaGuidedDialogs(RestSchema,Pred,ParamTypes);true);
	 schemaGuidedDialogs(RestSchema,Pred,ParamTypes)).    

schemaGuidedDialogs(Schema,[],_,_) :- write('There is no other strategy for schema '), write(Schema),writeln('!'). 

schemaGuidedDialogs(Schema,[FirstStrategy|RestStrategy],Pred,ParamTypes) :-
	writeln([FirstStrategy|RestStrategy]),
	name(FirstStrategy,FirstStrategyStr),
	ask('Strategy?',FirstStrategyStr,TAnswerStr),
	name(AStrategy,TAnswerStr),
	(dialogsII(Schema,AStrategy,Pred,ParamTypes) -> 
	ask('Do you want another synthesis with a different strategy?',"yes",AnswerStr), 
	 (AnswerStr="yes" -> schemaGuidedDialogs(Schema,RestStrategy,Pred,ParamTypes);true);
	 schemaGuidedDialogs(Schema,RestStrategy,Pred,ParamTypes)). 
%******************************************************************************
%*									      *
%*				 phase0.pl				      *
%*									      *
%*	 	Written by: Serap Yilmaz  (1997)		              *
%******************************************************************************
:- dynamic 'Induction'/2.
:- dynamic 'Result'/2.
:- dynamic 'Passive'/2.
:- dynamic di/2.
:- dynamic 'Accumulation'/2.


% phase0(Pred,ParamTypes,Hints,Info,DPMode,DQMode,OpenPgm)
%	OpenPgm is an open logic program for predicate Pred, whose
%	parameter name:type pairs are ParamTypes.  Hints contains preferences
%	for the parameter roles and the DecR instance of CurrPred.
%	Info contains information about the actual decisions of this phase.


phase0(Schema,Strategy,Pred,ParamTypes,Hints,PRoles,Info,DPMode,DQMode,OpenPgm) :-
       	paramRoles(Pred,ParamTypes,Hints,PRoles,ParamRoles,FormVars),
	findArity(FormVars,Arity),
	(length(ParamTypes,A), A =\= Arity -> fail;
	       (findInfo(ParamRoles,'Induction',[IPinfo]),
		selectDecR(Pred,IPinfo,Hints,DecRinfo,H,T),
	        Info=info(ParamRoles,DecRinfo,Arity,_,_,FormVars),
	  	member(Schema,[dc,dg]), 
		member(Strategy,[divide_and_conquer_strategy1,descend_gen_strategy1]),
		findVars(FormVars,SchemaVars),
	        lpschema(Schema,MetaSchema,_,SchemaVars,[H,T],PMode,QMode,SRArgs,SQArgs,SQCArgs),
		adjustMode(PMode,ParamRoles,PRoles,DPMode),
		correctSchema(MetaSchema,CMetaSchema),
		dedotifyMode(QMode,DQMode),
		dedotifyMetaSchema(Pred,Info,Schema,CMetaSchema,SRArgs,SQArgs,SQCArgs,H,OpenPgm))).




correctSchema(MetaSchema,MetaSchema) :-
	MetaSchema = [_,RecClause],
	lastOpen(RecClause),!.

correctSchema(MetaSchema,CMetaSchema) :-
	MetaSchema = [NonRecClause,RecClause],
	RecClause = if(Head,Body),
	Body = and(Dec,and(Q,Conj)),
	NewBody = and(Dec,and(Conj,Q)),
	NewRecClause = if(Head,NewBody),
	CMetaSchema = [NonRecClause,NewRecClause].

lastOpen(RecClause)  :-
	RecClause = if(_,Body),
	Body = and(_,and(_,Atom)),
	Atom =.. [q|_].

	
        
	



%findArity(FormVars,Arity)

findArity(FormVars,Arity) :-
	findArity(FormVars,Arity,0).

findArity([],Arity,Arity).
findArity([form(_,N)|TFormVars],Arity,Acc) :-
	NewAcc is Acc + N,
	findArity(TFormVars,Arity,NewAcc).

%findPos(ParamRoles,PRole,Pos)

findPos([],_,[]).
findPos([param(PRole,Info)|_],PRole,Pos) :-
	!,extractPos(Info,Pos).

findPos([param(Role,_)|TRoles],PRole,Pos) :-
	Role \== PRole,
	findPos(TRoles,PRole,Pos).


%findInfo(ParamRoles,PRole,Info)

findInfo([param(PRole,Info)|_],PRole,Info) :- !.

findInfo([param(Role,_)|TRoles],PRole,Info) :-
	Role \== PRole,
	findInfo(TRoles,PRole,Info).

%findInfo2(ParamRoles,PRole,Info)

findInfo2([],_,[]).

findInfo2([param(PRole,Info)|_],PRole,Info) :- !.

findInfo2([param(Role,_)|TRoles],PRole,Info) :-
	Role \== PRole,
	findInfo2(TRoles,PRole,Info).






findCount([form(PRole,Count)|_],PRole,Count) :- !.

findCount([form(Role,_)|TForms],PRole,Count) :-
	Role \== PRole,
	findCount(TForms,PRole,Count).

%findHint(Hints,What,Hint)


findHint([hint(What,Hint)|_],What,Hint) :- !.

findHint([hint(What2,_)|THints],What,Hint) :-
        What2 \== What,
	findHint(THints,What,Hint).



%extractPos(Info,Pos)

extractPos([],[]).
extractPos([pi(P,_,_)|TInfo],[P|TPos]) :-
	extractPos(TInfo,TPos).


%findVars(FormVars,SchemaVars)

findVars([form(_,N)],[N]).

findVars([form(_,N)|TFormVars],[N|TSchemaVars]) :-
	findVars(TFormVars,TSchemaVars).


%paramRoles(Pred,ParamTypes,Hints,PRoles,ParamRoles,FormVars)

paramRoles(Pred,ParamTypes,Hints,PRoles,ParamRoles,FormVars):- 
	paramRoles(Pred,ParamTypes,Hints,PRoles,[],ParamRoles,[],FormVars).


paramRoles(_,_,_,[],ParamRoles,ParamRoles,FormVars,FormVars).

paramRoles(Pred,ParamTypes,Hints,[HRole|TRoles],CurrentParamRoles,ParamRoles,CurrentFormVars,FormVars):-
	getInfo(Pred,ParamTypes,HRole,Hints,CurrentParamRoles,ParamRole,FormVar),
	append(CurrentParamRoles,ParamRole,NewRoles),
	append(CurrentFormVars,FormVar,NewFormVars),
	paramRoles(Pred,ParamTypes,Hints,TRoles,NewRoles,ParamRoles,NewFormVars,FormVars).




%getInfo(Pred,ParamTypes,PRole,Hints,CurrentParamRoles,ParamInfo,FormVar) 

getInfo(Pred,ParamTypes,PRole,Hints,CurrentParamRoles,ParamInfo,FormVar) :-
	selectParamDefaults(ParamTypes,PRole,Hints,CurrentParamRoles,ParamDefaults),
	(ParamDefaults = [] -> ParamInfo = [], FormVar = [form(PRole,0)];
        ((member(PRole,['Induction','Result']) ->
	  name(PRole,RoleStr),
          name(' parameter?',PStr);   
	 name(PRole,RoleStr),
	 name(' parameter(s)?',PStr)),
	 append(RoleStr,PStr,QuestionStr),
	 name(Question,QuestionStr),
	 asksParam(Question,PRole,ParamDefaults,ParamDefaults,Pred,ParamTypes,ParamInfo,FormVar))).



%selectParamDefaults(ParamTypes,PRole,Hints,CurrentParamRoles,ParamDefaults)

selectParamDefaults(ParamTypes,PRole,Hints,CurrentParamRoles,ParamDefaults):-
	candidateDefaults(CurrentParamRoles,Names),
	(Hints \== [] ->
        	(paramHints(Hints,PRole,ParamHints), 
	         legalHints(ParamHints,Names,LegalHints),
        	 selectDefaults(ParamTypes,Names,PRole,Defaults),
		 dlgsreverse(Defaults,RDefaults),
		 (length(RDefaults,Len),Len=1 -> PDefaults = RDefaults;
		 mpowerset(RDefaults,PDefaults)),
		 putHintFront(PDefaults,LegalHints,ParamDefaults));
		 selectDefaults(ParamTypes,Names,PRole,Defaults),
		 dlgsreverse(Defaults,RDefaults),
	         mpowerset(RDefaults,ParamDefaults)).

	

%constructInfo(ParamTypes,Names,ParamInfo,N1,N).

constructInfo(_,[],[],N,N).
constructInfo(ParamTypes,[HName|TName],[HInfo|TInfos],N1,N) :-
	constructInfo1(ParamTypes,HName,1,HInfo),
	NewN is N1 +1,
	constructInfo(ParamTypes,TName,TInfos,NewN,N).

constructInfo1([Name:Type|_],Name,N,pi(N,Name,Type)).
constructInfo1([HName:_|TParamTypes],Name,N,Info) :-
	HName \== Name,
	N1 is N +1,
	constructInfo1(TParamTypes,Name,N1,Info).
	


%asksParam(Question,PRole,AllDefaults,Defaults,Pred,ParamTypes,ParamInfo,FormVar)


asksParam(Question,PRole,AllDefaults,Defaults,Pred,ParamTypes,ParamInfo,FormVar) :-
	 Defaults = [Default|_],
         convertdef(Default,DefaultStr),
	 ask(Question,DefaultStr,AnswerStr),
	(AnswerStr = "back" -> !, fail;
			  myPhrase(variablesList(Names),AnswerStr),
			  (Names = [] -> ParamInfo =[], FormVar=[form(PRole,0)];
				        (memberPCheck(AllDefaults,Names) ->
				         Item =.. [PRole|[Pred,Names]],
				         assert(Item),
				         constructInfo(ParamTypes,Names,PInfo,0,FVar),
ParamInfo = [param(PRole,PInfo)],
FormVar = [form(PRole,FVar)]);
	                                 asksParam(Question,PRole,AllDefaults,Defaults,Pred,ParamTypes,ParamInfo,FormVar))).


asksParam(Question,PRole,AllDefaults,Defaults,Pred,ParamTypes,ParamInfo,FormVar):-
	Item =.. [PRole|[Pred,_]],
	(Item -> retract(Item),
	         Item =.. [PRole|[Pred,Names]],
		 (length(Names) = 1 ->
		      (mefface(Names,Defaults,NewDefaults);
		       effaceP(Names,Defaults,NewDefaults)));
		 NewDefaults = Defaults),
        (NewDefaults \== [] ->
		 asksParam(Question,PRole,AllDefaults,NewDefaults,Pred,ParamTypes,ParamInfo,FormVar)).


%candidateDefaults(PRoles,Names)

candidateDefaults([],[]).

candidateDefaults([param(_,InfoList)|TPRoles],Names) :-
	extractNames(InfoList,HNames),
	candidateDefaults(TPRoles,TNames),
	append(HNames,TNames,Names).


%extractNames(Infos,Names)

extractNames([],[]).

extractNames([pi(_,Name,_)|TInfos],[Name|TNames]) :-
	extractNames(TInfos,TNames).



%selectDefaults(ParamTypes,Names,PRole,Defaults)

selectDefaults([],_,_,[]).

selectDefaults([Name:_|TParamTypes],Names,PRole,Defaults) :-
	memberCheck(Names,Name),
	selectDefaults(TParamTypes,Names,PRole,Defaults).

selectDefaults([Name:Type|TParamTypes],Names,PRole,[Name|TDefaults]) :-
	\+(memberCheck(Names,Name)),
	features(PRole,Type),
	selectDefaults(TParamTypes,Names,PRole,TDefaults).

selectDefaults([Name:Type|TParamTypes],Names,PRole,TDefaults) :-
	\+(memberCheck(Names,Name)),
	\+(features(PRole,Type)),
	selectDefaults(TParamTypes,Names,PRole,TDefaults).

%putHintFront(Defaults,Hints,NewDefaults)


putHintFront(Defaults,Hints,[Hints|TDefaults]) :-
	effaceP(Hints,Defaults,TDefaults).
 
%legalHints(ParamHints,Names,LegalHints)

legalHints(ParamHints,Names,LegalHints) :-
	memberPCheck(Names,ParamHints),!,
	LegalHints = [].

legalHints(ParamHints,_,ParamHints).

%paramHints(Hints,PRole,ParamHints)

paramHints([hint(PRole,Names)|_],PRole,Names) :- !.

paramHints([hint(Role,_)|THints],PRole,Names) :- 
	PRole \== Role,
	paramHints(THints,PRole,Names).


% convertdef(Default,DefaultStr)

convertdef(Default,DefaultStr):-
	convertdefaux(Default,TDefaultStr),
	NTDefaultStr = [91|TDefaultStr],
	append(NTDefaultStr,"]",DefaultStr).

convertdefaux([HD],HD) :- !.
convertdefaux([HD|TD],DefaultStr) :-
	convertdefaux(TD,TDStr),
	append(",",TDStr,NTDStr),
	append(HD,NTDStr,DefaultStr).


% effaceP(PN,Tdefaults,TNDefaults)

effaceP(_,[],[]).
effaceP(PN,[N|Tdefaults],TNDefaults) :-
	eqPL(PN,N),
	effaceP(PN,Tdefaults,TNDefaults).
effaceP(PN,[N|Tdefaults],[N|TNDefaults]) :-
	\+(eqPL(PN,N)),
	effaceP(PN,Tdefaults,TNDefaults).


% eqPL(LN1,LN2)

eqPL([],[]).
eqPL(LN1,LN2):-
	LN1 = [_|TN1],
	TN1 = [],
	LN1 = LN2.
eqPL([Name|TN1],LN2) :-
	TN1 \== [],
	efface(Name,LN2,RLN2),
	eqPL(TN1,RLN2).

% memberPCheck(NDefaults,Pnames)


memberPCheck([HL|_],PN) :-
	eqPL(HL,PN).
memberPCheck([HL|TL],PN) :-
	\+(eqPL(HL,PN)),
	memberPCheck(TL,PN).


% mpowerset(As,Ss) iff Ss denotes all subsets of As
% where As is a list and Ss is a list of lists of elements occuring in As.

mpowerset(As,Ss) :-
	findall(S,(msubset(S,As), S \== []),RSs),
	dlgsreverse(RSs,Ss).
	
% subset(S,As) iff S is a subset of As
% where As and S are lists.

msubset([],[]).
msubset(S,[H|T]) :-
	S=[H|V],
	msubset(V,T).
msubset(S,[_|T]) :-
	msubset(S,T).

%mefface(E,L,R) R is list L without its first, existing occurrence of term E,
% if E not exists then R is list L.

mefface(_,[],[]).
mefface(E,[E|R],R).
mefface(E,[HL|TL],[HL|TR]) :-
 	E\==HL,
	mefface(E,TL,TR).


%features(PRole,Type)

features('Induction',Type) :-
	inductivetype(Type).

features('Result',Type) :-
	inductivetype(Type).

features('Passive',_).

features('Accumulation',Type) :-
	inductivetype(Type).



inductivetype(Type):-
	(Type = list(_);
	 Type = nat;
	 Type = int).




%******************************************************
%   Predicates related to SelectDecR
%******************************************************

% selectDecR(Pred,IPinfo,Hints,DecRinfo,HX,T)

selectDecR(Pred,IPInfo,Hints,DecRinfo,HX,T) :-
	IPInfo = pi(N,IPname,Type),
	paramHints(Hints,decr,HDecR),
	paramHints(Hints,'Induction',[IPName]),
	IPName = IPname,
	HDecR \== [],
	check_selectDecRdefaults(pi(N,IPname,Type),HDecR,DecRDefaults),
	asksDecR('Decomposition Operator?',DecRDefaults,
	          Pred,pi(N,IPname,Type),DecRinfo,HX,T).

selectDecR(Pred,IPinfo,_,DecRinfo,HX,T) :-
	check_selectDecRdefaults(IPinfo,true,DecRDefaults),
	asksDecR('Decomposition Operator?',DecRDefaults,
	               Pred,IPinfo,DecRinfo,HX,T).


% checkeqDecR(DecR1,DecR2,Args1,Arg2) holds iff DecR2 is a variant
%	of DecR1 where both are conjunctions and their variables
%	are instantiated to alphabetic atoms and Args are the arguments of
%	DecR1 and DecR2 respectively.
%	mode(+,+,?,?)
%	checkeqDecR(and(headtail('Ayse',['Naber'],'iyilik'),
%	partition('iyilik','Naber','optum','bye')),
%	and(headtail('L',['HL'],'TL'),partition('TL','HL','TL1','TL2')),L1,L2).

checkeqDecR(true,true,[],[]) :-!.
checkeqDecR(Literal1,Literal2,Arglist1,Arglist2) :-
	functor(Literal1,F1,N1),
	F1\==and,!,
	functor(Literal2,F2,N2),
	F2=F1,
	N1=N2,
	constituents2(Literal1,Arglist1),
	constituents2(Literal2,Arglist2),
	checkeqArgs(Arglist1,Arglist2).
checkeqDecR(and(Conj11,Conj12),and(Conj21,Conj22),Arglist1,Arglist2) :-
	checkeqDecR(Conj11,Conj21,Arglist11,Arglist21),
	checkeqDecR(Conj12,Conj22,Arglist12,Arglist22),
	append(Arglist11,Arglist12,Arglist1),
	append(Arglist21,Arglist22,Arglist2),
	checkeqArgs(Arglist1,Arglist2).


% checkeqArgs(Args1,Args2) holds iff elements of list Args1 is
%	a variant of list Args2.
%	mode(+,+)

checkeqArgs([],[]).
checkeqArgs([Arg1|RestArgs1],[Arg2|RestArgs2]) :-
	positions(Arg1,RestArgs1,Ps),
	positions(Arg2,RestArgs2,Ps),
	checkeqArgs(RestArgs1,RestArgs2).

%check_selectDecRdefaults(IPinfo,HDecR,DecRDefaults)

check_selectDecRdefaults(pi(_,IPname,Type),HDecR,DecRDefaults) :-
	finddefaultDecR(Type,TDecRDefaults),
	name(Name,IPname),
        (HDecR \== true -> HDecR=[HDecRin],DecRDefaults=[decRdef(HDecRin,_)];
	                  changeDecRDefaults(Name,TDecRDefaults,DecRDefaults)).

% changeDecRDefaults(Name,TDecRDefaults,DecRDefaults)

changeDecRDefaults(_,[],[]).
changeDecRDefaults(Name,[decRdef(Def,IP)|TDecRDefaults],
			[decRdef(Def1,Name)|TDecRDefaults1]) :-
	changeName(Name,Def,Def1,IP),
	changeDecRDefaults(Name,TDecRDefaults,TDecRDefaults1).



changeName(_,true,true,_).
changeName(Name,Literal1,Literal2,IP) :-
	Literal1 =.. [F1|_],
	F1 \== and,
	changeNameL(Name,Literal1,Literal2,IP).

changeName(Name,and(Conj1,Conj2),ConjR,IP) :-
	changeName(Name,Conj1,ConjR1,IP),
	changeName(Name,Conj2,ConjR2,IP),
	ConjR = and(ConjR1,ConjR2).

changeNameL(Name,Literal1,Literal2,IP) :-
	Literal1 =.. [F1|Args1],
	changeNameaux(Name,Args1,Args2,IP),
	Literal2 =.. [F1|Args2].

changeNameaux(_,[],[],_).

changeNameaux(Name,[HA1|TA1],[HA2|TA2],IP) :-
	atomic(HA1), HA1 \== [],!,
	changeIP(Name,IP,HA1,HA2),
	changeNameaux(Name,TA1,TA2,IP).
changeNameaux(Name,[HA1|TA1],[HA2|TA2],IP) :-
	\+(atomic(HA1)),
	functor(HA1,_,N), N>0,!,
	changeName(Name,HA1,HA2,IP),
	changeNameaux(Name,TA1,TA2,IP).
changeNameaux(Name,[HA1|TA1],[HA2|TA2],IP) :-
	list(HA1),
	changeNameaux(Name,HA1,HA2,IP),
	changeNameaux(Name,TA1,TA2,IP).

changeIP(Name,IP,HA1,HA2):-
	name(Name,Nname),
	name(IP,[Ipname]),
	name(HA1,SHA1),
	changeinlist(SHA1,Ipname,Nname,SHA2),
	name(HA2,SHA2).

%changeinlist("HL1",'L',"List",HList1").
changeinlist([],_,_,[]).
changeinlist([H1|T1],H,NH,L2):-
	H1 = H,
	changeinlist(T1,H,NH,T2),
	append(NH,T2,L2).
changeinlist([H1|T1],H,NH,[H1|T2]):-
	H1 \== H,
	changeinlist(T1,H,NH,T2).

%asksDecR(Question,AllDecRDefaults,DecRDefaults,Pred,IPinfo,DecRinfo,HX,T) 

asksDecR(Question,DecRDefaults,Pred,IPinfo,DecRinfo,HX,T) :-
	(DecRDefaults \==[] -> 
	     (DecRDefaults=[decRdef(Default,_)|_],
	      convertdefDecR(Default,DefaultStr));
		   DefaultStr = []),
          ask(Question,DefaultStr,AnswerStr), 
	 (AnswerStr = "back" -> !, DecRinfo = AnswerStr, fail;
	      (myPhrase(decomposition(Decomp),AnswerStr),
	       Decomp = <--(_,DecR),
	       constructDecRinfo(IPinfo,DecR,DecRinfo,HX,T),
	       IPinfo = pi(_,IP,_),
	       name(IPname,IP),
	       DecRdef = decRdef(Decomp,IPname),
	       assert(di(Pred,DecRdef)))).

asksDecR(Question,DecRDefaults,Pred,IPinfo,DecRinfo,HX,T) :- 
	 retract(di(Pred,ODecRdef)),
   	 effaceDecR(ODecRdef,DecRDefaults,NewDecRDefaults),
         asksDecR(Question,NewDecRDefaults,Pred,IPinfo,DecRinfo,HX,T).


%constructDecRinfo(IPinfo,DecR,DecRinfo,HX,T)

constructDecRinfo(IPinfo,DecR,decRinfo(NDecR,HLs,TLs),HX,T):-
	constructauxDecRinfo(IPinfo,DecR,decRinfo(NDecR,HLs,TLs)),
	length(HLs,HX),
	length(TLs,T).


%constructauxDecRinfo(IPinfo,DecR,decRinfo(NDecR,HLs,TLs))

constructauxDecRinfo(pi(_,Name,Type),DecR,DecRinfo):-
	name(NName,Name),
	checkName(NName,DecR),
	getHTs(Name,DecR,SHLs,STLs),
	checkinHs(Name,SHLs,NSHLs),
	checkinTs(Name,STLs,NSTLs),
	headType(pi(_,Name,Type),HType),
	Types = types(HType,Type),
	varDecRinfo(DecR,NSHLs,NSTLs,Types,DecRinfo).

checkinHs(Name,SLs,NSLs):-
	length(SLs,L), L < 2 -> NSLs = SLs ;
	              checkinHsaux(Name,SLs,NSLs).

checkinTs(Name,SLs,NSLs):-
	length(SLs,L), L < 2 -> NSLs = SLs ;
	              checkinTsaux(Name,SLs,NSLs).

checkinHsaux(Name,[H1|T1],L2):-
	H1 = [72|Name] -> L2 = T1;
	                  L2 = [H1|T1].
checkinTsaux(Name,[H1|T1],L2):-
	H1 = [84|Name] -> L2 = T1;
	                  L2 = [H1|T1].

headType(pi(_,_,list(T)),T):-!.
headType(pi(_,_,Type),T):- T=Type.	

checkName(Name,Literal):-
	Literal =.. [Pred|TLArgs],
	Pred \== and,
	findArgs(TLArgs, LArgs),
	memberCheck(LArgs,Name).
checkName(Name,and(Conj1,Conj2)):-
	(\+checkName(Name,Conj1)) ->
	    checkName(Name,Conj2); 
	            true.

varDecRinfo(DecR,SHLs,STLs,types(HType,TType),decRinfo(VDecR,HInfos,TInfos)):-
	varArgs(SHLs,HLs,HType,HInfos),
	varArgs(STLs,TLs,TType,TInfos),
	varDecR(SHLs,HLs,DecR,TVDecR),
	varDecR(STLs,TLs,TVDecR,VDecR).

varArgs([],[],_,[]).
varArgs([H1|T1],[H2|T2],Type,[HI|TI]):-
	var(H2),
	HI = pi(H2,H1,Type),
	varArgs(T1,T2,Type,TI).

varDecR([],[],NDecR,NDecR).
varDecR([SH|ST],[VH|VT],DecR,VDecR):-
	name(H,SH),
	varauxDecR(DecR,TDecR,H,VH),
	varDecR(ST,VT,TDecR,VDecR).

%varauxDecR(true,true,_,_).
varauxDecR(Literal,NLiteral,H,VH):-
	functor(Literal,_,0),
	H = Literal,
	NLiteral = VH.

varauxDecR(Literal,NLiteral,H,_):-
	functor(Literal,_,0),
	H \== Literal,
	NLiteral = Literal.

varauxDecR(Literal,NLiteral,H,VH):-
	functor(Literal,Pred,N), N > 0,
	Pred \== and,
	Literal =.. [Pred|Args],
	varauxDecR1(Args,NArgs,H,VH),
	NLiteral =.. [Pred|NArgs].

varauxDecR(and(Conj1,Conj2),and(NConj1,NConj2),H,VH):-
	varauxDecR(Conj1,NConj1,H,VH),
	varauxDecR(Conj2,NConj2,H,VH).

varauxDecR1([],[],_,_).
varauxDecR1([H1|T1],[H2|T2],H,VH):-
	(\+var(H1), H1 \==[] ->
	    varauxDecR(H1,H2,H,VH) ;
	    H2 = H1),
	varauxDecR1(T1,T2,H,VH).

%getHTs("L",moto('L','HL','TL'),["HL"],["TL"]).

getHTs(_,true,[],[]).

getHTs(Name,Literal,SHLs,STLs) :-
	Literal =.. [Pred|TLArgs], 
	Pred \== and,
	findArgs(TLArgs,LArgs),
	stringArgs(LArgs,SLArgs),
	checkHs(Name,SLArgs,USHLs),
	checkTs(Name,SLArgs,USTLs),
	sort(USHLs,SHLs),
	sort(USTLs,STLs).

getHTs(Name,and(Conj1,Conj2),SHLs,STLs) :-
	getHTs(Name,Conj1,SHL1s,STL1s),
	getHTs(Name,Conj2,SHL2s,STL2s),
	append(SHL1s,SHL2s,USHLs),
	sort(USHLs,SHLs),
	append(STL1s,STL2s,USTLs),
	sort(USTLs,STLs).

findArgs([],[]).
findArgs([H1|T1],LArgs):-
	  functor(H1,_,0), 
          LArgs = [H1|TLArgs],
	  findArgs(T1,TLArgs).

findArgs([H1|T1],LArgs):-
	functor(H1,P,N), N =\= 0,
	  H1 =.. [P|H1Args],
	  findArgs(H1Args,TH1Args),
	  findArgs(T1,TLArgs),
	  append(TH1Args,TLArgs,LArgs).

stringArgs([],[]).
stringArgs([H|T],[HS|TS]):-
	name(H,HS),
	stringArgs(T,TS).

checkHs(_,[],[]).
checkHs(Name,[HSArg|TSArgs],[HSArg|TSHLs]):-
	eqbegin(HSArg,[72|Name]),!,
	checkHs(Name,TSArgs,TSHLs).

checkHs(Name,[_|TSArgs],SHLs):-
	checkHs(Name,TSArgs,SHLs).	

checkTs(_,[],[]).
checkTs(Name,[HSArg|TSArgs],[HSArg|TSTLs]):-
	eqbegin(HSArg,[84|Name]),!,
	checkTs(Name,TSArgs,TSTLs).
checkTs(Name,[_|TSArgs],STLs):-
	checkTs(Name,TSArgs,STLs).	

eqbegin(_,[]).
eqbegin([H1|T1],[H1|T2]):-
	eqbegin(T1,T2).


% effaceDecR(DecRinfo,NDecRDefaults,NewDecRDefaults)

effaceDecR(_,[],[]).
effaceDecR(DecRinfo,[Def|TNDefaults],NDefaults) :-
	DecRinfo=decRdef(DecR,_),
	Def=decRdef(DDecR,_),
	cutify(DecR,CutDecR,_),
	cutify(DDecR,CutDDecR,_),
	checkeqDecR(CutDecR,CutDDecR,_,_),!,
	effaceDecR(DecRinfo,TNDefaults,NDefaults).
effaceDecR(DecRinfo,[Def|TNDefaults],[Def|TNNDefaults]) :-
	effaceDecR(DecRinfo,TNDefaults,TNNDefaults).


% puthintDecR(HDecR,DecRDefaults,NDecRDefaults)

 puthintDecR(HDecR,DecRDefaults,NDecRDefaults) :-
	effacehintDecR(HDecR,DecRDefaults,RDecRDefaults,DecRinfo),
 	NDecRDefaults=[DecRinfo|RDecRDefaults].
	
effacehintDecR(HdecR,DecRDefaults,RDecRDefaults,DecRinfo) :-
	memberDecRCheck(DecRDefaults,HdecR,DecRinfo),
	effaceDecR(DecRinfo,DecRDefaults,RDecRDefaults).

	
% finddefaultDecR(Type,DecRDefaults)

finddefaultDecR(Type,DecRDefaults) :-
	(bagof(decRdef(DecR,IP),Type^decPrim(DecR,Type,
				IP),DecRDefaults);
	DecRDefaults = []).


% convertdefDecR(Default,DefaultStr).

convertdefDecR(Literal,DefaultStr) :-
	nameDecr(Literal,DefaultStr).

nameDecr(true,"true").
nameDecr(CuteL,DefaultStr) :-	
	functor(CuteL,F,_),
	F \== and,
	nameDecRL(CuteL,DefaultStr).

nameDecr(and(Conj1,Conj2),DefaultStr):-
	nameDecr(Conj1,Conj1Str),
	(Conj2 \== true -> (nameDecr(Conj2,Conj2Str),
				append(",",Conj2Str,TempConj2Str),
				append(Conj1Str,TempConj2Str,DefaultStr));
			DefaultStr = Conj1Str).

nameDecRL(CuteL,DefaultStr):-
	functor(CuteL,F,N),
	(F = headtail -> 
		(CuteL =.. [F|Args],
		Args=[A1,A2,A3],
		name(A1,A1Str),
		namelist(A2,A2Str),
		name(A3,A3Str),
		append(A1Str,"=[",T1),
		append(A2Str,"|",T2),
		append(T1,T2,T3),
		append(A3Str,"]",T4),
		append(T3,T4,DefaultStr));
		(name(F,FStr),
		argstring(CuteL,N,1,ArgStr),
		(infunct2(F) -> (CuteL =.. [F|Args],
		                 Args = [A1,A2],
				 nameS(A1,AS1),
				 nameS(A2,AS2),
		                 append(AS1,FStr,FTStr),
				 append(FTStr,AS2,DefaultStr));
		               ( 
                                argstring(CuteL,N,1,ArgStr),
				append(FStr,"(",FTStr),
		                append(ArgStr,")",ATStr),
		                append(FTStr,ATStr,DefaultStr))))).

%%%%%%%%%%%%%%%%%%Attention!!!!

%infunct2(F) :- F='=';
%	      F='\=';
%	      F='~=';
%	      F='=/='.

infunct2(F) :- F='=';
	      F='=\=';
	      F='\==';
              F='=/=';
	      F='<--'.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

namelist([],[]).
namelist([H],Str) :- !, 
	name(H,Str).
namelist([H|TL],Str) :-
	name(H,HStr),
	namelist(TL,TStr),
	append(",",TStr,Temp),
	append(HStr,Temp,Str).

nameS(L,S) :-
	functor(L,_,0),
	name(L,S).
nameS(L,S):-
	functor(L,_,N),
	N>0,
	nameDecRL(L,S).

argstring(Literal,1,Nth,ArgString) :-!,
	arg(Nth,Literal,A),
	nameS(A,ArgString).

argstring(Literal,N,Nth,ArgString) :- 
	arg(Nth,Literal,A),
	nameS(A,NthArg),
	Nnew is N-1,
	Nthnew is Nth+1,
	argstring(Literal,Nnew,Nthnew,TArgString),
	append(NthArg,",",NthTemp),
	append(NthTemp,TArgString,ArgString).



%***********************************************************
% Predicates related to instantiation of template
%    Written by: Serap Yilmaz (14 May 1996)
%***********************************************************

%converttoname(L,N)
%N is list of the names of the strings in the term of the form 
%rp(Position,Name,Type) in list L.
%mode(+,?)

converttoname([],[]):- !.
converttoname([H|T],[H2|T2]) :-
	arg(2,H,NameStr), %'Result'(Position,Name,Type)
	name(H2,NameStr),
	converttoname(T,T2).


%instantparamnames(ParamNames,Term,Term2)
%e.g Term=foo(X,Y,Z,T)
%e.g ParamNames=['A','B','C','D']
%e.g Term2=foo('A','B','C','D')
%mode(+,+,?)

instantparamnames(ParamNames,Term,Term2) :-
	instantparamnames(ParamNames,Term,1,Term2).

instantparamnames([],Term,_,Term).
instantparamnames([Name|Rest],Term,Count,Head) :-
	arg(Count,Term,Name),
	NewCount is Count + 1,
	instantparamnames(Rest,Term,NewCount,Head).

%processterm(Pos,Term,SubTerms)
%Term with at positions Pos is instantiated
%with Subterms
%mode(+,+,+),(+,-,+),(+,+,+)
 
processterm([],_,[]).
processterm([Pos1|RestPos],Term,[SubTerm1|RestSub]) :-
	arg(Pos1,Term,SubTerm1),
	processterm(RestPos,Term,RestSub).


%recursivecalls(ListofTX,Pred,Arity,APs,IPpos,APpos,Listofreccalls) 
%Listofreccalls is the list of recursive calls constituted of
%predicates whose name is Pred, arity is Arity, and parameters are
%determined according to the positions of IPpos and APpos
%mode(+,+,+,+,+,?)


recursivecalls([],_,_,_,_,_,[]).
recursivecalls([HTX|TTX],Pred,Arity,APs,IPpos,APpos,[RecCall|RestRecCalls]) :-
	functor(Term,Pred,Arity),	%construct pred(_,_,_,...,_)
	arg(IPpos,Term,HTX), % instantiate first arg by HTX
	processterm(APpos,Term,APs,RecCall),
	recursivecalls(TTX,Pred,Arity,APs,IPpos,APpos,RestRecCalls).


%collectvars(PosList,Reccalls,Vars)
%Vars is the columnwise listed result parameters of Reccalls
%mode(+,+,?)

collectvars([],_,[]).
collectvars([Count|Rest],Reccalls,Vars) :-
	columnwisecollect(Reccalls,Count,Vars1),
	collectvars(Rest,Reccalls,Vars2),
	append(Vars1,Vars2,Vars).


%columnwisecollect(Reccalls,Count,Vars1)
%Vars1 is the list of variables at the Countth position of recursive
%calls
%mode(+,+,?)

columnwisecollect([],_,[]). 
columnwisecollect([H|T],Count,Vars1) :-
	arg(Count,H,A),
	columnwisecollect(T,Count,Varlist),
	append([A],Varlist,Vars1).


%collectArgs(Atom,Pos,Args) iff Args is the list of terms of atom Atom
%at positions Pos.

collectArgs(_,[],[]).
collectArgs(Atom,[Pos|T],[Arg1|Rest]) :-
	arg(Pos,Atom,Arg1),
	collectArgs(Atom,T,Rest).

%makeconj(Literallist,Conj)
%makes a conjunction Conj built outof the literal list Literal
%mode(+,?) or (-,+) 

makeconj([],true).
makeconj([Literal],Literal) :- !.
makeconj([HLiteral1,HLiteral2|Rest],and(HLiteral1,Conj)) :-
	makeconj([HLiteral2|Rest],Conj).

%replaceatom(Term1,Atom,Var,Term2) 
%Term2 is Term1 in which the first occurrence of Atom is replaced by Var
%mode(?,+,+,+) or (+,+,+,?)

replaceatom(Atom,Atom,Var,Var) :-
	atom(Atom),
	var(Var),!.
replaceatom(Term1,Atom,Var,Term2) :-
	Term1 \== Atom,
	Term1 =..[F|Ts1],
	replaceatomaux(Ts1,Atom,Var,Ts2),
	Term2 =..[F|Ts2].

replaceatomaux([],_,_,[]).
replaceatomaux([T1|Ts1],Atom,Var,[T2|Ts2]) :-
	\+var(T1),!,
	replaceatom(T1,Atom,Var,T2),
	replaceatomaux(Ts1,Atom,Var,Ts2).
replaceatomaux([T1|Ts1],Atom,Var,[T1|Ts2]) :-
	replaceatomaux(Ts1,Atom,Var,Ts2).


%replaceatoms(Term1,Atoms,Vars,Term2)

replaceatoms(Term1,[],[],Term1).
replaceatoms(Term1,[Atom1|TAtoms],[Var1|TVars],Term2) :-
	replaceatom(Term1,Atom1,Var1,Term3),
	replaceatoms(Term3,TAtoms,TVars,Term2).





%convertconjht(Conj,NewConj)
%NewConj is Conj in which any literal whose functor is "headtail"
%is replaced by the equality "="
%e.g. convertconjht(headtail(L,[H],T),L=[H|T])
%mode(+,+)

convertconjht(true,true).
convertconjht(headtail(L,Hs,T), L = L1 ):-
	append(Hs,T,L1).
convertconjht(Literal,Literal):- 
	functor(Literal,P,_), 
	P \== and, P \== headtail.
convertconjht(and(Conj1,Conj2),and(NConj1,NConj2)) :-
	convertconjht(Conj1,NConj1),
	convertconjht(Conj2,NConj2).

%conversion for new format of HeadInfos,TailInfos called in instTemplate 

convertPIs([],[]).

convertPIs([H1|T1], [H2|T2]):-
	H2 = pi(H1,_,_),
	convertPIs(T1,T2).

%instParamConj(Conj,Terms,Pos) iff Terms are unified with the variables
%at positions Pos of (flat) conjunction Conj.

instParamConj(Conj,Terms,Pos) :- 
	Conj =.. [F|_],
	F \== and,!,
	instArgs(Conj,Terms,Pos).

instParamConj(Conj,Terms,Pos) :- 
	Conj=and(SubConj1,SubConj2),
	instParamConj(SubConj1,Terms,Pos),
	instParamConj(SubConj2,Terms,Pos).

%instArgs(Term,Terms,Pos) iff Terms are unified with the terms of Term
%at positions Pos.

instArgs(_,_,[]).

instArgs(Term,[H|T],[Pos|RestPos]) :-
	arg(Pos,Term,H),
	instArgs(Term,T,RestPos).


%instParamConj2(Conj,Terms,Pos) iff ith term in Terms is unified with
%the Term at the argument position Pos of ith literal of (flat)
%conjunction Conj.

instParamConj2(_,[],_).

instParamConj2(Conj,[Term],Pos) :-
	Conj =.. [F|_],
	F \== and,!,
	arg(Pos,Conj,Term).

instParamConj2(Conj,Terms,Pos) :- 
	Conj=and(Literal,SubConj2),
	Terms=[Term1|RestTerms],
	instParamConj2(Literal,[Term1],Pos),
	instParamConj2(SubConj2,RestTerms,Pos).


%collectLiterals(Conj,Literals) iff Literals is the ordered list of
%literals appearing in (flat) conjunction Conj.

collectLiterals(Conj,[Conj]) :-
	Conj =.. [F|_],
	F \== and,!.

collectLiterals(Conj,[Literal1|SubLiterals]) :-
	Conj=and(Literal1,Conj2),
	collectLiterals(Conj2,SubLiterals).
	
%genNumber(S,N,Nums) iff list Nums is the ordered list of natural
%numbers between S+1 and S+N inclusive.

genNumber(S,N,Nums) :-
	genNumber(S,N,1,Nums).

genNumber(_,N,F,[]) :- F>N, !.
genNumber(S,N,Acc,[Num|RestNum]) :-
	Num is S+1,
	NewAcc is Acc +1,
	genNumber(Num,N,NewAcc,RestNum).

	



dedotifyMetaSchema(Pred,Info,SchemaName,MetaSchema,RArgs,QArgs,QCArgs,H,OpenPgm) :-
	Info=info(ParamRoles,DecRinfo,_,_,_,_),
	giveName(SchemaName,MetaSchema,Pred,PMetaSchema), %replace the name of
					       %the relation "r" by
					       %"Pred".
       	dedotify(PMetaSchema,DPMetaSchema),
       	DPMetaSchema=[_,Clause2], %instantiate the induction parameter of decompose to the one in Head
	Clause2=if(Head,Body),
	Body=and(Decompose,_),
	findPos(ParamRoles,'Induction',[IPPos]),
	collectArgs(Head,[IPPos],[IPVar]),
	arg(1,Decompose,IPVar),
	placeVarsConj(Body,Head,Decompose,ParamRoles,RArgs,QArgs,QCArgs,H), %replace the dummy variables of DPMetaSchema by the actual var.s ('Result','Passive'...) in Head
	DecRinfo = decRinfo(DecR,HeadInfos,TailInfos), %construct a decompose clause to add DPMetaSchema
	findInfo(ParamRoles,'Induction',IPInfo),
	IPInfo =[pi(_,NameStr,_)],
	name(Name,NameStr),
	replaceatom(DecR,Name,AVar,DecompBody),
	convertconjht(DecompBody,NewDecompBody),
        replaceatom(NewDecompBody,'T',_,TNewDecompBody), %incase of halves, partition
	replaceatoms(TNewDecompBody,['H1','H2','H3','H4'],[_,_,_,_],HTNewDecompBody),
	/*DecRAtom =.. [DPred|_],
	(member(DPred,[halves]) -> 
	 convertPIs(ListTX,TailInfos),
	 ListHXTX=ListTX,writeln(dechere);*/
	 convertPIs(ListHX,HeadInfos),
	 convertPIs(ListTX,TailInfos),
	append(ListHX,ListTX,ListHXTX),
	name(Pred,PredStr),
	name(decompose,DStr),
	name('_',UStr),
	append(DStr,UStr,DUStr),
	append(DUStr,PredStr,DStr2),
	name(DName,DStr2),
	DecompHead =.. [DName|[AVar|ListHXTX]],
	DecompClause = if(DecompHead,HTNewDecompBody),
	append(DPMetaSchema,[DecompClause],OpenPgm).
	
	


%placeVars(Atom,Atom2,ParamRoles,Args) iff variables of Atom are instantiated to 
%the variables of Atom2 (the variables of a certain parameter role, e.g. 'Induction, 'Result', 'Accumulation') 
%where the positions of the variables in Atom are determined by 
%using the schema parameter Args and parameter roles ParamRoles.  
%This procedure is used to instantiate the 'Result','Passive','Accumulation' etc (parameters that are not 
%induction parameters) variables of the recursive calls.
	
placeVars(_,_,_,[]).

placeVars(Atom,Atom2,ParamRoles,[Arg1|TArgs]) :-
	Arg1 =.. [_|Args2],
	Args2 = [Role,_],
	findPos(ParamRoles,Role,Pos), %Param. positions  
        Pos \== [],!,
	collectArgs(Atom2,Pos,Vars),
	placeVars2(Atom,Pos,Vars),
	placeVars(Atom,Atom2,ParamRoles,TArgs).

placeVars(Atom,Atom2,ParamRoles,[_|TArgs]) :-
	placeVars(Atom,Atom2,ParamRoles,TArgs).


placeVars1(_,_,[]).

placeVars1(Atom,Pos,[HVar|TVars]) :-
	arg(Pos,Atom,HVar),
	NewPos is Pos +1,
	placeVars1(Atom,NewPos,TVars).


%placeVars2(Atom,Pos,Vars)

placeVars2(_,[],[]).

placeVars2(Atom,[HPos|TPos],[HVar|TVars]) :-
	arg(HPos,Atom,HVar),
	placeVars2(Atom,TPos,TVars).
	
%placeVars3(Atom,Atom2,ParamRoles,QArgs) 

placeVars3(_,_,_,[]).

placeVars3(Atom,Atom2,ParamRoles,[HQArgs|TQArgs]) :-
	HQArgs =.. [_|Args2], 
        Args2 = [Role,StartPos],
	findPos(ParamRoles,Role,Pos),
	Pos \== [],!,
	collectArgs(Atom2,Pos,Vars),
	NewStartPos is StartPos +1,
	placeVars1(Atom,NewStartPos,Vars),
	placeVars3(Atom,Atom2,ParamRoles,TQArgs).

placeVars3(Atom,Atom2,ParamRoles,[_|TQArgs]) :-
	placeVars3(Atom,Atom2,ParamRoles,TQArgs).




%collectArgs2(Atom,Pos,Terms) iff Terms is the list of terms in the positions starting with Pos+1 in Atom.

collectArgs2(Atom,Pos,Terms) :-
	Atom =..[_|Args],
	collectArgs21(Args,Pos,1,Terms).

collectArgs21(Args,Pos,Pos,Args).
collectArgs21([_|T],Pos,Acc,Terms) :-
	NewAcc is Acc+1,
	collectArgs21(T,Pos,NewAcc,Terms).






%placeVarsConj(Body,Head,Decompose,ParamRoles,RArgs,QArgs,QCArgs,H) 

placeVarsConj(Body,Head,Decompose,ParamRoles,RArgs,QArgs,QCArgs,H) :-
	Body = and(_,Conj),
	Conj = and(RecCallConj,QAtom),
	collectLiterals(RecCallConj,RecLiterals),
	placeVarsLiterals(RecLiterals,Head,ParamRoles,RArgs), %inst. y,z
	placeVarsLiterals2(RecLiterals,Decompose,ParamRoles,H), %inst.tx
	placeVarsLiterals3(RecLiterals,QAtom,ParamRoles,QCArgs), %inst. ty's
	placeVars3(QAtom,Head,ParamRoles,QArgs). %inst. y,z,acc



%placeVarsLiterals(Literals,Atom,ParamRoles,RArgs)

placeVarsLiterals([],_,_,_).
placeVarsLiterals([HLiteral|TLiterals],Atom,ParamRoles,RArgs) :-
	placeVars(HLiteral,Atom,ParamRoles,RArgs),
	placeVarsLiterals(TLiterals,Atom,ParamRoles,RArgs).


%placeVarsLiterals2(Literals,Atom,ParamRoles,H) iff the induction parameter of each 
%literal in Literals is instantiated to the variables of Atom such that the variables 
%starting from position i are instantiated to the induction variables of Literals one
%by one. This procedure is to instantiate the variables TX of Decompose-r to the 
%induction parameters of recursive calls.



placeVarsLiterals2(Literals,Atom,ParamRoles,H) :-
        StartPos is H+1+1, %since there is an induction param.
	collectArgs2(Atom,StartPos,Vars),
	findPos(ParamRoles,'Induction',[Pos]),
	placeVarsLiterals21(Literals,Pos,Vars).

placeVarsLiterals21([],_,[]).

placeVarsLiterals21([HLiteral|TLiterals],Pos,[HVar|TVars]) :-
	arg(Pos,HLiteral,HVar),
	placeVarsLiterals21(TLiterals,Pos,TVars).
	





%placeVarsLiterals3(Literals,Atom,ParamRoles,QArgs) iff variables of Atom are
%instatiated to the variables of Literals, where the variables of Literals are selected
%by using ParamRoles and the positions of the variables in QAtom is determined using the 
%schema parameter QArgs.
%This procedure is used to instantiate the variables of open relation q in the 
%recursive clause using the variables of recursive calls, where the variables of 
%recursive calls are columnwisely collected.   

placeVarsLiterals3(_,_,_,[]).
placeVarsLiterals3(Literals,Atom,ParamRoles,[HQArgs|TQArgs]) :-
	HQArgs =..[_|Args],
	Args = [Role,StartPos],
	Role = ty,!,
	findPos(ParamRoles,'Result',Pos),
	collectvars(Pos,Literals,Vars),
	NewStartPos is StartPos+1,
	placeVars1(Atom,NewStartPos,Vars),
	placeVarsLiterals3(Literals,Atom,ParamRoles,TQArgs).
placeVarsLiterals3(Literals,Atom,ParamRoles,[HQArgs|TQArgs]) :-
	HQArgs =..[_|Args],
	Args = [Role,StartPos],
	Role = tx,!,
	findPos(ParamRoles,'Induction',Pos),
	collectvars(Pos,Literals,Vars),
	NewStartPos is StartPos+1,
	placeVars1(Atom,NewStartPos,Vars),
	placeVarsLiterals3(Literals,Atom,ParamRoles,TQArgs).
placeVarsLiterals3(Literals,Atom,ParamRoles,[HQArgs|TQArgs]) :-
	HQArgs =..[_|Args],
	Args = [Role,StartPos],
	Role = 'Accumulation',!,
	findPos(ParamRoles,'Accumulation',Pos),
	collectvars(Pos,Literals,Vars),
	NewStartPos is StartPos+1,
	placeVars1(Atom,NewStartPos,Vars),
	placeVarsLiterals3(Literals,Atom,ParamRoles,TQArgs).
placeVarsLiterals3(Literals,Atom,ParamRoles,[_|TQArgs]) :-
        placeVarsLiterals3(Literals,Atom,ParamRoles,TQArgs).




giveName(SchemaName,MetaSchema,Pred,PMetaSchema) :-
	MetaSchema=[Clause1,Clause2],
	Clause1=if(Head1,Body1),
	Head1 =.. [_|Args1],
	NewHead1 =.. [Pred|Args1],        %construct head Pred(...) of the non-recursive clause
	name(Pred,PredStr),            %construct  p_Pred(...) of the non-recursive clause
	p(SchemaName,PName),       
	name(PName,PStr),
	name('_',UStr),
	append(PStr,UStr,PUStr),
	append(PUStr,PredStr,PPredStr),
	name(PPredName,PPredStr),
	Body1 =.. [_|ArgsP],
	NewBody1 =.. [PPredName|ArgsP],
	NewClause1=if(NewHead1,NewBody1),
	Clause2=if(_,Body2),
	Body2=and(Decomp,and(ConjAtoms,QLiteral)), %construct Pred(...), namely recursive call meta-atom
	ConjAtoms=conjatoms(R,LB,UB),
	R =.. [_|Args3],
	NewR =.. [Pred|Args3],
	NewConjAtoms=conjatoms(NewR,LB,UB),
	q(SchemaName,QName),                                  %construct q_Pred(...) of the recursive clause
	name(QName,QStr),
	append(QStr,UStr,QUStr),
	append(QUStr,PredStr,QPredStr),
	name(QPredName,QPredStr),
	QLiteral =.. [_|ArgsQ],
	NewQ =.. [QPredName|ArgsQ],
	Decomp =.. [_|DecArgs],                    %construct decompose_Pred(...) 
	name(decompose,DecStr),
	append(DecStr,UStr,DecUStr),
	append(DecUStr,PredStr,NewDecStr),
	name(DecName,NewDecStr),
	NewDecomp =.. [DecName|DecArgs],
	NewBody2=and(NewDecomp,and(NewConjAtoms,NewQ)),
	NewClause2=if(NewHead1,NewBody2),   %heads of two clauses are the same 
        PMetaSchema=[NewClause1,NewClause2].

placeDecompOp(PMetaSchema,DecRinfo,IPinfo,DecPMetaSchema) :-  
	PMetaSchema=[Clause1,Clause2],
	Clause2=if(Head,Body),
	Body=and(_,Conj),
	IPinfo=pi(IPPos,IPName,_),
	collectArgs(Head,[IPPos],[IPVar]),
	name(Name,IPName),
	DecRinfo=decRinfo(DecR,HeadInfos,TailInfos),
	replaceatom(DecR,Name,IPVar,DecRinst), %instantiate the IP of DecR to the IP of Head
        convertconjht(DecRinst,NewDecRinst), %decR instance of the open program
	convertPIs(ListofTX,TailInfos), %instantiate TX's of recursive calls inside "conjatoms"
	Conj=and(RecursiveCalls,Dpc),        %in meta-schema
       	instParamConj2(RecursiveCalls,ListofTX,IPPos),
	convertPIs(ListofHX,HeadInfos),
	length(ListofHX,H),
	genNumber(0,H,HPos),
	processterm(HPos,Dpc,ListofHX),
     	NewBody=and(NewDecRinst,Conj),
	NewClause2=if(Head,NewBody),
	DecPMetaSchema=[NewClause2,Clause1]. %clause with dpc is the first claue 
	


%putVars(Term,Term2)

/*putVars(and(Conj1,Conj2),NewConj) :-
	Conj1=..[_|Args],
	Args = [_,*/



/*putVars(and(Conj1,Conj2),NewConj) :-
	!,
	putVars(Conj1,NConj1),
	putVars(Conj2,NConj2),
	NewConj = and(NConj1,NConj2).
putVars(Conj,NewConj) :-
	Conj =..[Pred|Args],!,
	putVars2(Args,NArgs),
	NewConj =..[Pred|NArgs].
putVars(Conj,NewConj) :-
	atomic(Conj),
	nonvar(Conj),
	var(NewConj).


putVars2([],[]).
putVars2([H|T],[H|NT]) :-
	var(H),
	putVars(T,NT).
putVars2([H|T],[V|NT]) :-
	nonvar(H),
	var(V),
	putVars(T,NT).*/



%replaceArgument(Atom,Args,NewAtom) iff NewAtom is Atom whose first
%argument has been replaced by list of terms Args.

replaceArgument(Atom,Args,NewAtom) :-
	Atom =.. [Pred|AtomArgs],
	AtomArgs = [_|RestArgs],
	append(Args,RestArgs,NewArgs),
	NewAtom =.. [Pred|NewArgs].
	
%adjustMode(Mode,ParamRoles,PRoles,NewMode) iff NewMode is Mode, where the arguments
%have been shuffled according to the actual positions of parameters of PRoles, e.g. 'Passive', ip etc 
%in ParamRoles (Mode is in vectoral form).



adjustMode(Mode,ParamRoles,PRoles,NewMode) :-
	dedotifyMode(Mode,DMode),
	functor(DMode,mode,N),
	functor(NewMode,mode,N),
	Mode =.. [_|ModeArgs],
	adjustMode2(ModeArgs,ParamRoles,PRoles,NewMode).


adjustMode2(_,_,[],_).
adjustMode2([HMode|TModes],ParamRoles,[HPRole|TPRoles],NewMode) :-
	member(HMode,[may,must,res]),
	findPos(ParamRoles,HPRole,Pos),
	instantiateMode(NewMode,Pos,HMode),
	adjustMode2(TModes,ParamRoles,TPRoles,NewMode).

adjustMode2([HMode|TModes],ParamRoles,[HPRole|TPRoles],NewMode) :-
	HMode = vec(Mode,_,_),
	findPos(ParamRoles,HPRole,Pos),
	instantiateMode(NewMode,Pos,Mode),
	adjustMode2(TModes,ParamRoles,TPRoles,NewMode).


instantiateMode(_,[],_).

instantiateMode(NewMode,[HPos|TPos],Mode) :-
	arg(HPos,NewMode,Mode),
	instantiateMode(NewMode,TPos,Mode).
	
	
	
%decomposition primitives for lists and natural numbers.

:- op(1100,xfx,<--).


%decPrim((decompose('L','HL','TL1','TL2')<--and(headtail('L',['HL'],'T'),partition('T','HL','TL1','TL2'))),list(nat),'L').

%decPrim(<--(decompose('L','HL','TL'),headtail('L',['HL'],'TL')),list(_),'L').
decPrim((decompose('L','HL','TL')<--headtail('L',['HL'],'TL')),list(_),'L').
decPrim((decompose('L','HL1','HL2','TL')<--headtail('L',['HL1','HL2'],'TL')),list(_),'L').
%decPrim((decompose('L','H1','H2','T')<--and(headtail('L',['H1','H2'],'T'),halves('L','TL1','TL2'))),list(_),'L').
%decPrim(and(headtail('L',['HL'],'T'),partition('T','HL','TL1','TL2')),
%         list(int),'L').
%decPrim(and(headtail('L',['HL'],'T'),partition('T','HL','TL1','TL2')),
%         list(nat),'L').
%decPrim(and(headtail('L',['H1','H2'],'T'),halves('L','TL1','TL2')),
%	list(_),'L').
decPrim((decompose('N','HN','TN')<--and('N'=s('TN'),'HN'='N')),nat,'N').

%decPrim((decompose('L','TL1','TL2')<--and(headtail('L',['H1','H2'],'T'),halves%('L','TL1','TL2'))),list(_),'L').

