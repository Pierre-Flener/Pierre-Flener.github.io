%uses predicates msg/5, checkMember/2, vars/2  from utilities.pl 

%makeBody(L,C) holds iff list L is a flattened form of the conjunction C (from left to right).


makeBody([A],A):- A==true,!. %to prevent variable Body MSG to instan. to true.
makeBody([],true). %incase of undefined lg/theta for the bodies of clauses
makeBody([A],A) :- compound(A),!.
makeBody(L,(C,RC)) :-
        nonvar(L),
	L=[C|R],
	makeBody(R,RC).

%conjMsg(L,C,Lmsg,Inj,NewInj) holds iff Lmsg is the msg list of the literal L
%and the conjunction C, where the msg list is the cartesian product
%(msg) of the literal L and the atoms in conjunction C, where NewInj
%is the list of terms and their msgs,
%e.g. NewInj=[inj(A=B,D>C,X), inj(D,E,Y)].

conjMsg(true,true,[true],[],[]).  
conjMsg(L,B,[Lmsg|R],Inj,NewInj) :-
	B=and(LB,LR),functor(L,F,N),functor(LB,F,N),!,  %compatible literals
	msg(L,LB,Lmsg,Inj,Linj), 
	conjMsg(L,LR,R,Linj,NewInj).   
conjMsg(L,B,R,Inj,NewInj) :-
	B=and(LB,LR),!, %incompatible literals
	msg(L,LB,_,Inj,Linj),conjMsg(L,LR,R,Linj,NewInj).
conjMsg(L,C,[Lmsg],Inj,NewInj) :- 
	compound(C),functor(C,F,N),functor(L,F,N), %compatible literals
	msg(L,C,Lmsg,Inj,NewInj),!.
conjMsg(L,C,[M],Inj,NewInj) :- 
	compound(C),msg(L,C,M,Inj,NewInj). %incompatible literals


%bodyMsg(Conj1,Conj2,Msg,Inj) holds iff Msg is the list of the msgs of
%all literals in Conj1 and Conj2,  where the msg list is the cartesian product
%(msg) of the atoms in conjunction Conj1 and conjunction Conj2, where
%Inj is the list of terms and their msgs,
%e.g. NewInj=[inj(A=B,D>C,X), inj(D,E,Y)].
    
bodyMsg(true,true,[true],_) :- !.
bodyMsg(C,B,Bmsg,Inj) :-
        C=and(L,Conj),!,
	conjMsg(L,B,Lmsg,Inj,ConjInj),!,
	bodyMsg(Conj,B,BRmsg,ConjInj),
	append(Lmsg,BRmsg,Bmsg).
bodyMsg(C,B,Bmsg,Inj) :- 
	(C = true ; compound(C)), 
	conjMsg(C,B,Bmsg,Inj,_).

%member2(L,E) iff E is a member of list L (succeeds only once).

member2([E|_],E) :- !.
member2([_|T],E) :- 
	member2(T,E).

%checkVars(Vars,L) iff at least one element of Vars is an element of list L.

checkVars([V|_],L) :-
	memberCheck(L,V),!.
checkVars([_|T],L) :-
	checkVars(T,L).

%equalLists(L1,L2) iff list L1 and list L2 are literally identical.

equalLists([],[]).
equalLists([H|T],[H2|T2]) :-
	H == H2,
        equalLists(T,T2).

%union2(L1,L2,U) iff list U is the union of list L1 and list L2 (the elements of L2 comes after the elements of L1).

union2([],L,L).
union2([H|T],L,U) :-
	memberCheck(L,H),!,
	union2(T,L,U).
union2([H|T],L,[H|U]) :-
	union2(T,L,U).

%linkedVars(Terms,Vars,LTerms,LVars) iff list LTerms is list Terms without its terms that do not contain variables Vars and LVars is the list of variables of LTerms.

linkedVars([],Vars,[],Vars).
linkedVars([Term|Rest],Vars,[Term|LRest],NewVars2) :-
	vars(Term,TVars),
	checkVars(Vars,TVars),!,
        union2(Vars,TVars,NewVars),
	linkedVars(Rest,NewVars,LRest,NewVars2).
linkedVars([_|Rest],Vars,LinkedTerms,NewVars) :-
	linkedVars(Rest,Vars,LinkedTerms,NewVars).

%linkedTerms(Terms,Vars,LTerms,LVars) iff list LTerms is list Terms without its terms that do not have any linked variables with the ones in Vars, and
%LVars is list of variables of LTerms, e.g. linkedTerms([C<D,C<B,A<B,E<F],[A,B],[C<D,C<B,A<B],[D,C,A,B]).

linkedTerms(Terms,Vars,LTerm,NewVars) :-
       	linkedVars(Terms,Vars,LTerm,NewVars),
        equalLists(Vars,NewVars),!.
linkedTerms(Terms,Vars,LTerms,NewVars2) :-
        linkedVars(Terms,Vars,LTerm1,NewVars),
	linkedTerms(Terms,NewVars,LTerm2,NewVars2),
	union2(LTerm1,LTerm2,LTerms).

%append(L1,L2,L3) iff list L3 is list L2 concatenated to list L1.
%L3 = L1 <> L2, e.g. append([a,b],[c,d,e],[a,b,c,d,e])
  
%append([],L,L).
%append([H|T],L,[H|TL]) :-
%	append(T,L,TL).

%thetaReduction(C,R) iff R is the theta-subsumption reduced body of Horn 
%Clause C (the reduction algorithm is from Plotkin's paper on Generalization)
%thetaReduction([m(X,Y),m(X,T)],R).
%R = [m(X,T)],Y = T.
%thetaReduction([m(X,Z),m(X,T),f(X,T)],R).
%R = [m(X,T),f(X,T)],Z = T. 

thetaReduction(C,R) :-
	delAndCheck(C,CR),!,
	thetaReduction(CR,R).
thetaReduction(R,R).


%delAndCheck(C,R) iff list R is list C without an element of C that unifies 
%with another element of list C. 
%delAndCheck([m(X,Z),m(X,T),f(X,T)],R).
%R = [m(X,T),f(X,T)],Z = T.
 
delAndCheck(C,R) :-
	C=[H|T],
	member2(T,H),!,
	R=T.
delAndCheck(C,[H|RT]) :-
	C=[H|T],
	delAndCheck(T,RT).
	
	
%clauseMsg(C,D,Msg) holds iff Msg is the msg (lg\theta) of the two compatible (the head functors of both clauses have the same function symbol and have the same arity) definite clauses C and D. 

%clauseMsg(if(foo(A,P,Q,R),(R=[P|A],Q>P)),if(foo(C,D,F,E),(E=[D|C],F>D)),MSG)
%MSG = if(foo(_A,_B,_C,_D),(_D=[_B|_A],[_C>_B]))
%clauseMsg(if(foo(A,P,Q,R),true),if(foo(C,D,F,E),true),MSG)
%MSG = if(foo(_A,_B,_C,_D),true)
%clauseMsg(if(foo2(HL,TR,R,P),(HL=B1,(TR=[],(R=[B1],not(odd(B1)))))), if(foo2(HL,TR,R,P),(HL=B1,(TR=[B2],(R=[B1,B2],not(odd(B1)))))),MSG).
% MSG = if(foo2(_A,_B,_C,_D),(_A=_E,(_B=_F,(_C=[_E|_F],not(odd(_E))))))
%clauseMsg(if(foo3(B1,[],[B1],P),not(odd(B1))),if(foo3(B1,[B2],[B1,B2],P),not(odd(B1))),MSG)
%MSG = if(foo3(_A,_B,[_A|_B],_C),not(odd(_A)))
%clauseMsg(if(foo3(X),(X<Y,(Y<V,(V<K,P<Q)))),if(foo3(Z),(Z<T,(T<W,(W<L,R<S)))),MSG).
%MSG = if(foo3(_A),(_A<_B,_B<_C,_C<_D)). 
%clauseMsg(if(foo3(X),(P<Q,(Y<V,(V<K,X<Y)))),if(foo3(Z),(T<W,(Z<T,(W<L,R<S)))),MSG).
%MSG = if(foo3(_A),(_B<_C,_C<_D,_A<_B)).

clauseMsg(C,D,Msg) :-
        C = if(H1,B1),
        D = if(H2,B2), 
	msg(H1,H2,Hmsg,[],NewInj),
       	bodyMsg(B1,B2,Bmsg,NewInj),
        makeBody(Bmsg,Bconj),
	Msg = if(Hmsg,Bconj).
					  
