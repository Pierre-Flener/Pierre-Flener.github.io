%
%    dedotify.pl
%    written by:Halime Buyukyildiz
%    modified by:Serap Yilmaz & Halime Buyukyildiz
%

%dedotify(TempD,TempDD) iff TempDD is the open program TempD,
%without dots ...
/*
dedotify([if(r(X,Y),and(minimal(X),solve(X,Y))),
if(r(X,Y), and(nonminimal(X),and(decompose(X,HX,vec(TX,1,2)),
and(conjatoms(r(TX#J,TY#J),1,2),and(I#0 = E,
and(conjatoms(compose(I#(J-1),TY#J,I#J),1,1),
and(process(HX,HY), and(compose(I#1,HY,I#2),
and(conjatoms(compose(I#J,TY#J,I#(J+1)),2,2),Y=I#3)))))))))],D).

dedotify([if(r(X,Y),r_t([X],Y)),
	      if(r_t(Xs,Y), and(Xs=[], Y=[])),
	      if(r_t(Xs,Y), and(Xs=[X|TXs], and(minimal(X),
	                    and(r_t(TXs,TY), and(solve(X,HY),
			    compose(HY,TY,Y)))))),
	      if(r_t(Xs,Y), and(Xs=[X|TXs], and(nonminimal(X),
	                    and(decompose(X,HX,vec(TX,1,2)),
			    and(conjatoms(minimal(TX#J),1,1),
			    and(r_t([vec(TX,2,2)|TXs],TY),
			    and(conjatoms(solve(TX#J,TY#J),1,1),
			    and(I#0=[],
			    and(conjatoms(compose(I#(J-1),TY#J,I#J),1,1),
			    and(process(HX,HHY),
			    and(compose(I#1,HHY,I#2),
			    and(HY=I#2,compose(HY,TY,Y))))))))))))),
	     if(r_t(Xs,Y), and(Xs=[X|TXs], and(nonminimal(X),
	                    and(decompose(X,HX,vec(TX,1,2)),
			    and(disjatoms(nonminimal(TX#J),1,1),
			    and(conjatoms(minimal(U#J),1,1),
			    and(decompose(N,HX,vec(U,1,1),vec(TX,2,2)),
			    r_t([vec(TX,1,1),N|TXs],Y))))))))],D).

*/

dedotify([],[]).

dedotify([DC|TTempD],[DDC|TTempDD]):-
	dedotify_clause(DC,DDC,F), F = t,
	dedotify(TTempD,TTempDD),!.

dedotify([DC|TTempD],TempDD):-
	dedotify_clause(DC,_,F), F = f,
	dedotify(TTempD,TempDD).

%dedotify_clause(DC,DDC,Flag) iff DDC is the clause DC, without dots and
%Flag=t, or Flag=f and no DDC generated from DC
%dedotify_clause(if(r(X,Y),and(m(X),s(X,Y))),D,F).
/*
dedotify_clause(if(r(X,Y), and(nonminimal(X),and(decompose(X,HX,vec(TX,1,2)),
and(conjatoms(r(TX#J,TY#J),1,2),and(I#0 = [],
and(conjatoms(compose(I#(J-1),TY#J,I#J),1,1),
and(process(HX,HY), and(compose(I#1,HY,I#2),
and(conjatoms(compose(I#J,TY#J,I#(J+1)),2,2),Y=I#3))))))))),D,F).

dedotify_clause(if(r_t(Xs,Y), and(Xs=[X|TXs], and(nonminimal(X),
	                    and(decompose(X,HX,vec(TX,1,2)),
			    and(conjatoms(minimal(TX#J),1,1),
			    and(r_t([vec(TX,2,2)|TXs],TY),
			    and(conjatoms(solve(TX#J,TY#J),1,1),
			    and(I#0=[],
			    and(conjatoms(compose(I#(J-1),TY#J,I#J),1,1),
			    and(process(HX,HHY),
			    and(compose(I#1,HHY,I#2),
			    and(HY=I#2,compose(HY,TY,Y))))))))))))),D,F).

*/

dedotify_clause(if(DH,DB),if(DDH,DDB),F):-
	dedotify_atom(DH,DDH,[],HVs),
	dedotify_body(DB,DDB,HVs,_,F),
	F = t.

dedotify_clause(if(DH,DB),if(DDH,_),F):-
	dedotify_atom(DH,DDH,[],HVs),
	dedotify_body(DB,_,HVs,_,F),
	F = f.

%dedotify_body(DB,DDB,IVs,Vs,Flag) iff  DDB is the body DB, without
%conjatoms/2,
%disjatoms/2, sterm/2, each X#Y denoting indexed variables in DB is properly
%replaced by a new variable Z, where Vs is the list of references of (X#Y, Z),
%and flag is t. Otherwise Flag is f, and no body.
%dedotify_body(and(m(X),s(X,Y)),D,[],V,F).

dedotify_body(true,true,Vs,Vs,t).

dedotify_body(conjatoms(_,LB,UB),DDConj, _, [],t):-
	nonvar(LB), nonvar(UB),
	LB > UB , DDConj = true.

dedotify_body(conjatoms(Root,LB,UB),DDConj, Vs, CVs,t):-
	nonvar(LB), nonvar(UB),
	LB =< UB,
	Root =.. [P|Args],
	dedotify_conj(P,Args,LB,UB,DDConj,Vs,CVs).

dedotify_body(disjatoms(_,LB,UB),_, _, _,f):-
	nonvar(LB), nonvar(UB),
	LB > UB.

dedotify_body(disjatoms(Root,LB,UB),DDDisj, Vs, DVs,t):-
	nonvar(LB), nonvar(UB),
	LB =< UB,
	Root =.. [P|Args],
	dedotify_disj(P,Args,LB,UB,DDDisj,Vs,DVs).

dedotify_body(and(A,C),and(DDA,DDC),Vs,NVs,Flag) :-
	dedotify_body(A,DDA,Vs,AVs,t),
	append(AVs,Vs,NIVs),
	dedotify_body(C,DDC,NIVs,CVs,Flag),
	append(NIVs,CVs,NVs).

dedotify_body(and(A,_),and(DDA,_),Vs,_,F) :-
	dedotify_body(A,DDA,Vs,_,F), F=f, !.

dedotify_body(Atom,DDAtom,Vs,AVs,t) :-
	\+(Atom == conjatoms(_,_,_)),
	\+(Atom == disjatoms(_,_,_)),
	\+(Atom == and(_,_)),
	dedotify_atom(Atom,DDAtom,Vs,AVs).


%dedotify_atom(Atom,DDAtom,Vs,AVs) iff DDAtom is the Atom with actual variables
%not indexed ones (I#4), and Vs is the input list that may or may not contain
%the variables that are used in Atom. Variable as a tuple (I#3, I_3) is put in
%the list AVs, if not already in Vs.

% dedotify_atom(Atom,DDAtom,Vs,AVs) for infix predicates not written like =


dedotify_atom(Atom,DDAtom,Vs,AVs):-
	Atom =.. [P|Args],
	convert_args(Args,DArgs,Vs,AVs),
	DDAtom =.. [P|DArgs].

%convert_args(Args,DArgs,Vs,AVs)
%convert_args([TX#3,I#2,TX#2],D,[(TX#3,A)],Vs).
%convert_args([X,vec(TX,1,3)],D,[(TX#3,A)],Vs).
%convert_args([[L,R,N|TXs]],D,[],A).
%convert_args([[vec(TX,1,2)|TXs]],D,[],A).

convert_args([],[],_,[]).

convert_args([HArg|TArgs],DArgs,Vs,AVs):-
	\+(var(HArg)),mlist(HArg),
	convert_list_arg(HArg,HDArg,Vs,HVs),
	append(Vs,HVs,NVs),
	convert_args(TArgs,TDArgs,NVs,TVs),
	append([HDArg],TDArgs,DArgs),
	append(HVs,TVs,AVs).

convert_args([HArg|TArgs],[HDArg|TDArgs],Vs,AVs):-
	\+(HArg == vec(_,_,_)),
	convert_arg(HArg,HDArg,Vs,ArgV),
	append(ArgV,Vs,NIVs),
	convert_args(TArgs,TDArgs,NIVs,TAVs),
	append(ArgV,TAVs,AVs).

convert_args([vec(_,LB,UB)|TArgs],DArgs,Vs,AVs):-
	nonvar(LB), nonvar(UB),
	LB > UB,
	convert_args(TArgs,DArgs,Vs,AVs).

convert_args([vec(V,LB,UB)|TArgs],DArgs,Vs,AVs):-
	nonvar(LB), nonvar(UB),
	LB =< UB,
	vec_convert(V,LB,UB,HDArgs,Vs,VVs),
	append(Vs,VVs,NVs),
	convert_args(TArgs,TDArgs,NVs,TVs),
	append(HDArgs,TDArgs,DArgs),
	append(VVs,TVs,AVs).


%convert_list_arg([vec(TX,1,2)|TXs],HDArg,[],AVs)
%convert_list_arg([L,N|T],HD,[],A).

convert_list_arg(T,TD,_,[]):-
	\+(var(T)), 
	T == [], TD=T.

convert_list_arg([H|T],TD,Vs,AVs):-
	\+(var(H)),
	H=vec(_,LB,UB),
	var(T), 
	\+(var(LB)), \+(var(UB)),
	LB > UB, 
	convert_arg(T,TD,Vs,AVs).

convert_list_arg([H|T],DArg,Vs,AVs):-
	\+(var(H)),
	H=vec(V,LB,UB),
	var(T), 
	\+(var(LB)), \+(var(UB)),
	LB =< UB, 
	vec_convert(V,LB,UB,DVec,Vs,VVs),
	append(Vs,VVs,NVs),
	convert_arg(T,TD,NVs,TVs),
	append(DVec,TD,DArg),
	append(VVs,TVs,AVs).

convert_list_arg([H|T],[HD|TD],Vs,AVs):-
	\+(H == vec(_,_,_)), var(T), 
	convert_arg(H,HD,Vs,HVs),
	append(HVs,Vs,NVs),
	convert_arg(T,TD,NVs,TVs),
	append(HVs,TVs,AVs).


convert_list_arg([H|T],TD,Vs,AVs):-
	\+(var(H)),
	H=vec(_,LB,UB),
	\+(var(T)), 
	\+(var(LB)), \+(var(UB)),
	LB > UB, 
	convert_list_arg(T,TD,Vs,AVs).

convert_list_arg([H|T],DArg,Vs,AVs):-
	\+(var(H)),
	H=vec(V,LB,UB),
	\+(var(T)), 
	\+(var(LB)), \+(var(UB)),
	LB =< UB, 
	vec_convert(V,LB,UB,DVec,Vs,VVs),
	append(Vs,VVs,NVs),
	convert_list_arg(T,TD,NVs,TVs),
	append(DVec,TD,DArg),
	append(VVs,TVs,AVs).

convert_list_arg([H|T],DArg,Vs,AVs):-
	\+(H == vec(_,_,_)), \+(var(T)), 
	convert_arg(H,HD,Vs,HVs),
	append(HVs,Vs,NVs),
	convert_list_arg(T,TD,NVs,TVs),
	append(HVs,TVs,AVs),
	append([HD],TD,DArg).
	
%vec_convert(V,LB,UB,HDArgs,Vs, VVs)

vec_convert(V,UB,UB,[HDArg],Vs,VVs):-
	convert_arg(V#UB,HDArg,Vs,VVs).

vec_convert(V,LB,UB,[HDArg|TDArgs],Vs,VVs):-
	LB < UB,
	convert_arg(V#LB,HDArg,Vs,HVs),
	NLB is LB+1,
	append(HVs,Vs,NVs),
	vec_convert(V,NLB,UB,TDArgs,NVs,TVs),
	append(HVs,TVs,VVs).

%mlist(L)

mlist([]).
mlist([_|T]):-var(T),!.
mlist([_|T]):- \+(var(T)), mlist(T).

%convert_arg(HArg,HDArg,Vs,ArgV)


convert_arg(HArg,HArg,[],[(HArg,HArg)]):-
	var(HArg).

convert_arg(HArg,HDArg,[],[(HArg,HDArg)]):-
	\+(var(HArg)), 
	HArg = _#_,
	var(HDArg).

convert_arg(HArg,HArg,[(HVArg,HVArg)|_],[]):-
        var(HArg), var(HVArg),  
	HArg == HVArg.

convert_arg(HArg,HDArg,[(HVArg,HDArg)|_], []):-
	\+(var(HArg)), \+(var(HVArg)), 
	HArg = Arg#N,
	HVArg = VArg#M,
	Arg == VArg,
	N == M.

convert_arg(HArg,HDArg,[(HHArg,_)|TVs],ArgV):-
	var(HArg), var(HHArg), 
	\+(HArg == HHArg),  
	convert_arg(HArg,HDArg,TVs,ArgV).

convert_arg(HArg,HDArg,[(HHArg,_)|TVs],ArgV):-
	var(HArg), \+(var(HHArg)), 
	convert_arg(HArg,HDArg,TVs,ArgV).

convert_arg(HArg,HDArg,[(Arg,_)|TVs],ArgV):-
	var(Arg), \+(var(HArg)), 
	convert_arg(HArg,HDArg,TVs,ArgV).

convert_arg(HArg,HDArg,[(HVArg,_)|TVs],ArgV):-
	\+(var(HArg)), \+(var(HVArg)), 
	HArg = Arg#N,
	HVArg = VArg#M,
	(\+(M == N); \+(VArg == Arg)),
	convert_arg(HArg,HDArg,TVs,ArgV).

%dedotify_conj(P,Args,LB,UB,DDConj,Vs,CVs)

dedotify_conj(P,Args,UB,UB,DDConj,Vs,CVs):-
	proc_args(Args,UB,NArgs),
	convert_args(NArgs,DDArgs,Vs,CVs),
	DDConj =.. [P|DDArgs].

dedotify_conj(P,Args,LB,UB,and(DDA,DDB),Vs,CVs):-
	LB < UB,
	proc_args(Args,LB,NArgs),
	convert_args(NArgs,DDArgs,Vs,AVs),
	DDA =.. [P|DDArgs],
	NLB is LB+1,
	append(AVs,Vs,NIVs),
	dedotify_conj(P,Args,NLB,UB,DDB,NIVs,BVs),
	append(AVs,BVs,CVs).


%dedotify_disj(P,Args,LB,UB,DDDisj,Vs,DVs)

dedotify_disj(P,Args,UB,UB,DDDisj,Vs,DVs):-
	proc_args(Args,UB,NArgs),
	convert_args(NArgs,DDArgs,Vs,DVs),
	DDDisj =.. [P|DDArgs].

dedotify_disj(P,Args,LB,UB,or(DDA,DDB),Vs,DVs):-
	LB < UB,
	proc_args(Args,LB,NArgs),
	convert_args(NArgs,DDArgs,Vs,AVs),
	DDA =.. [P|DDArgs],
	NLB is LB+1,
	append(AVs,Vs,NIVs),
	dedotify_disj(P,Args,NLB,UB,DDB,NIVs,BVs),
	append(AVs,BVs,DVs).

%proc_args(Args,N,NArgs) iff
%proc_args([TX#J,I#(J-1)], 3, [TX#3,I#2]).

proc_args([],_,[]).

proc_args([vec(_,VLB,VUB)|TArgs],LB,TNArgs):-
	nonvar(VLB), nonvar(VUB),
	VLB > VUB,
	proc_args(TArgs,LB,TNArgs).

proc_args([vec(V,VLB,VUB)|TArgs],LB,[vec(V,VLB,VUB)|TNArgs]):-
	nonvar(VLB), nonvar(VUB),
	VLB =< VUB,
	proc_args(TArgs,LB,TNArgs).

proc_args([HArg|TArgs],LB,[HArg|TNArgs]):-
	var(HArg),
	proc_args(TArgs,LB,TNArgs).

proc_args([HArg#J|TArgs],LB,[HArg#LB|TNArgs]):-
	var(J),
	proc_args(TArgs,LB,TNArgs).

proc_args([HArg#(J-X)|TArgs],LB,[HArg#NE|TNArgs]):-
	var(J),
	\+(var(X)),
	NE is LB-X,
	proc_args(TArgs,LB,TNArgs).

proc_args([HArg#(J+X)|TArgs],LB,[HArg#NE|TNArgs]):-
	var(J),
	\+(var(X)),
	NE is LB+X,
	proc_args(TArgs,LB,TNArgs).


%dedotifyMode(Mode,DMode) iff term DMode is dedotified form of term Mode.

dedotifyMode(Mode,DMode) :-
	Mode =.. [_|Args],
	dedotifyArgs(Args,DArgs),
	DMode =.. [mode|DArgs].


dedotifyArgs([],[]).
dedotifyArgs([H|T],DArgs) :-
	H =.. [vec|_],!,
	dedotifyVec(H,DH),
	dedotifyArgs(T,TDArgs),
	append(DH,TDArgs,DArgs).
dedotifyArgs([H|T],[H|DTArgs]) :-
	dedotifyArgs(T,DTArgs). %H is may,must,res,or mayall


dedotifyVec(Vector,DVector) :-
	Vector =.. [vec|VecArgs],
	VecArgs = [Item,LB,UB],
	constructItem(Item,LB,UB,DVector).


constructItem(Item,UB,UB,[Item]).
constructItem(_,LB,UB,[]) :- LB>UB.
constructItem(Item,LB,UB,[Item|TDVector]) :-
	LB < UB,
	NewLB is LB + 1,
	constructItem(Item,NewLB,UB,TDVector).








