%*******************************************************************************
%*									       *
%*  DIALOGS - Dialog-based Inductive and Abductive LOGic program Synthesizer-II*
%*									       *
%*				 dialogs2.pl				       *
%*									       *
%*		Written by: Serap Yilmaz  (1997)                               *
%*									       *
%*******************************************************************************


%%% Initializations
:- use_module(library(lists)).


:- [phase0,phase1and2,schemas,utilities,clausemsg,dedotify,primitives,prettyPrint,grammar,cliques].
:- dynamic short/1.
:- dynamic dialMode/1.
:- dynamic introduced/1.

	
%%% Specifier-level commands

aloud :-
	retractall(dialMode(_)),
	assert(dialMode(aloud)).
mute :-
	retractall(dialMode(_)),
	assert(dialMode(mute)).

cleanup :-
	retractall(di(_,_)),
	retractall(ip(_,_)),
	retractall(rp(_,_)),
	retractall(ap(_,_)),
	retractall(acc(_,_)),   
	retractall(short(_)),
	retractall(introduced(_)).


%dialogsII gets Schema and Strategy from schemas.pl

dialogsII(Schema,Strategy,Pred,ParamTypes) :-
	aloud,
	cleanup,			% only needed during DIALOGSII design
	dialogsII(Schema,Strategy,1,Pred,ParamTypes,[],[],[],Pred,Pgm),
        writeln('A possible program is:'),
	ppPgm(Pgm),
	aloud, 
	ask('Do you want another logic program?',"yes",AnsStr),
	(AnsStr="yes" ->
	 (writeln('Backtracking...'),fail)
	;
	 (cleanup,aloud,writeln('No (more) programs.'))
	).


% dialogsII(Schema,Strategy,Level,CurrPred,ParamTypes,Hints,Infos,StartPgm,TopPred,Pgm)
%       Schema is the schema to be used together with its strategy Strategy
%       Level is the level of the synthesis
%	Pgm is a logic program for predicate TopPred, obtained by adding
%	some clauses for predicate CurrPred (whose parameter name:type pairs
%	are ParamTypes) to the logic program StartPgm.  Hints contains
%	preferences for some decisions of phase0.  Infos contains information
%	about the chain of schema-defined predicates in StartPgm. ParamTypes are the
%       paramTypes of the predicate CurrPred.   

dialogsII(Schema,Strategy,Level,CurrPred,ParamTypes,Hints,Infos,StartPgm,TopPred,Pgm) :-
	lpschema(Schema,_,PRoles,_,_,_,_,_,_,_),
        phase0(Schema,Strategy,CurrPred,ParamTypes,Hints,PRoles,Info,PMode,QMode,OpenPgm),
	append(StartPgm,OpenPgm,CurrPgm),
	append(Infos,[Info],NewInfos),
	phase1and2(Schema,Strategy,Level,CurrPgm,NewInfos,PMode,QMode,TopPred,Pgm).







