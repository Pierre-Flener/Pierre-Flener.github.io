%******************************************************************************
%*									      *
%*				 phase1and2.pl				      *
%*									      *
%*	 	Written by: Serap Yilmaz  (1997)		              *
%******************************************************************************

% phase1and2(Schema,Strategy,CurrPgm,Infos,TopPred,Pgm)
%	Pgm is a logic program for predicate TopPred, obtained from the
%	second-order logic program CurrPgm by instantiating the unknown
%	operators of its second-order clauses.  Infos contains information
%	about the chain of D&C-defined predicates in CurrPgm.  Shortcuts
%	for some predicates of CurrPgm are asserted as short/1 facts.

phase1and2(Schema,Strategy,Level,CurrPgm,Infos,PMode,QMode,TopPred,Pgm) :-
	writeln('Current program: '),ppPgm(CurrPgm),
	member(Schema,[dc,dg]),
	member(Strategy,[divide_and_conquer_strategy1,descend_gen_strategy1]),
	abduce(Schema,CurrPgm,Infos,TopPred,Level,Pev,Qev),
    	induce(Pev,Qev,PMode,QMode,Pinsts,Qinsts),
	evaluate(Schema,Strategy,Level,Qinsts,Pinsts,Qev,Pev,PMode,CurrPgm,Infos,TopPred,Pgm).
       



abduce(Schema,Pgm,Infos,TopPred,Level,Pev,Qev) :-
	Infos=[info(ParamRoles,_,Arity,_,_,_)|_],
	findInfo(ParamRoles,'Induction',IPInfo),
	IPInfo = [pi(IPpos,_,IPtype)],
	dlgsreverse(Pgm,RPgm), %to ask queries of relation "q" first
	findCouples(RPgm,TopPred,Arity,IPpos,IPtype,Level,Couples),!,
	retractOpShorts(Schema),
	unzip(Couples,Pev,Qev).

%findCouples(Pgm,TopPred,Arity,IPpos,IPtype,Couples) iff Couples is
%the couples of P and Q examples. 

findCouples(Pgm,TopPred,Arity,IPpos,IPtype,Level,Couples) :-
	buildGoal(TopPred,Arity,IPpos,IPtype,Goal),
                    	cutify(Goal,CuteGoal,_),
	                write('***NOW PROVING GOAL: <-- '),ppConj(CuteGoal),nl,
        pgmClause(Pgm,Goal,Body),
	demo(Body,Pgm,Level,Ass,Res,MaybeLast),  %duplicate when unfolding "pgm."
       	(MaybeLast=none -> Last=Goal ; Last=MaybeLast),
        askQuery(Goal,Ass,Res,Answer,Answers), 
        (Answer == false -> fail; %maybe add ", Res = [P|..]" then fail
        Answer == stop_it -> assertz(queue(bottom)),collectCouples(Couples);
        (Answers \== [] -> abduce_evidence(Answers,Res,Last,Ass,Pexs,Qexs), 
	 assertz(queue(couple(Pexs,Qexs))), %Answer \== stop_it and Answers \== []
         fail; fail))                         %Answer \== stop_it and Answers=[]
      	 ;assertz(queue(bottom)), %no backtracking point left
	  collectCouples(Couples).


collectCouples(Cs) :-
	retract(queue(X)),!,
	(X == bottom,!,Cs=[]
         ;
	 Cs=[X|Rest],collectCouples(Rest)).

	 




% buildGoal(Pred,Arity,Pos,Type,Goal)
%	Goal is a most-general goal/atom for predicate Pred of arity Arity,
%	and this for various most-general values of the induction parameter,
%	which is at argument position Pos and of type Type.

buildGoal(Pred,Arity,Pos,Type,Goal) :-
	functor(Goal,Pred,Arity),
	mostGenForm(Type,Form),
	arg(Pos,Goal,Form).


mostGenForm(nat,0).
mostGenForm(nat,s(T)) :-
	mostGenForm(nat,T).

mostGenForm(list(_),[]).
mostGenForm(list(_),[_|T]) :-
	mostGenForm(list(_),T).



% demo(Goal,Pgm,Ass,Res,Last)
%	Flat conjunction Res is the residue of SLD-resolving conjunction Goal
%	with respect to the open program Pgm;  flat conjunction Ass
%	has the assumptions (with introduced predicates, which are skipped)
%	of this process.  Last is the last unfolded atom whose predicate is
%	defined in Pgm, and 'none' if no such unfolding occurred.

demo(true,_,_,Ass,Res,Last) :-		% empty goal
	!,Ass=true,Res=true,Last=none.
demo(and(G1,G2),Pgm,Level,Ass,Res,Last) :-	% conjunctive goal
	!,demo(G1,Pgm,Level,Ass1,Res1,_),
	demo(G2,Pgm,Level,Ass2,Res2,Last),
	conjoin(Ass1,Ass2,Ass),
	conjoin(Res1,Res2,Res).
demo(Atom,Pgm,Level,Ass,Res,Last) :-	% Q-Pred positive literal
	Atom =.. [AtomName|_],
	name(AtomName,AtomStr),
	q(_,QName),
	name(QName,QStr),
	name('_',UStr),
	append(QStr,UStr,QUStr),
	append(QUStr,_,AtomStr),
        legalShort(Atom,Body),		% there is a "legal" shortcut
		cutify(c(Atom,Body),c(CuteAtom,CuteBody),_),
		write('Trying shortcut during unfolding atom: '),
		print(CuteAtom),write(' <-- '),ppConj(CuteBody),nl,
	demo(Body,Pgm,Level,Ass,Res,Last).
demo(Atom,Pgm,Level,Ass,Res,Last) :-	% P-Pred positive literal
	Atom =.. [AtomName|_],
	name(AtomName,AtomStr),
	p(_,PName),
	name(PName,PStr),
	name('_',UStr),
	append(PStr,UStr,PUStr),
	append(PUStr,_,AtomStr),
	\+(closedRelation(Atom,Pgm)),
        legalShort(Atom,Body),		% there is a "legal" shortcut
		cutify(c(Atom,Body),c(CuteAtom,CuteBody),_),
		write('Trying shortcut during unfolding atom: '),
		print(CuteAtom),write(' <-- '),ppConj(CuteBody),nl,
	demo(Body,Pgm,Level,Ass,Res,Last).
demo(Atom,Pgm,Level,Ass,Res,Last) :-	
        Atom =.. [AtomName|_],
	name(AtomName,AtomStr),
        q(_,QName),
	name(QName,QStr),
	name('_',UStr),
	append(QStr,UStr,QUStr),
	append(QUStr,_,AtomStr),
	bagof(Body,pgmClause(Pgm,Atom,Body),[Body1,_]), %for second-level synthesis
	demo(Body1,Pgm,Level,Ass,Res,MaybeLast),
	(MaybeLast=none -> Last=Atom ; Last=MaybeLast).

demo(Atom,Pgm,Level,Ass,Res,Last) :-	
        Atom =.. [AtomName|_],
	name(AtomName,AtomStr),
        q(_,QName),
	name(QName,QStr),
	name('_',UStr),
	append(QStr,UStr,QUStr),
	append(QUStr,_,AtomStr),
       	bagof(Body,pgmClause(Pgm,Atom,Body),[_,Body2]), %for second-level synthesis
	demo(Body2,Pgm,Level,Ass,Res,MaybeLast),!,
	(MaybeLast=none -> Last=Atom ; Last=MaybeLast). 
       
demo(Atom,_,_,Ass,Res,Last) :-	% Q-Pred positive literal
        Atom =.. [AtomName|_],
	name(AtomName,AtomStr),
        q(_,QName),
	name(QName,QStr),
	name('_',UStr),
	append(QStr,UStr,QUStr),
	append(QUStr,_,AtomStr),!,
     	\+legalShort(Atom,_),		% there is no "legal" shortcut
       	Ass=true,
	Res=Atom,
	Last=none.
demo(Atom,Pgm,_,Ass,Res,Last) :-	% P-Pred positive literal
        Atom =.. [AtomName|_],
	name(AtomName,AtomStr),
        p(_,PName),
	name(PName,PStr),
	name('_',UStr),
	append(PStr,UStr,PUStr),
	append(PUStr,_,AtomStr),!, 
	\+(closedRelation(Atom,Pgm)),
	\+legalShort(Atom,_),		% there is no "legal" shortcut
       	Ass=true,
	Res=Atom,
	Last=none.
demo(neg(Atom),_,_,Ass,Res,Last) :-	% negative literal
	!,introduced(Atom),		% but introduced
	Ass=neg(Atom),			% other negation is disallowed
	Res=true,
	Last=none.
demo(Atom,_,_,Ass,Res,Last) :-		% positive literal
	introduced(Atom),!,		% and introduced
	Ass=Atom, 
	Res=true,
	Last=none.
demo(Atom,_,_,Ass,Res,Last) :-		% positive literal
	primitive(Atom),!,		% not introduced, but DialogsII primitive
        call(Atom),			% it must succeed
	Ass=true,
	Res=true,
	Last=none.
demo(Atom,Pgm,Level,Ass,Res,Last) :-	% positive literal
        short(if(Atom,Body)),	% there is a shortcut, attent.!
      	cutify(c(Atom,Body),c(CuteAtom,CuteBody),_),
	write('Trying shortcut during unfolding Atom: '),
	print(CuteAtom),write(' <-- '),ppConj(CuteBody),nl,
	demo(Body,Pgm,Level,Ass,Res,Last).    
demo(Atom,Pgm,Level,Ass,Res,Last) :-		% positive literal
       	\+short(if(Atom,Body)),		% there is no shortcut,
	pgmClause(Pgm,Atom,Body),
	demo(Body,Pgm,Level,Ass,Res,MaybeLast),
	(MaybeLast=none -> Last=Atom ; Last=MaybeLast).


%closedRelation(Atom,Pgm)

closedRelation(Atom,[Clause1|_]) :-
	Clause1=if(Head,_),
	Atom=..[Pred|_],
	Head=..[HPred|_],
	Pred=HPred,!.
closedRelation(Atom,[_|Rest]) :-
	closedRelation(Atom,Rest).
	


% legalShort(Atom,Body)
%	Body is the body (under substitution \theta) of an asserted shortcut
%	whose head is a variant (under \theta) of Atom.

legalShort(Atom,Body) :-
	copy_term(Atom,CopyBefore),
	numbervars(CopyBefore,1,N),
       	short(if(Atom,Body)),
	copy_term(Atom,CopyAfter),
	numbervars(CopyAfter,1,N).


% pgmClause(Pgm,Head,Body)
%	Logic program Pgm has a clause whose head matches atom Head,
%	and whose body matches conjunction Body.

pgmClause([Clause|_],Head,Body) :-
	copy_term(Clause,NewClause),	% needed???
	NewClause=if(Head,Body).
pgmClause([_|Pgm],Head,Body) :-
	pgmClause(Pgm,Head,Body).


% askQuery(Goal,Ass,Res,Answer,Answers)
%	Pexs or Qexs is a list of abduced tuples for the P-R or Q-R
%	predicate variable (if any) occurring in flat conjunction Res, which
%	is the residue of proving conjunction Goal, the assumptions being in
%	the flat conjunction Ass.  At least one of Pexs and Qexs is empty.
%	Last is the last unfolded atom whose predicate is defined in Pgm.

askQuery(_,_,Res,AnswerDisj,Answers) :-
	Res=true,!,	% no Residue
	AnswerDisj=continue,
	Answers=[].
askQuery(Goal,Ass,Res,AnswerDisj,Answers) :-
        Res =.. [ResName|_],
	legalAtom(ResName),     %either a 'P' or 'Q' atom  
	                        %Residue has 1! Open atom
  % offline (via shortcuts, w/o updating introduced/1):
        collect(AllAnswers,Goal), % danger(?): this may instantiate Goal...
       	pruneConjs(AllAnswers,Ass,AnswersOff),
       	(AnswersOff=[]->
  % online:
	 (
	  cutify(q(Goal,Ass),q(CuteGoal,CuteAss),Subst1),
	  write('When does '),print(CuteGoal),
	  write(' hold'),
	  (CuteAss=true -> true ; (write(', assuming '),ppConj(CuteAss))),
	  writeln('?'),
	  read_term(AnswerDisj,[variable_names(Subst2)]), 
	  rebind(Subst2,Subst1),
	  disjList(AnswerDisj,DAnswers),
	  makeListofList(DAnswers,LAnswers),
       	  removeRedundant(LAnswers,RAnswers),
	  commaAnds(RAnswers,Answers),  
          ((AnswerDisj\==false,AnswerDisj\==stop_it)->
       	    updateIntros(Answers);
	    true)
	 )
	;(Answers=AnswersOff, 
          writeln('Using shortcut(s) instead of querying...'))).


%abduce_evidence(Answers,Res,Last,Ass,Pexs,Qexs)

abduce_evidence(Answers,Res,Last,Ass,Pexs,Qexs) :-
	Res =..[ResPred|_],
	name(ResPred,ResPredStr),	
	(p(_,PName),name(PName,PStr),name('_',UStr),append(PStr,UStr,PUStr),append(PUStr,_,ResPredStr) ->		% "P..."
	 (buildPexsShorts(Answers,Res,Last,Ass,Pexs),
	  Qexs=[]
	 )
	;(Pexs=[],				% "Q..."
          buildQexsShorts(Answers,Res,Last,Ass,Qexs)
	 )
	).


%legalAtom(Atom) iff Atom is an atom whose name begins with either 'Q' or 'P'.

legalAtom(Atom) :-
	name(Atom,AtomStr),
	p(_,PName),
	name(PName,PStr),
	name('_',UStr),
	append(PStr,UStr,PUStr),
	append(PUStr,_,AtomStr),!.
legalAtom(Atom) :-
	name(Atom,AtomStr),
	q(_,QName),
	name(QName,QStr),
	name('_',UStr),
	append(QStr,UStr,QUStr),
	append(QUStr,_,AtomStr).

%prunespecific(Goal,Answers,PAnswers) :-
%	Answers=[Answer1,Answer2],
%       copy_term(
%       Term1=and(Goal,Answer1),
%	Term2=and(Goal,

% collect(Cs,H)
%	List Cs contains all the conjunctions that are the bodies of
%	asserted shortcuts with head H.

collect(Cs,H) :-
	collect(Cs1,[],[],H),
	dlgsreverse(Cs1,Cs).

collect(Cs,Accu,CAccu,H) :-
       	short(if(H,C)),	% danger(?): this may (further) instantiate H...
       	\+ \+ demo(C,[],_,_,true,_),	% it's provable
        copy_term(C,CT),
        cutify(CT,CCT,_),
	\+ memberCheck(CAccu,CCT),!,      %attention! 
       	collect(Cs,[C|Accu],[CCT|CAccu],H).
collect(Cs,Cs,_,_).


% pruneConjs(Conjs1,Conj,Conjs2)
%	Conjs2 is Conjs1 where only the flat conjunctions containing all the
%	literals of flat conjunction Conj are retained, but without those
%	literals of Conj.

pruneConjs([],_,[]).
pruneConjs([Conj1|Conjs1],Conj,[Conj2|Conjs2]) :-
	pruneConj(Conj,Conj1,Conj2),!,
	pruneConjs(Conjs1,Conj,Conjs2).
pruneConjs([_|Conjs1],Conj,Conjs2) :-
	pruneConjs(Conjs1,Conj,Conjs2).

% pruneConj(Conj,Conj1,Conj2)
%	Conj2 is flat conjunction Conj1 without all the literals of
%	flat conjunction Conj.

pruneConj(true,Conj1,Conj2) :-
	!,Conj2=Conj1.
pruneConj(and(Lit,Conj),Conj1,Conj2) :-
	!,pruneLit(Conj1,Lit,IntConj),
	pruneConj(Conj,IntConj,Conj2).
pruneConj(Lit,Conj1,Conj2) :-
	pruneLit(Conj1,Lit,Conj2).


% pruneLit(Conj1,Lit,Conj2)
%	Conj2 is flat conjunction Conj1 without literal Lit.

pruneLit(and(Lit1,Conj1),Lit,Conj2) :-
	Lit==Lit1,!,
	Conj2=Conj1.
pruneLit(and(Lit1,Conj1),Lit,Conj2) :-
 	!,pruneLit(Conj1,Lit,IntConj),
	(IntConj=true -> Conj2=Lit1 ; Conj2=and(Lit1,IntConj)).
pruneLit(Lit1,Lit,Conj2) :-
	Lit==Lit1,
	Conj2=true.


% updateIntro(Conj)
%	Declare every predicate of conjunction Conj that is not a Prolog
%	primitive as an introduced predicate.

updateIntro(and(Conj1,Conj2)) :-
	!,updateIntro(Conj1),
	updateIntro(Conj2).
updateIntro(true) :- !.
updateIntro(Atom) :-
	functor(Atom,Pred,Arity),
	functor(MostGenAtom,Pred,Arity),
	(sysPrim(MostGenAtom) ->
	  true					% it is a Prolog-primitive
	;(retractall(introduced(MostGenAtom)),	% it's not a Prolog-primitive
	  assert(introduced(MostGenAtom))
	 )
	).

updateIntros([]).
updateIntros([Conj|Conjs]) :-
	updateIntro(Conj),
	updateIntros(Conjs).


% buildPexsShorts(Answers,ResAtom,Atom,Ass,Pexs)
%	Pexs is a list of abduced tuples for the P-R predicate variable
%	occurring in residue atom ResAtom (of arguments Args), namely one
%	for each conjunctive answer in Answers, which were obtained for
%	the query extracted from the top-level atom Atom (of predicate R)
%	and the conjunctive assumptions Ass.  Shortcuts for P-R and R are
%	asserted as well.

buildPexsShorts([],_,_,_,[]).
buildPexsShorts([Answer|Answers],ResAtom,Atom,Ass,[Pex|Pexs]) :-
 	copy_term(q(Answer,ResAtom,Atom,Ass),
		  q(CAnswer,CResAtom,CAtom,CAss)),
	conjoin(CAnswer,CAss,CBody),
		cutify(t(CResAtom,CAtom,CBody),
			t(CuteResAtom,CuteAtom,CuteBody),_),
		write('Abducing/asserting evidence:  '),
		print(CuteResAtom),write(' <-- '),ppConj(CuteBody),nl,
        retractAllandAssert(CResAtom,CBody),
	retractAllandAssert2(CResAtom,CBody),
       		write('Asserting shortcut: '),
		print(CuteAtom),write(' <-- '),ppConj(CuteBody),nl,
        retractAllandAssert(CAtom,CBody),
	retractAllandAssert2(CAtom,CBody),
	demo(CAnswer,[],_,NewAnswer,true,_),	% DIALOGSII-primitive elimination
	conjoin(NewAnswer,CAss,NewBody),
        Pex= if(CResAtom,NewBody),
	buildPexsShorts(Answers,ResAtom,Atom,Ass,Pexs).


% buildQexsShorts(Answers,ResAtom,Atom,Ass,Qexs)
%	Qexs is a list of abduced tuples for the Q-R predicate variable
%	occurring in residue atom ResAtom (of arguments Args), namely one
%	for each conjunctive answer in Answers, which were obtained for
%	the query extracted from the top-level atom Atom (of predicate R)
%	and the conjunctive assumptions Ass.  Shortcuts for Q-R and R are
%	asserted as well.

buildQexsShorts([],_,_,_,[]).
buildQexsShorts([Answer|Answers],ResAtom,Atom,Ass,[Qex|Qexs]) :-
	copy_term(q(Answer,ResAtom,Atom,Ass),
		  q(CAnswer,CResAtom,CAtom,CAss)),
	conjoin(CAnswer,CAss,CBody),
		cutify(q(CResAtom,CAtom,CBody,CAnswer),
			q(CuteResAtom,CuteAtom,CuteBody,CuteAnswer),_),
		write('Abducing/asserting evidence: '),
		print(CuteResAtom),write(' <-- '),ppConj(CuteAnswer),nl,
		retractAllandAssert(CResAtom,CAnswer),
		retractAllandAssert2(CResAtom,CAnswer),
       		write('Asserting shortcut: '),
		print(CuteAtom),write(' <-- '),ppConj(CuteBody),nl,
        retractAllandAssert(CAtom,CBody),
	retractAllandAssert2(CAtom,CBody),
       	demo(CAnswer,[],_,NewAnswer,true,_),	% DIALOGSII-primitive elimination
        Qex= if(CResAtom,NewAnswer),
       	buildQexsShorts(Answers,ResAtom,Atom,Ass,Qexs).



retractAllandAssert(Atom,Body) :- 
       	copy_term(short(if(Atom,Body)),short(if(CAtom,CBody))),
        copy_term(short(if(CAtom,CBody)),short(if(C2Atom,C2Body))),
        copy_term(short(if(C2Atom,C2Body)),short(if(C3Atom,C3Body))),
        cutify(short(if(CAtom,CBody)),CuteSCT,_),
        clause(short(if(C2Atom,NCBody)),true),
        cutify(short(if(C2Atom,NCBody)),Cute2SCT,_),
	Cute2SCT == CuteSCT,!,
        retract(short(if(C3Atom,C3Body))),
        retractAllandAssert(Atom,Body),!.
retractAllandAssert(Atom,Body) :-
       	assert(short(if(Atom,Body))).


retractAllandAssert2(Atom,Body) :- 
       	copy_term(sparseshort(if(Atom,Body)),sparseshort(if(CAtom,CBody))),
        copy_term(sparseshort(if(CAtom,CBody)),sparseshort(if(C2Atom,C2Body))),
        copy_term(sparseshort(if(C2Atom,C2Body)),sparseshort(if(C3Atom,C3Body))),
        cutify(sparseshort(if(CAtom,CBody)),CuteSCT,_),
        clause(sparseshort(if(C2Atom,NCBody)),true),
        cutify(sparseshort(if(C2Atom,NCBody)),Cute2SCT,_),
	Cute2SCT == CuteSCT,!,
       	retract(sparseshort(if(C3Atom,C3Body))),
        retractAllandAssert2(Atom,Body),!.
retractAllandAssert2(Atom,Body) :-
      	assert(sparseshort(if(Atom,Body))).








% retractOpShorts(Schema)
%	Retract all shortcuts for the operators of the current predicate.

retractOpShorts(Schema) :-
	short(if(Head,_)),
	functor(Head,Pred,Arity),
	name(Pred,PredStr),
       (p(Schema,PName),
	name(PName,PStr),
	name('_',UStr),
	append(PStr,UStr,PUStr),
	append(PUStr,_,PredStr);
	q(Schema,QName),
	name(QName,QStr),
	name('_',UStr),
	append(QStr,UStr,QUStr),
	append(QUStr,_,PredStr)),!,	% "p_..." or "q_..."
	functor(GenH,Pred,Arity),
	retractall(short(if(GenH,_))),
	retractOpShorts(Schema).
retractOpShorts(_).


% retractOpSparseShorts
%	Retract all shortcuts for the operators of the current predicate.

retractOpSparseShorts(Schema) :-
	sparseshort(if(Head,_)),
	functor(Head,Pred,Arity),
	name(Pred,PredStr),
       (p(Schema,PName),
	name(PName,PStr),
	name('_',UStr),
	append(PStr,UStr,PUStr),
	append(PUStr,_,PredStr);
	q(Schema,QName),
	name(QName,QStr),
	name('_',UStr),
	append(QStr,UStr,QUStr),
	append(QUStr,_,PredStr)),!,	% "p_..." or "q_..."
	functor(GenH,Pred,Arity),
	retractall(sparseshort(if(GenH,_))),
	retractOpSparseShorts(Schema).
retractOpSparseShorts(_).






% unzip(Couples,List1,List2)
%	List[1,2] is the concatenation of the lists in the [1st,2nd]
%	argument positions in the couple/2 elements of list Couples.

unzip([],[],[]).
unzip([couple(Xs,Ys)|Couples],List1,List2) :-
	unzip(Couples,SuffList1,SuffList2),
	append(Xs,SuffList1,List1),
	append(Ys,SuffList2,List2).

% -------------------------------------------------------------------------- %
remove_identicals([],_).
remove_identicals([H|T],[H|NT]) :-
        remove_identical(H,T,NT),
        remove_identicals(T,NT).

remove_identical(_,[],[]).
remove_identical(H,[H1|T1],[H1|NT]) :-
	cutify(H,CH,_),
	cutify(H1,CH1,_),
        CH==CH1,!,
	remove_identical(H,T1,NT).
remove_identical(H,[H1|T1],[H,H1|NT]) :-
	remove_identical(H,T1,NT).




% induce(Pev,Qev,PMode,QMode,Pinsts,Qinsts)
%	Pinsts and Qinsts are the conjunctive instances of the P-R
%	and Q-R predicate variables obtained by applying the Program Closing
%       Method to the corresponding tuples in lists Pev and Qev using the modes
%       PMode and QMode
% Simplifying assumption: admissibility is an equivalence relation, in
% which case all connected components of a graph are strongly connected,
% hence cliques.

induce(Pev,Qev,PMode,QMode,Pinsts,Qinsts) :-
	%length(Qev,L), L>0 -> %if decomposition operator is a correct one
	                         %or no sparseness pblm occured
		writeln('Entering the Program Closing Method with the following evidence'),
		cutify(Pev,CPev,_),
		cutify(Qev,CQev,_),
		writeln('solve evidence:'),ppList(CPev),nl,
		writeln('compose evidence:'),ppList(CQev),nl,
		%writeln(pmode(PMode)),
		%writeln(qmode(QMode)),
        dlgsreverse(Pev,Pev1),	% make counterpart positions coincide
	dlgsreverse(Qev,Qev1),
	get_cliques(Qev1,QMode,Qcliques),
		%writeln('Step1: Q cliques'),ppList(Qcliques),nl,
        findPositions(Qcliques,Qev1,QPos), %find the positions of the clauses in the cliques
	prune(Qcliques,Pev1,PMode,Qcliques1,Pev2,QPos), % step 2
		%writeln('Step2: New P evidence'),ppList(Pev2),nl,
		%writeln('Step2: New Q cliques'),ppList(Qcliques1),nl,
	buildInsts(Qcliques1,Qinsts),		% step 3
	writeln('Result of the Program Closing Method:'),
	cutify(Qinsts,CQinsts,_),
		writeln('Clauses for compose:'),ppClauses(CQinsts),nl,
	get_cliques(Pev2,PMode,Pcliques),	
	%writeln('Step4: P cliques'),ppClauses(Pcliques),nl,
	buildInsts(Pcliques,Pinsts),	
        cutify(Pinsts,CPinsts,_),				% step 4
	writeln('Clauses for solve:'),ppClauses(CPinsts),nl
        . %sparseness pblm. occured, length(Pev)>>length(Qev)



%findPositions(Cliques,Ev,Pos) iff Pos is a list of list of positions of clauses in Cliques
%according to the list of clauses Ev

findPositions([],_,[]).

findPositions([HCliques|TCliques],Ev,[HPos|TPos]) :-
	positions2(HCliques,Ev,HPos),
	findPositions(TCliques,Ev,TPos).

%positions2(Clique,Ev,Pos) iff list Pos is the list of positions of clauses in list Clique according
%to the positions of the clauses in list Ev

positions2([],_,[]).
positions2([Clause|TClauses],Ev,[Pos|TPos]) :- 
	posOfClauseinEv(Clause,Ev,Pos),
	positions2(TClauses,Ev,TPos).

posOfClauseinEv(Clause,Ev,Pos) :- 
	posOfClauseinEv(Clause,Ev,1,Pos).

posOfClauseinEv(Clause,[HEv|_],Pos,Pos):-
	Clause==HEv,!.

posOfClauseinEv(Clause,[_|TEv],Acc,Pos) :-
	NewAcc is Acc + 1,
	posOfClauseinEv(Clause,TEv,NewAcc,Pos).


% getCliques(Atoms,Mode,Cliques)
%	see file cliques.pl by Esra Erdem


% getCompos(Atoms,Mode,IPPos,RPPos,APPos,Compos)
%	Compos is the list of connected components (through the admissibility
%	relation based on mode Mode, which is *assumed* to be an equivalence
%	relation) of the atom list Atoms.

getCompos(Atoms,Mode,IPPos,RPPos,APPos,Compos) :-
	components(Atoms,1,Mode,IPPos,RPPos,APPos,[],Compos).

components([],_,_,_,_,_,Cs,Cs).
components([A|As],Pos,Mode,IPPos,RPPos,APPos,Cs,NewCs) :-
	placement(Cs,A,Pos,Mode,IPPos,RPPos,APPos,IntCs),
	NewPos is Pos + 1,
	components(As,NewPos,Mode,IPPos,RPPos,APPos,IntCs,NewCs).

placement([],A,Pos,_,_,_,_,[clique([Pos],A)]).
placement([C|Cs],A,Pos,Mode,IPPos,RPPos,APPos,NewCs) :-
       	C=clique(Ps,OldMSG),
       	((clauseMsg(OldMSG,A,NewMSG), 
          NewMSG = if(H,B),  %take the appropriate parts of the evidence for admissi. check
         vars(H,HVars),
	 vars(B,BVars),
	 dlgsSublist(BVars,HVars)) ->
         H =.. [_|Args],     %added 
         append([B],Args,MSGItem), %added 
	(admissible(MSGItem,Mode,IPPos,RPPos,APPos) ->       %admissible(NewMSG,Mode)
	 (NewC=clique([Pos|Ps],NewMSG),
       	  NewCs=[NewC|Cs])
	;(placement(Cs,A,Pos,Mode,IPPos,RPPos,APPos,TailNewCs),
	  NewCs=[C|TailNewCs]));
	(placement(Cs,A,Pos,Mode,IPPos,RPPos,APPos,TailNewCs),
	 NewCs=[C|TailNewCs])).


% prune(Qcliques,Pev,Pmode,Qcliques1,Pev1,QPos)
%	Qcliques1 has the cliques of Qcliques whose counterpart subsets
%	in Pev do not have admissible msg's (according to mode Pmode).
%	Pev1 has the tuples of Pev that do not have counterparts among
%	the tuples for Q or whose counterparts do not participate in a
%	clique of Qcliques1.

prune(Qcliques,Pev,Pmode,Qcliques1,Pev1,QPos) :-
       	eliminate(Qcliques,QPos,Pev,Pmode,Qcliques1,ElimPps),
       	sort(ElimPps,Pos),
       	length(Pev,Pcount),
       	iota(Pcount,AllPos),
	ordDiff(AllPos,Pos,RemPos),
       	dlgsselect(RemPos,Pev,Pev1).

eliminate([],_,_,_,[],[]).
eliminate([Clique|Qcliques],[QPos|TQPos],Pev,Pmode,Qcliques1,ElimPps) :-
      	dlgsreverse(QPos,RevPos),
       	dlgsselect(RevPos,Pev,Counterpart),
        ((clauseMsg(Counterpart,MSG),	%msg(Counterpart,MSG),
         MSG = if(HMSG,BMSG),
         vars(BMSG,Vars1),
	 vars(HMSG,Vars2),
	 dlgsSublist(Vars1,Vars2)) ->
	 (admissibleClause(MSG,Pmode) ->
       	  eliminate(Qcliques,TQPos,Pev,Pmode,Qcliques1,ElimPps)
	;(eliminate(Qcliques,TQPos,Pev,Pmode,TailQcliques1,TailElimPps),
	  Qcliques1=[Clique|TailQcliques1],
	  append(QPos,TailElimPps,ElimPps)
         ));         
          eliminate(Qcliques,TQPos,Pev,Pmode,TailQcliques1,TailElimPps),
	  Qcliques1=[Clique|TailQcliques1],
	  append(QPos,TailElimPps,ElimPps)).

% buildInsts(Cliques,Insts)
%	Conjunctions Insts are built from the
%	msgs of the cliques Cliques.

buildInsts([],[]).
buildInsts([Clique|Cliques],[Clause|Insts]) :-
        clauseMsg(Clique,Clause),
	/*Clause=if(H,B),
	vars(H,HVars),
	vars(B,BVars),
	dlgsSublist(HVars,BVars),!,*/
	buildInsts(Cliques,Insts).
/*buildInsts([_|Cliques],Insts) :-        
	buildInsts(Cliques,Insts).*/




% -------------------------------------------------------------------------- %

% evaluate(Schema,Strategy,Level,Qinsts,Pinsts,Qev,Pev,PMode,CurrPgm,Infos,TopPred,Pgm)
%	Program Pgm (for top-level predicate TopPred) is obtained from
%	current program CurrPgm by instantiating its predicate variables
%	P-R and Q-R based on their instances Pinsts and Qinsts;
%	this instantiation is either direct or through recursive synthesis
%	(in which case some of Pev are used to instantiate P-R).  Infos
%	contains information about the chain of D&C-defined predicates
%	in CurrPgm.

evaluate(Schema,Strategy,Level,_,_,Qev,Pev,PMode,CurrPgm,Infos,TopPred,Pgm) :-
       		write('Please evaluate the Program Closing Method results: '),
		writeln('need for recursive synthesis? [yes/no]'),
		readLine(Answer),Answer="yes",
	!, append(_,[info(ParamRoles,DecRinfo,_,_,_,_)],Infos),!,
	Schema = dc, Strategy = divide_and_conquer_strategy1, %only for dc schemas and strategy1
	%findCount(FormVars,'Result',Y),
	DecRinfo=decRinfo(_,_,TailInfos),
	length(TailInfos,T),
	%feasible(Y,T), %see below (cons. of new param. types and hints)
	append(PrefixPgm,[NonRecClause,RecClause,Decompose],CurrPgm),!,
	RecClause=if(Head,Body),
	assert(introduced(Head)),
  % construct NewPred
	functor(Head,CurrPred,Arity),
	name(CurrPred,[C|Cs]),	
	q(Schema,QName),
	name(QName,QStr),
	name('_',UStr),
	append(QStr,UStr,QUStr),		
	append(QUStr,[C|Cs],NewPredStr),
	name(NewPred,NewPredStr),	   % e.g. "q_r..."
  % construct NewParamTypes
       (T=1 -> findInfo(ParamRoles,'Result',RPinfos),
	       RPinfos=[pi(_,RPname,RPtype)],
	       NewIPname=[84|RPname],			% "T..."
	       DecRinfo=decRinfo(_,HeadInfos,_),	
               findInfo(ParamRoles,'Induction',IPinfo),
               IPinfo=_,  
               findInfo2(ParamRoles,'Passive',APinfos),
	       dlgsreverse(APinfos,RevAPinfos),
	       buildDNs(RevAPinfos,SomeDecls,[],SomeAPnames,[]),
	       dlgsreverse(HeadInfos,RevHeadInfos),
	       buildDNs(RevHeadInfos,NewParamTypes,[NewIPname:RPtype,
			RPname:RPtype|SomeDecls],APnames,SomeAPnames),
       	       Hints = [hint('Induction',[NewIPname]),hint('Result',[RPname]),hint('Passive',APnames),hint(decr,[])];
               T=2,
	       findInfo(ParamRoles,'Result',RPinfos),
	       RPinfos=[pi(_,RPname,RPtype)],
	       NewIPname=[84|RPname],	
               NewAPname=[84,50|RPname],	% "T..."
	       DecRinfo=decRinfo(_,HeadInfos,_),	
               findInfo(ParamRoles,'Induction',IPinfo),
               IPinfo=_,  
               findInfo2(ParamRoles,'Passive',APinfos),
	       dlgsreverse(APinfos,RevAPinfos),
	       buildDNs(RevAPinfos,SomeDecls,[],SomeAPnames,[]),
	       dlgsreverse(HeadInfos,RevHeadInfos),
	       buildDNs(RevHeadInfos,NewParamTypes,[NewIPname:RPtype,
			NewAPname:RPtype,RPname:RPtype|SomeDecls],APnames,SomeAPnames),
       	       Hints = [hint('Induction',[NewIPname]),hint('Result',[RPname]),hint('Passive',[NewAPname|APnames]),hint(decr,[])]),
	       
        %construct IntPgm
      	getPartialPgm(Schema,Body,NewPred,_,Inst),
	assert(introduced(Inst)),
	length(Pev,Pcount),
	length(Qev,Qcount),
        Sparseness is Pcount-Qcount,
	((Sparseness>=3,Level>1) -> %a sparse set of examples hit
         writeln('You must know the relation whose clauses are given below.'),
	 writeln('Please answer the queries about this relation'),
         displayRelation(CurrPred),	
	 retractOpSparseShorts(Schema),
	 NewLevel is Level+1, %synthesis level is incremented by one
	 writeln('Calling DialogsII for a new synthesis:'),
	 IPinfo=[pi(_,IPname,IPtype)],
	 RPinfos=[pi(_,RPname,RPtype)],
         dlgsreverse(APinfos,RevAPinfos),
	 buildDNs(RevAPinfos,APdecls,[],NAPnames,[]),
	 append([IPname:IPtype],APdecls,ParamTypes1),
	 append(ParamTypes1,[RPname:RPtype],ParamTypes),
	 ppDecl(CurrPred,ParamTypes),
	 NHints = [hint('Induction',[IPname]),hint('Result',[RPname]),hint('Passive',NAPnames),hint(decr,[])],                                    dialogsII(Schema,Strategy,NewLevel,CurrPred,ParamTypes,NHints,[],[],CurrPred,QPgm),
	 append(PrefixPgm,QPgm,Pgm)
       ;(Delta is Pcount - Qcount,
	firstM(Delta,Pev,PrePev),
	get_cliques(PrePev,PMode,Pcliques),
	buildInsts(Pcliques,Pinsts),      %changed acc. to open pgm. approach
	TopPredClauses=[NonRecClause,RecClause,Decompose],
	functor(GenH,CurrPred,Arity),
	retractall(introduced(GenH)),
	retractall(introduced(Inst)),
	dlgsreverse(Pinsts,RPinsts),
	append(TopPredClauses,RPinsts,Clauses),
	append(PrefixPgm,Clauses,IntPgm),
		writeln('So far, the synthesized program is:'),
		ppPgm(IntPgm),
		writeln('Calling DIALOGSII with the predicate declaration'),
		ppDecl(NewPred,NewParamTypes),
	mute,
	NewLevel is Level+1, %synthesis level is incremented by one
	dialogsII(Schema,Strategy,NewLevel,NewPred,NewParamTypes,Hints,Infos,IntPgm,TopPred,Pgm))).
evaluate(_,_,_,Qinsts,Pinsts,_,_,_,CurrPgm,_,_,Pgm) :-	% w>0 --> accept
	append(PrefixPgm,[NonRecClause,RecClause,Decompose],CurrPgm),!,
	RecClause=if(Head,_),		% allow primitive elimination
       	retractall(introduced(Head)),	% by declaring CurrPred as an
	assert(introduced(Head)),	% introduced predicate
	functor(Head,Pred,Arity),	% restore CurrPred as a
	functor(GenH,Pred,Arity),	% non-introduced predicate,
	retractall(introduced(GenH)),	% for backtracking synthesis
       /*	(Qinsts = [] -> RecClause = if(_,Body), 
	                  lastLiteral(Body,Literal),
	                  functor(Literal,F,N), functor(NLiteral,F,N),
			  NQinsts = [if(NLiteral,true)];true),*/
	dlgsreverse(Pinsts,RPinsts),
	/*(Qinsts = [] -> append(RPinsts,NQinsts,NewClauses);*/
	                  dlgsreverse(Qinsts,RQinsts),
		          append(RPinsts,RQinsts,NewClauses),
        append(PrefixPgm,[NonRecClause,RecClause,Decompose],NewClauses2),
	append(NewClauses2,NewClauses,Pgm).



% feasible(Y,T)
%	Decide whether the underlying d&c schema is powerful enough to
%	support a recursive call to the synthesizer.

feasible(1,1) :- !.
feasible(_,_) :-
	writeln('However, this prototype implementation cannot handle this'),
	writeln('particular situation, as its divide-and-conquer schema is'),
	writeln('not powerful enough.  We are sorry for the inconvenience.'),
	fail.


% buildDNs(ParamInfos,Decls,AccuDecls,Names,AccuNames)
%	Decls is Name:Type pairs extracted from ParamInfos <> AccuDecls;
%	Names is Names extracted from ParamInfos <> AccuNames;

buildDNs([],Decls,Decls,Names,Names).
buildDNs([pi(_,Name,Type)|ParamInfos],Decls,AccuDecls,Names,AccuNames) :-
	buildDNs(ParamInfos,Decls,[Name:Type|AccuDecls],Names,[Name|AccuNames]).


% getPartialPgm(Schema,Conj,Pred,IncConj,Atom)
%	IncConj is Conj without the Q/P-Relation atom at the end,
%	and Atom is the atom where the Q/P-Relation 
%	is replaced by predicate Pred.

getPartialPgm(Schema,OpenPred,Pred,true,Atom) :-
	OpenPred =.. [OpenPredName|Args],
	name(OpenPredName,PredStr),
        p(Schema,PName),
	name(PName,PStr),
	name('_',UStr),
	append(PStr,UStr,PUStr),
	append(PUStr,_,PredStr),
	Atom=..[Pred|Args].
getPartialPgm(Schema,OpenPred,Pred,true,Atom) :-
	OpenPred =.. [OpenPredName|Args],
	name(OpenPredName,PredStr),
	q(Schema,QName),
	name(QName,QStr),
	name('_',UStr),
	append(QStr,UStr,QUStr),
	append(QUStr,_,PredStr),
       	Atom=..[Pred|Args].
getPartialPgm(Schema,and(Lit,Conj),Pred,IncConj,Atom) :-
	getPartialPgm(Schema,Conj,Pred,IntConj,Atom),
	(IntConj=true -> IncConj=Lit ; IncConj=and(Lit,IntConj)).



% addToOpenPgm(Insts,IncClause,Clauses)
%	Clauses contains the clauses obtained by conjoining the flat
%	conjunctions Insts to the body (a flat conjunction) of IncClause;
%	these clauses are syntactically simplified on-the-fly by elimination
%	of the DIALOGSII primitives.

addToOpenPgm([],_,[]).
addToOpenPgm([Inst|Insts],IncClause,[Clause|Clauses]) :-
        IncClause=if(Head,IncBody),
        conjoin(IncBody,Inst,Body),
        copy_term(if(Head,Body),if(CHead,CBody)),
        demo(CBody,[],_,NewBody,true,_),    % DIALOGSII-primitive elimination
        Clause=if(CHead,NewBody),
        addToOpenPgm(Insts,IncClause,Clauses).

%dlgsSublist(L1,L2) iff list L1 is a sublist of L2.
%memberCheck is used.

dlgsSublist([],L) :- list(L).
dlgsSublist([H|T],L) :-
	memberCheck(L,H),
        dlgsSublist(T,L).

%displayRelation displays the asserted shortcuts of the relation Pred.


displayRelation(Pred) :- 
	sparseshort(if(Head,Body)),
	retract(sparseshort(if(Head,Body))),
	Head =.. [Pred|_],
	cutify(if(Head,Body),if(CHead,CBody),_),
	ppClauses([if(CHead,CBody)]),
	displayRelation(Pred).
displayRelation(_).







%thetasubsumes(Term1,Term2) iff there exists a substitution S s.t. S
%applied to list Term1 is a subterm of Term2.
%careful: non-deterministic.
%e.g. thetasubsumes(C=[B],[C=[A],B=A]).


thetasubsumes(Conj1,Conj2) :- 
	sublist(Conj1,Conj2).







%removeRedundant(Answers,ReducedAnswers) iff list ReducedAnswers is
%list Answers without its redundant elements (according to
%\theta-subsumption generality).
%Assumption: elements are compound terms.
%Succeeds only once.
%e.g. removeRedundant([[C=[A],B=A],[C=[B]]],R), R = [C=[B]] ?;no.
 
removeRedundant(Answers,ReducedAnswers) :-
	length(Answers,L),
	removeRedundant(Answers,1,L,ReducedAnswers),!.

removeRedundant(LeftAns,N,L,LeftAns) :- N>L.
removeRedundant([Ans1|Answs],N,L,ReducedAnsws) :-
	N1 is N+1,
	checkGen(Ans1,Answs,N1,NewN,LeftAnsws),
      	append(LeftAnsws,[Ans1],NewAnsws), 
       	removeRedundant(NewAnsws,NewN,L,ReducedAnsws).


%checkGen(Ans,Answs,N,N1,RestAnsws) iff list RestAnsws is list Answs
%without its elements that are \theta-subsumed by term Ans
%N1 is N + X where X is the number of these elements.

checkGen(_,[],N,N,_).
checkGen(Ans,[Ans1|Answs],N,N1,RestAnsws) :-
	copy_term(Ans,CAns),
	copy_term(Ans1,CAns1),
	thetasubsumes(CAns,CAns1),!,
	NewN is N +1,
	checkGen(Ans1,Answs,NewN,N1,RestAnsws).
checkGen(Ans,[Ans1|Answs],N,N1,[Ans1|RestAnsws]) :-
	checkGen(Ans,Answs,N,N1,RestAnsws).

%makeListofList(Conjs,ListofLists) iff ListofLists is the list of
%lists that are obtained from comma-ed conjunction terms.
%e.g. makeListofList([(A=B,C>D,odd(E)),(K>L,Q=R)],List), 
%List = [[A=B,C>D,odd(E)],[K>L,Q=R]].

makeListofList([],[]).
makeListofList([Conj1|ConjRest],[LConj1|LConjRest]) :-
	makeList(Conj1,LConj1),
	makeListofList(ConjRest,LConjRest).

makeList(Conj,[Conj]) :- Conj =.. [F|_],F \== ',',!.
makeList(Conj,[Arg1|ConjList]) :-
	Conj =.. [F|Args],
	F == ',',
	Args = [Arg1|RestArgs],
	RestArgs = [RestConj],
	makeList(RestConj,ConjList).


%lastLiteral(Conj,Literal) iff Literal is the last literal in conjunction Conj. 
lastLiteral(true,true) :- !.

lastLiteral(and(_,Conj2),Literal) :-
	!,lastLiteral(Conj2,Literal).

lastLiteral(C,C) :-
	compound(C).