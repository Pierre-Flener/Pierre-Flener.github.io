%**************************************************
%*   Predicates related to admissibility          *
%*    Written by: Serap Yilmaz (1996)             *
%*    Updated by: Serap Yilmaz (1997)             *
%**************************************************

%separateArgs(Args,Count,List1,List2)
%List1 is first Count arguments of list Args, List2 is the rest

separateArgs(Args,0,[],Args):-!.
separateArgs([T1|Tail1],Count,[T1|Tail2],Rest):-
        Count >= 1,
        NewCount is Count-1,
        separateArgs(Tail1,NewCount,Tail2,Rest). 


%separateArgs2(Args,Count1,Count2,List1,List2)
%List1 is list of lists whose length are Count2+1
%List2 is the rest of Args, that is Args=[flatten(List1),List2]
%used in admissibleDPC

separateArgs2(Args,_,0,[],Args):-!.
separateArgs2(Args,T,Count,[FirstTyY|Tail2],Zlist):-
         TY_Y is T+1, %to take TS1,TS2,..TSt,S
         separateArgs(Args,TY_Y,FirstTyY,Rest), %Rest=[TR1,TR2,...,TRt,Zs]
         NewCount is Count-1,
         separateArgs2(Rest,T,NewCount,Tail2,Zlist).      

%collectArgs2(Atom,Start,Count,Args) iff Args list of arguments of
%atom Atom at positions <Start+1...Start+Count.

 
collectArgs2(Atom,Start,Count,Args) :-
	genNumber(Start,Count,Pos),
	collectArgs(Atom,Pos,Args).


%unionofConstituents(List,ConstList)
%ConstList is the list of constituents of terms in List
%mode(+,-)
%used in admissibleDS(DPC)

unionofConstituents([],[]). %clause indexing
unionofConstituents([H|T],ConstList) :-
        constituents2(H,ConstH),
        unionofConstituents(T,ConstListT),
        append(ConstH,ConstListT,ConstList).           



%legalconj(F) iff F is a legal conjunction
%that is F is not variable, not a literal with equality atom, it is flat conjunction
%mode(+)

legalconj(F):- \+var(F),F=true,!.
legalconj(F):-
         \+var(F),literal(F),!.
legalconj(F):- 
         \+var(F),F=and(Literal,Conj),
         literal(Literal),
         legalconj(Conj).


%literal(L) iff L is a literal
%mode(+)
 
literal(L):-
        compoundterm(L),!.
literal(L):-
        L=neg(Atom),
        compoundterm(Atom).


%compoundterm(T) iff T is compound prolog term
%mode(+)

compoundterm(T):-
        functor(T,F,Arity),
        F \== '=',
        Arity>0.

           
% constituents2(T,Ls)
%	Ls is the list of constituents of term T
%	(repetitions included), as they appear in T from left to right.
% NB. Computing the *set* of constituents would be less efficient.

constituents2(T,Ls) :-
	constituents2(T,Ls,[]).

constituents2(T,[T|Ls],Ls) :-
	var(T),!.
constituents2(T,[T|Ls],Ls) :-
	atomic(T),T\==[],!.
constituents2(T,Ls,Acc) :-
	T=..[_|Ts],
	constituents21(Ts,Ls,Acc).

constituents21([],Ls,Ls).
constituents21([T|Ts],Ls,Acc) :-
        constituents21(Ts,Acc1,Acc),
        constituents2(T,Ls,Acc1).


%subset2(L1,L2) holds iff list L1 is a subset of list L2
%L1 and L2 might include variables

subset2([],_). %clause indexing
subset2([H|T],L2):-
	memberCheck(L2,H),
	subset2(T,L2).


%vertices(Term,Vertices) iff list Vertices is a multi-set of constituents
%of Term.


vertices(V,[V]) :- var(V),!.
vertices(A,[A]) :- atomic(A),!.
vertices([],[nil]) :- !.
vertices(C,[F|Rest]) :-
	compound(C),
	C =..[F|Args],
	vertices2(Args,Rest).


vertices2([V],[V]) :- var(V),!.
vertices2([[]],[nil]) :- !.
vertices2([],[]) :- !.
vertices2([HArgs|TArgs],Vertices) :-
	vertices(HArgs,HVertices),
	vertices2(TArgs,TVertices),
	append(HVertices,TVertices,Vertices).

%leaves(T,Ls) iff list Ls is the set of variables and constants occurring in term T.  

leaves(T,Ls) :-
	leaves(T,Ls,[]).

leaves(T,[T|Ls],Ls) :-
	var(T),
	(\+memberCheck(Ls,T)),!.
leaves(T,Ls,Ls) :-
	var(T),!.
leaves(T,[T|Ls],Ls) :-
	atomic(T),T\==[],(\+memberCheck(Ls,T)),!.
leaves(T,Ls,Ls) :-
	atomic(T), T\==[],!.
leaves(T,Ls,Acc) :-
	T=..[_|Ts],
	leaves1(Ts,Ls,Acc).

leaves1([],Ls,Ls).
leaves1([T|Ts],Ls,Acc) :-
        leaves1(Ts,Acc1,Acc),
        leaves(T,Ls,Acc1).

%sharedLeaves(Ts,SLs) iff list SLs is the set of shared leaves of all 
%components of list of terms Ts.

sharedLeaves([L],SL) :- leaves(L,SL).
sharedLeaves( [HT1s,HT2s|TTs],SLs) :-
	leaves(HT1s,HTLs),
	sharedLeaves([HT2s|TTs],TTLs),
	sharedLeaves1(HTLs,TTLs,SLs).


sharedLeaves1([],_,[]).
sharedLeaves1([H|T],L,[H|TSLs]) :-
	memberCheck(L,H),!,
	sharedLeaves1(T,L,TSLs).
sharedLeaves1([_|T],L,TSLs) :-
	sharedLeaves1(T,L,TSLs).

%listDifference(L1,L2,L3) iff list L3 is the difference of lists L1 and L2.

listDifference([],_,[]).
listDifference([H|T],L2,L3) :-
	memberCheck(L2,H),!,
	listDifference(T,L2,L3).
listDifference([H|T],L2,[H|L3]) :-
	listDifference(T,L2,L3).


%admissibleClause(Clause,Mode) iff Clause is admissible with respect to Mode.
%admissibleClause(if(ds([B2],[B1,B2],B1),B1>=B2),mode(may,res,may)).
%not admissibleClause(if(ds([B1,B2],[B3,B2]),B1>B2),mode(may,res,may)).
%not admissibleClause(if(dpc(B1,[B3],[B2,B1]),B1>B3),mode(may,must,res,may)).
%admissibleClause(if(dpc(B2,[B1],[B1,B2],B1),B1=<B2),mode(may,must,res,may)).


admissibleClause(Clause,Mode) :-
	admissible1(Clause,Mode),
	admissible2(Clause,Mode).


%admissible1(Clause,Mode) iff 
%leaves(Res)\SharedLeaves(Res) is a subset of leaves(<May,Mayall,Must,Body>) U
%{0,nil...}, where Body is the body conjunction, where Clause=if(Head,Body).

admissible1(Clause,Mode) :-
	Clause = if(Head,Body),
	collectTerm(Head,Mode,must,Must),
	collectTerm(Head,Mode,res,Res),
	collectTerm(Head,Mode,may,May),
	collectTerm(Head,Mode,mayall,MayAll),
	leaves([Must,May,MayAll,Body,0,nil],Leaves),
	leaves(Res,LRes),
     	(length(Res,L), L>1 ->
         (sharedLeaves(Res,SharedLeaves),
	  listDifference(LRes,SharedLeaves,RLeaves));
	  leaves(Res,RLeaves)),
	leavesSublist(RLeaves,Leaves).
	
%admissible2(Clause,Mode) iff
%for all 1=< j =<k: Mustj is a subset of <Resj,Body>, where Body is the body 
%conjunction, where Clause=if(Head,Body).

admissible2(Clause,Mode) :-
	Clause = if(Head,Body),
	collectTerm(Head,Mode,must,Must),
	collectTerm(Head,Mode,res,Res),
	verticesOfTerms(Res,Vertices1),
	vertices(Body,Vertices2),
	verticesOfTerms(Must,Vertices3),
	append(Vertices1,Vertices2,Vertices4),
	verticeSublist(Vertices3,Vertices4).

%collectTerm(Head,Mode,Item,Terms) iff Terms is the list of terms 
%at the corresponding positions in Head of a mode item, e.g. must.
%e.g. collectTerm(solve([A|B],D,C),mode(may,res,may),may,[[A|B],C]). 


collectTerm(Head,Mode,Item,Terms) :-
	Head =.. [_|Args1],
	Mode =.. [_|Args2],
	collectTerm2(Args1,Args2,Item,Terms).

collectTerm2([],_,_,[]).
collectTerm2([HTerm|TTerm],[Item|TArgs],Item,[HTerm|Rest]) :-
	collectTerm2(TTerm,TArgs,Item,Rest),!.
collectTerm2([_|TTerm],[Item|TArgs],Item2,Terms) :-
	Item \== Item2,
	collectTerm2(TTerm,TArgs,Item2,Terms).

%leavesOfTerms(Terms,Leaves) iff list Leaves is the list of leaves of 
%Terms
 
leavesOfTerms([],[]).
leavesOfTerms([HTerms|TTerms],Leaves) :-
	leaves(HTerms,HLeaves),
	leavesOfTerms(TTerms,TLeaves),
	append(HLeaves,TLeaves,Leaves).


%verticesOfTerms(Terms,Vertices) iff list Vertices is the list of vertices of 
%Terms 

verticesOfTerms([],[]).
verticesOfTerms([HTerms|TTerms],Vertices) :-
	vertices(HTerms,HVertices),
	verticesOfTerms(TTerms,TVertices),
	append(HVertices,TVertices,Vertices).


%howMany(T,L,C) iff natural number C is the number of occurences of term T in lis%t L.

howMany(_,[],0).
howMany(T,[HL|Rest],C) :-
	T == HL,
	!,howMany(T,Rest,RestC),
	C is RestC +1.
howMany(T,[_|Rest],C) :-
	howMany(T,Rest,C).



%verticeSublist(L1,L2) iff multi-set L1 is a subset of multi-set L2.

verticeSublist([],_).
verticeSublist(L1,L2) :-
	L1 = [H|T],
	howMany(H,L1,C1),
	howMany(H,L2,C2),
	C1 =< C2,
	verticeSublist(T,L2).


%leavesSublist(L1,L2) iff set L1 is a subset of set L2.

leavesSublist([],_).
leavesSublist([H|T],L2) :-
	memberCheck(L2,H),
	leavesSublist(T,L2).






%********************************************************************
%Written by: Esra Erdem                                             *
%********************************************************************

%% IMPORTANT: This pgm is implemented in SICSTUS Prolog...
%% Don't forget to include the appropriate path names for the files loaded...

%:- ensure_loaded(library(lists)).	 % list operations.


/* get_cliques(Examples, Mode, Cliques) iff Cliques is a minimum clique cover
	of the (compatibility) graph of Examples wrt a given (construction) Mode,
   where Examples is a list of the nodes of a graph, i.e., each node is an atom,
	 Mode is an atom,
	 Cliques is a list of lists (of nodes). */



get_cliques(Examples, Mode,Cliques) :-
        create_cliques(Examples, Mode, [], Examples,Cliques0),!,
	eliminate_unnecessary_cliques(Cliques0,Cliques0,[],Cliques).

/* create_cliques(CurrentExamples, Mode, CurrentCliques, Examples, Cliques) iff
	Cliques is a clique cover of the (compatibility) graph of Examples
	wrt a given (construction) Mode,
   where ... */
	
create_cliques([],_, Cliques0,_,Cliques0).
create_cliques([HCurExamples|TCurExamples], Mode, Cliques0, Examples,Cliques):-
	get_connected_nodes(HCurExamples, Examples, Mode, [],Connecteds),
	new_clique(Connecteds,HCurExamples,Cliques0,NewCliques),
	create_cliques(TCurExamples, Mode,NewCliques,Examples,Cliques).


/* get_connected_nodes(AnExample,Examples, Mode, CurrentConnecteds,Connecteds)
	iff Connecteds is a list of nodes such that they occur before the
	node AnExample in the list of nodes Examples and they are connected to
	the node AnExample,
   where ... */

/* Note that, the heuristic is applied at this point: the nodes are labeled
   according to their occurances in the list of nodes, i.e., in the list
   [2,3,4], 2 has a label of 1, and 3 has a label of 2, and 4 has a label of 3;
   so, we only check the connectedness of a node w/ the ones that occur before
   that node in the given list of nodes, i.e., we check the connectedness of 3
   w/ only 2, and we check connectedness of 4 w/ 2 and 3. As a result what we
   get is W = { j | j < i and {i,j} are connected in G} where G is the given
   list of nodes representing a graph. */


/* We will replace
	connected(AnExample,HExamples) 
   with 
	lgg([AnExample,HExamples],Lgg),
        admissible(Lgg,Mode)
   which stands for
	compatible(AnExample,HExamples,Mode)
*/

connected(AnExample,HExamples,Mode):-
	clauseMsg(AnExample,HExamples,Lgg),
	Lgg = if(H,B),
	vars(H,HVars),
	vars(B,BVars),
	dlgsSublist(BVars,HVars),
	admissibleClause(Lgg,Mode).
	

get_connected_nodes(HExamples,[HExamples2|_],_,Connecteds,Connecteds) :-
	HExamples == HExamples2.
get_connected_nodes(AnExample,[HExamples|TExamples],Mode,Connecteds0,Connecteds):-
	connected(AnExample,HExamples,Mode) -> 
		get_connected_nodes(AnExample,TExamples, Mode,[HExamples|Connecteds0],Connecteds)
	; get_connected_nodes(AnExample,TExamples, Mode,Connecteds0,Connecteds).

/* new_clique((Connecteds, AnExample, CurrentCliques, NewCliques) iff
   	NewCliques is the list of cliques after the modification of
	CurrentCliques: first we try to insert AnExample into an existing
	clique in  CurrentCliques considering Connecteds, i.e., what AnExample 
	is connected to, and next, if necessary, we add a new clique (modifying
	some of the existing cliques in CurrentCliques,
   where ... */


new_clique([],HExamples, Cliques, [[HExamples]|Cliques]).
new_clique(Connecteds, HExamples, Cliques, NewCliques):-
	modify_cliques(Connecteds,HExamples,Cliques,TConnecteds,[],TCliques),!,
	add_cliques(TCliques,HExamples,NewCliques,TConnecteds).
	
/* modify_cliques(Connecteds,AnExample,Cliques,NewConnecteds,NewCliques0,NewCliques) 
	iff NewCliques is the list of cliques that is the union of NewCliques0 and the
	cliques (where AnExample might have been  inserted into some) in Cliques,
	and NewConnecteds is the list of Connecteds without the elements of the
	cliques that are modified to include AnExample,
   where ... */

/* Note that AnExample is added to a clique C in Cliques when C is a subset of 
	Connecteds, i.e., if a node N is connected to every node in a clique C then
	{N} union C should also be a clique (by the definition of a clique) */

modify_cliques(Connecteds,_,[],Connecteds,NewCliques,NewCliques).
modify_cliques([],_,Cliques,[],CurCliques,NewCliques):-
	union(Cliques,CurCliques,NewCliques).
modify_cliques(Connecteds,HExamples,[HCliques|TCliques],NewConnecteds,NewCliques0, NewCliques):-
	( subset(HCliques,Connecteds) -> 
		subtract(Connecteds,HCliques,TConnecteds),
		TNewCliques = [[HExamples|HCliques]|NewCliques0]
	; TConnecteds = Connecteds, TNewCliques = [HCliques|NewCliques0]),
	modify_cliques(TConnecteds,HExamples,TCliques,NewConnecteds,TNewCliques,NewCliques).

/* add_cliques(CurrentCliques,AnExample,Cliques,Connecteds) iff
   	Cliques is the list of cliques that is the union of the new cliques,
	created by modifying *some* cliques in CurrentCliques in order to include
	AnExample, and CurrentCliques,
   where ... */

/* Note that, after modifying_cliques if Connecteds is not empty we have to
	add_cliques: after finding the first clique F appearing in the list of
	current cliques such that its intersection with the Connecteds gives the
	maximum cardinality, we add AnExample to that intersection to give out a new
	clique N, and remove F from Connecteds; and add some more new cliques if
	Connecteds is not empty. */

add_cliques(Cliques,_,Cliques,[]).
add_cliques(Cliques,HExamples,NewCliques,Connecteds):-
	first_large_clique(Cliques,Connecteds,FirstLargeClique,Intersection),
	subtract(Connecteds,FirstLargeClique,TConnecteds),
	\+ memberchk([HExamples|Intersection],Cliques),!,
	add_cliques([[HExamples|Intersection]|Cliques], HExamples, NewCliques,TConnecteds).

/* first_large_clique(Cliques,Connecteds,FirstLargeClique,Intersection) iff
	FirstLargeClique is the first clique appearing in  Cliques such that its
	Intersection with the Connecteds gives the maximum cardinality,
   where ... */

first_large_clique([],_,_,_).
first_large_clique([HCliques|TCliques],Connecteds,FirstLargeClique,Intersection):-
	intersection(HCliques,Connecteds,Int), length(Int,Len),
	first_large_clique(TCliques,Connecteds,HCliques,Len,HCliques,FirstLargeClique,Intersection).

first_large_clique([],Connecteds,AClique,_,FirstLargeClique,FirstLargeClique,Intersection):-
	intersection(AClique,Connecteds,Intersection).


first_large_clique([HCliques|TCliques],Connecteds,Intersection0,Len0,LargeClique,FirstLargeClique,Intersection):-
	intersection(HCliques,Connecteds,NewIntersection),
        length(NewIntersection,LenNew),	
	(LenNew > Len0 ->
		first_large_clique(TCliques,Connecteds,NewIntersection,LenNew,HCliques,FirstLargeClique,Intersection)
	; first_large_clique(TCliques,Connecteds,Intersection0,Len0,LargeClique,FirstLargeClique,Intersection)).


/* eliminate_unnecessary_cliques(Cliques0,Cliques,CurCliques,NewCliques) iff
	NewCliques is the list of cliques after eliminating the cliques in
	Cliques0 covered by the rest of the the cliques in Cliques0,
   where ... */

/* Note that, if the set of nodes covered by a clique is a subset of the union of the
	rest of the cliques then that clique is not necessary for a clique cover; so
	we eliminate it to find a minimal clique cover. */
	
eliminate_unnecessary_cliques(Cliques0,Cliques,CurCliques,NewCliques):-
	member(HCliques0,Cliques0),!,
	subtract(Cliques,[HCliques0],Rest),
	subtract(Cliques0,[HCliques0],NewCliques0),
	(Rest = [HRest|TRest] -> 
 		union_rest(TRest,HRest,UnionRest),
		( subset(HCliques0,UnionRest) ->
			eliminate_unnecessary_cliques(NewCliques0,Rest,CurCliques,NewCliques)
		; eliminate_unnecessary_cliques(NewCliques0,Cliques,[HCliques0|CurCliques],NewCliques))
	; NewCliques = Cliques).


eliminate_unnecessary_cliques([HCliques0|TCliques0],[HCliques0|TCliques0],_,[HCliques0|TCliques0]):-!.

eliminate_unnecessary_cliques([],_,Cliques,Cliques):-!.

/*   subtract(+Set1, +Set2, ?Difference) iff the elements of Set1 which
    	*are* in Set2 are deleted giving out Difference, 
     where Set1, Set2, and Difference are lists.

     Note that duplicated Elements of Set1 which are not in Set2 are
     retained in Difference. */

subtract([], _, []).
subtract([Element|Elements], Set, Difference) :-
        memberCheck(Set,Element),
        !,
        subtract(Elements, Set, Difference).
subtract([Element|Elements], Set, [Element|Difference]) :-
        subtract(Elements, Set, Difference).

/*   union(+Set1, +Set2, ?Union) iff Union is the Union of the elements of
     	Set1 and Set2,
     where Set1, Set2, and Union are lists. */

union([], Union, Union).
union([Element|Elements], Set, Union) :-
        memberCheck(Set,Element),
        !,
        union(Elements, Set, Union).
union([Element|Elements], Set, [Element|Union]) :-
        union(Elements, Set, Union).

/*   intersection(+Set1, +Set2, ?Intersection) iff Intersection is the
	intersection of the elements of Set1 and Set2,
     where Set1, Set2, and Intersection  are lists. */

intersection([], _, []).
intersection([Element|Elements], Set, Intersection) :-
        memberCheck(Set,Element),
        !,
        Intersection = [Element|Rest],
        intersection(Elements, Set, Rest).
intersection([_|Elements], Set, Intersection) :-
        intersection(Elements, Set, Intersection).

/*   subset(+Set1,+Set2) iff Set1 is a subset of Set2,
     where Set and Set2	are lists. */

subset([], _).
subset([Element|Elements], Set) :-
        memberCheck(Set, Element), %memberchk(Set,Element)
        subset(Elements, Set).
        
/*   union_rest(+Sets, +Set, ?UnionRest) iff UnionRest is the union of the
	members of Sets and Set,
     where Sets is a list of lists, and Set and UnionRest are lists. */

union_rest([],UnionRest,UnionRest).
union_rest([HSet|TSet], CurUnion, UnionRest):-
        union(HSet,CurUnion,Union),
        union_rest(TSet,Union,UnionRest).
        

/* the library 'cpu_lib' includes cpu_time/2 where,

   cpu_time(+Goal,-Duration) iff Duration is the run time (CPU time in
	milliseconds) of executing the Goal. */

cpu_time(Goal, Duration) :-
        statistics(runtime, [Start|_]),
        ( call(Goal) -> true; true ),
        statistics(runtime, [Finish|_]),
        Duration is (Finish - Start).
