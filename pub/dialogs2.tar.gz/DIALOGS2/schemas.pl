%*******************************************************************************
%*						                               *
%*				 schemas.pl 				       *
%*						                               *
%*		      Written by: Serap Yilmaz  (1997)                         *
%*									       *
%*******************************************************************************



%the first argument of the lpschema/10 denotes the name of the schema
%the second argument denotes the template of the schema
%the third one denotes the parameter roles
%the fourth one denotes the number of parameters of a certain role (note the correspondence
%between the parameter roles and these numbers)
%the fifth one denotes the number of heads and tails obtained after decomposing the induction parameter
%the sixth and seventh ones denote the modes of the open relations p and q respectively
%the last three arguments are used for correctly placing the actual parameters of the program
%according to the predicate declaration obtained from the specifier
%the eigth one denotes the starting positions of parameters inside the recursive calls
%the ninth one denotes the starting positions of parameters inside an atom of open relation q
%the tenth one denotes the starting positions of parameters inside an atom of open relation q
%where the corresponding parameters in recursive calls are columnwisely collected and instantiated 
%to the positions.

lpschema(dc,Template,['Induction','Result','Passive'],[_,L,K],[H,T],PMode,QMode,RArgs,QArgs,QCArgs) :- 
	(L=0 -> M=0;M=T),
	Template = [if(r(X,vec(Y,1,L),vec(Z,1,K)), p(X,vec(Y,1,L),vec(Z,1,K))),if(r(X,vec(Y,1,L),vec(Z,1,K)), and(decompose(_,vec(HX,1,H),vec(_,1,T)),and(conjatoms(r(_#J,_#J,vec(_,1,K)),1,T),q(vec(HX,1,H),vec(_,1,M),vec(_,1,L),vec(_,1,K)))))],
	PMode = mode(may,vec(res,1,L),vec(may,1,K)),
	QMode = mode(vec(may,1,H),vec(must,1,M),vec(res,1,L),vec(may,1,K)),
	RArgs = [args('Passive',L+1)],
	QArgs = [args('Result',H+M),args('Passive',H+M+L)],
	QCArgs = [args(ty,H)].

%the actual names of the open relations p and q in the divide-and-conquer schema given above 

p(dc,solve).
q(dc,compose).



lpschema(dg,Template,['Induction','Result','Passive','Accumulation'],[_,L,K,C],[H,T],PMode,QMode,RArgs,QArgs,QCArgs) :-
	Template = [if(r(X,vec(Y,1,L),vec(Z,1,K),vec(A,1,C)),p(X,vec(Y,1,L),vec(Z,1,K),vec(A,1,C))), if(r(X,vec(Y,1,L),vec(Z,1,K),vec(A,1,C)),and(decompose(_,vec(HX,1,H),vec(_,1,T)),and(q(vec(HX,1,H),vec(_,1,K),vec(_,1,C),vec(_,1,C)),conjatoms(r(_#_,vec(_,1,L),vec(_,1,K),vec(_,1,C)),1,T))))],
	PMode = mode(may,vec(res,1,L),vec(may,1,K),vec(must,1,C)),
	QMode = mode(vec(may,1,H),vec(may,1,K),vec(must,1,C),vec(res,1,C)),
	RArgs = [args('Passive',T+L),args('Result',T)],
	QArgs = [args('Passive',H),args('Accumulation',H+K)],
        QCArgs = [args('Accumulation',H+K+C)].

p(dg,solveAccu).
q(dg,extendAccu). 


%the names of the strategies of schemas 

strategy(dc,divide_and_conquer_strategy1).
strategy(dg,descend_gen_strategy1).