%******************************************************************************
%*									      *
%*				 utilities.pl				      *
%*									      *
%*		Written by: Pierre Flener (12 June 1996)		      *
%*              Updated by: Serap Yilmaz  (14 March 1997)                     *
%*									      *
%******************************************************************************

%Quintus to Sicstus update: ~= replaced by \== (term inequality).

% asks(Question,Defaults,Answer)
%	Write out Question followed by the first default answer among
%	Defaults (unless that first default is the empty string);
%	read an entire line from the current input stream into Line.
%	If Line is empty, then Answer is Default and is written out,
%	otherwise Answer is Line.

asks(Question,[Default|_],Answer) :-
	ask(Question,Default,Answer) -> true ; !,fail.
asks(Question,[_|Defaults],Answer) :-
	asks(Question,Defaults,Answer).

ask(Question,Default,Answer) :-
	write(Question),
	(length(Default,Len),Len=3, name(Question,SQuest),append(_,[114,63],SQuest) -> Default=[91,D,93],write(' {'),put(D),write('} '),nl;
	writeDef(Default),nl),
	(Default \== "", dialMode(mute) ->
	     !, Line=[];
	     readLine(Line)),
	handleDef(Question,Line,Default,Answer).


writeDef([]).
writeDef([D|Ds]) :-
	write(' {'),
	writeString([D|Ds]),
	write('}').

writeString([]).
writeString([C|Cs]) :-
	put(C),
	writeString(Cs).

readLine([]) :-
	at_end_of_line,!,
	skip_line.
readLine([C|Cs]) :-
	get(C),
	readLine(Cs).

handleDef(Question,[],Answer,Answer) :-
	(length(Answer,Len),Len=3,name(Question,SQuest),append(_,[114,63],SQuest)->Answer=[91,D,93],put(D),nl;
	writeString(Answer),nl).
handleDef(_,[A|As],_,[A|As]).


% commaAnd(C,A)
%	A is the "and-ed" flat conjunction version of
%	the flattened list C.
% e.g. commaAnd([a,b,c],and(a,and(b,c))).
% e.g. commaAnd([d],d).


commaAnd([Atom],Atom).
commaAnd([Atom1,Atom2],and(Atom1,Atom2)) :- !.
commaAnd([Atom|TC],and(Atom,Conj)) :-
	commaAnd(TC,Conj).




commaAnds([],[]).
commaAnds([C|Cs],[A|As]) :-
	commaAnd(C,A),
	commaAnds(Cs,As).


% conjoin(FConj1,FConj2,FConj)
%	FConj is a flat conjunction obtained by conjoining the flat
%	conjunctions FConj1 and FConj2.

conjoin(true,FConj1,FConj) :-
	!,FConj=FConj1.
conjoin(and(Lit1,FConj1),FConj2,FConj) :-
	!,conjoin(FConj1,FConj2,FConj3),
	FConj=and(Lit1,FConj3).
conjoin(Lit1,true,FConj) :-
	!,FConj=Lit1.
conjoin(Lit1,FConj2,FConj) :-
	FConj=and(Lit1,FConj2).


% disjList(Disj,List)
%	List is the list of wff that appear in the flat disjunction Disj.

disjList((Wff;Disj),[Wff|List]) :-
	!,disjList(Disj,List).
disjList(false,[]) :- !.
disjList(Wff,[Wff]).


% efface(E,L,R)
%	R is list L without its first, existing occurrence of term E.
% OK for modes (+,+,?).

efface(E,[E|R],R) :- !.
efface(E,[HL|TL],[HL|TR]) :-
% i.e.E\==HL,
	efface(E,TL,TR).


% firstM(M,L,F)
%	F is the list of the first M elements of list L.

firstM(0,_,[]) :- !.
firstM(M,[HL|TL],[HL|TF]) :-
	M>0,
	Mminus1 is M-1,
	firstM(Mminus1,TL,TF).


% iota(N,L)
%	L is [1,2,...,N].
% OK for modes (+,+) and (+,-).

iota(N,L) :-
	iota(N,L,[]).

iota(N,L,A) :-
	N>0,!,
	Nminus1 is N-1,
	iota(Nminus1,L,[N|A]).
iota(0,L,L).


% member(L,E)
%	List L has E as an element.
%	Succeeds as many times as L has elements.

%member([E|_],E).
%member([_|TL],E) :-
%	member(TL,E).

dlgsmember([E],E) :- !.
dlgsmember([E,_|_],E).
dlgsmember([_,H|T],E) :-
	dlgsmember([H|T],E).


% memberCheck(L,E)
%	List L has as an element some term that is identical to term E.
%	Succeeds once at most.

memberCheck([H|_],E) :-
	H==E,!.
memberCheck([_|T],E) :-
	memberCheck(T,E).


% memberCheck2(L,E)
%	List L has as an element some term that matches term E.
%	Succeeds once at most.

memberCheck2([E|_],E) :- !.
memberCheck2([_|T],E) :-
	memberCheck2(T,E).


% msg(T1,T2,MSG)
%	Term MSG is the most-specific-generalization of terms T1 and T2.

msg(T1,T2,MSG) :-
	msg(T1,T2,MSG,[],_).

msg(T1,T2,MSG,Inj,NewInj) :-
	comparable(T1,T2),!,
	T1=..[F|As1],
	T2=..[F|As2],
	msgs(As1,As2,MSGs,Inj,NewInj),
	MSG=..[F|MSGs].
msg(T1,T2,MSG,Inj,NewInj) :-
	injection(Inj,T1,T2,MSG,NewInj).

msgs([],[],[],Inj,Inj).
msgs([A|As],[B|Bs],[M|Ms],Inj,NewInj) :-
	msg(A,B,M,Inj,IntInj),
	msgs(As,Bs,Ms,IntInj,NewInj).

comparable(T1,T2) :-
	nonvar(T1),
	nonvar(T2),
	functor(T1,F,N),
	functor(T2,F,N).

injection([],T1,T2,V,[inj(T1,T2,V)]).
injection([inj(T3,T4,W)|Inj],T1,T2,V,[inj(T3,T4,W)|Inj]) :-
	T1==T3,T2==T4,!,
	V=W.
injection([inj(T3,T4,W)|Inj],T1,T2,V,[inj(T3,T4,W)|NewInj]) :-
  % i.e.(T1,T2)\==(T3,T4),
	injection(Inj,T1,T2,V,NewInj).


% msg(Ts,MSG)
%	Term MSG is the most-specific-generalization of the elements in the
%	non-empty term-list Ts.

msg([T],T) :- !.
msg([T|Ts],MSG) :-
	msg(Ts,IntMSG),
	msg(T,IntMSG,MSG).

clauseMsg([C],C) :- !.
clauseMsg([C|Cs],MSG) :-
	clauseMsg(Cs,IntMSG),
	clauseMsg(C,IntMSG,MSG).


% nat2Peano(N,P)
%	P is the Peano-number version of natural number N.

nat2Peano(0,0).
nat2Peano(N,P) :-
	N>0,
	Nminus1 is N-1,
	nat2Peano(Nminus1,PredP),
	P=s(PredP).


% peano2Nat(P,N)
%	N is the natural number version of Peano-number P.
% Not used.

peano2Nat(0,0).
peano2Nat(s(PredP),N) :-
	peano2Nat(PredP,Nminus1),
	N is Nminus1+1.


% ordDiff(L1,L2,L)
%	L is L1 \ L2, where all parameters are ordered lists of integers.
% N.B. ordDiff(L,[E],R) <==> efface(E,L,R).

ordDiff(L,[],L) :- !.
ordDiff([HL1|TL1],[HL1|TL2],L) :-
	!,ordDiff(TL1,TL2,L).
ordDiff([HL1|TL1],[HL2|TL2],[HL1|TL]) :-
	HL1<HL2,
	ordDiff(TL1,[HL2|TL2],TL).


% positions(E,L,Ps)
%	Term E occurs in list L at positions Ps.
% OK for modes (+,+,?) and (-,+,+).

positions(E,L,Ps) :-
	positions(E,L,Ps,1).

positions(_,[],[],_).
positions(E,[E|TL],[P|Ps],P) :-
	Pplus1 is P+1,
	positions(E,TL,Ps,Pplus1).
positions(E,[HL|TL],Ps,P) :-
	E\==HL,
	Pplus1 is P+1,
	positions(E,TL,Ps,Pplus1).


% rebind(Subst2,Subst1)
%	Unify the variables of the bindings in substitution Subst2 with the
%	variables of the bindings in substitution Subst1 that are bound to
%	the same term, if any.

rebind([],_).
rebind([(Name2=Var2)|Subst2],Subst1) :-
	apply(Subst1,Name2,Var2),
	rebind(Subst2,Subst1).

apply([],_,_).
apply([(Name1=Var1)|_],Name2,Var2) :-
	Name1=Name2,!,
	Var2=Var1.
apply([_|Subst1],Name2,Var2) :-
%	Name1\==Name2,
	apply(Subst1,Name2,Var2).


% dlgsreverse(L,R)
%	List R is the reverse of list L.

dlgsreverse(L,R) :-
	dlgsreverse(L,R,[]).

dlgsreverse([],R,R).
dlgsreverse([HL|TL],R,A) :-
	dlgsreverse(TL,R,[HL|A]).


% dlgsselect(P,L,S)
%	S is the list of elements at ordered positions P in L.
% OK for modes (+,+,?), (+,-,+), and (-,+,+).

dlgsselect(P,L,S) :-
	dlgsselect(P,L,S,1).

dlgsselect([],_,[],_) :- !.
dlgsselect([HP|TP],[HL|TL],[HL|TS],HP) :-
	!,PosPlus1 is HP+1,
       	dlgsselect(TP,TL,TS,PosPlus1).
dlgsselect([HP|TP],[_|TL],LS,Pos) :-
       	PosPlus1 is Pos+1,
       	dlgsselect([HP|TP],TL,LS,PosPlus1).


% vars(T,S)
%	S is the set of all variables in term T (w/o repetitions),
%	as they occur in T from left to right.

vars(X,S) :-
	vars(X,RevS,[]),
	reverse(RevS,S).

vars(X,S,A) :-
	var(X),!,
	(memberCheck(A,X) -> S=A ; S=[X|A]).
vars(T,S,A) :-
	T=..[_|Args],
	vars1(Args,S,A).

vars1([T|Ts],S,A) :-
	vars(T,IntS,A),!,
	vars1(Ts,S,IntS).
vars1([],S,S).


% varList(T,L)
%	L is the list of all variables in term T (incl. repetitions),
%	as they occur in T from left to right.
% Not used.

varList(X,L) :-
	varList(X,L,[]).

varList(X,[X|L],L) :-
	var(X),!.
varList(T,L,A) :-
	T=..[_|Args],
	varList1(Args,L,A).

varList1([T|Ts],L,A) :-
	varList(T,L,IntA),!,
	varList1(Ts,IntA,A).
varList1([],L,L).


% writeln(X)
%	Write argument X followed by a newline symbol.

writeln(X) :-
	write(X),nl.


% zip(Vars,Terms,Eqs)
%	Eqs is a flat conjunction made of equality atoms built from the
%	variables in Vars and terms in Terms at the same positions.

zip([],[],true).
zip([Var],[Term],(Var=Term)) :- !.
zip([Var1,Var2|Vars],[Term1,Term2|Terms],and((Var1=Term1),Eqs)) :-	
	zip([Var2|Vars],[Term2|Terms],Eqs).

