*******************************************************************************
*                                                                             *
*DIALOGS-II: Dialog-based Inductive and Abductive LOGic program Synthesiser-II*
*                                                                             *
*               Written in Quintus Prolog by: Serap Yilmaz   (Spring 1997)    *
*                                                                             *
*               Based on the system DIALOGS                                   *
*                                                                             *
*               Written by: Pierre Flener  (Spring 1996)                      *
*               Together with: Serap Yilmaz, Halime Buyukyildiz               *
*                                                                             *
*******************************************************************************

Please read  http://user.it.uu.se/~pierref/pub/SerapMSc.ps.gz before you start
experimenting with Dialogs-II.  After loading the file  dialogsII.pl,  start a
new  synthesis by typing "d2."  (without the  quotes).

The system is composed of the following programs:

phase0.pl: asks for the predicate declaration, the schema, and the strategy,
           and executes the strategy in order to obtain an open program to
           be passed to the next phase.

phase1and2.pl: abduces evidence, induces program clauses using the Program
               Closing Method, and evaluates the result in order to detect
               necessary predicate invention.

schemas.pl: contains the currently available schemas of the system

cliques.pl: finds (admissible) cliques of clauses

clausemsg.pl: computes the lg\theta of two clauses

primitives.pl: contains primitives used by the system

grammar.pl: contains the definite clause grammar for parsing predicate
            declarations

utilities.pl: contains procedures frequently used by the system

Variable names start with an uppercase  letter;  predicate names, functors and
constants start with a lowercase  letter.  Conjunction is expressed by a comma
(,),  disjunction  by a semi-colon  (;),  negation by wrapping the atom with a
prefix  neg/1  functor,  truth by "true" and falsity by "false"  (without  the
quotes).  The  available  primitives  are:  =/2,  \==/2,  length/2,  append/3,
member/2,  nat/1, list/1, add/3, mult/3, lt/2, gt/2, le/2, ge/2,  partition/4,
and halves/3 (see file  primitives.pl).  Natural numbers should be typed in as
Peano numbers, using 0 for zero and prefix functor s/1 for successor.

Please note that, during  phase0,  answers  should  *not* be  terminated  by a
full-stop  (.).  The default  answer  (always  between  curly  braces)  can be
selected by simply hitting the RETURN/ENTER  key.  You can force  backtracking
to a previous  question  using the answer  "back"  (without the quotes).  Note
that result  parameters and passive  parameters  are indicated as lists, using
the Prolog  notation;  that means the absence of such  parameters is indicated
using the empty list ([]).

The schema  language  can be inferred  by looking at file  dedotify.pl  or the
example schemas in file schemas.pl,  plus Halime  Buyukyildiz's  M.Sc.  thesis
(http://user.it.uu.se/~pierref/pub/HalimeMSc.ps.gz). A new schema can be added
to the system using the  declarative  syntax of the schema  language,  but you
need to also make  sure  that the  parameter  roles of the  parameters  of the
programs that fit the schema are defined (see file phase0.pl).

The  type  language  can be  inferred  by  looking  at  file  grammar.pl  (see
non-terminal  type/1)  or  at  file tests.txt.  Similarly  for  the  predicate
declaration language.

During phase1 and phase2,  answers  *should* be terminated by a full-stop (.).
You can express your boredom with the questions (or unwillingness or inability
to answer them) by answering "stop_it" (without the quotes).

Feedback to the development team is always welcome.

Sincerely,
Pierre Flener (http://user.it.uu.se/~pierref/)
