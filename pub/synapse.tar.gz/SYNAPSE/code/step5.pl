%******************************************************************************
%*				 step5.pl				      *
%******************************************************************************

% step5(LA4,LA5)
%	Synthesis of LA5 from LA4.
% Fully manual version --> automatizable.
% NB. No test whether Solve or SolveNMin actually hold.

step5(LA4,LA5) :-
	LA4=iff(Head,or(MinCase4,NRecCase4,RecCase,[])),
	solveMinCase(MinCase4,MinCase5),
	solveNRecCase(NRecCase4,NRecCase5),
	LA5=iff(Head,or(MinCase5,NRecCase5,RecCase,[])).

solveMinCase(undefined,undefined) :- !.
solveMinCase(MinCase4,MinCase5) :-
	MinCase4=and(Minimal,undefined,MinEqsss),
	selectSolve('Solve',"true",Solve),
	MinCase5=and(Minimal,Solve,MinEqsss).

solveNRecCase(undefined,undefined) :- !.
solveNRecCase(NRecCase4,NRecCase5) :-
	NRecCase4=and(NMinimal,Decompose,undefined,undefined,NRecEqsss),
	selectSolve('SolveNMin',"true",SolveNMin),
	NRecCase5=and(NMinimal,Decompose,undefined,SolveNMin,NRecEqsss).


% selectSolve(Question,Default,Solve)
%	Select an instance Solve upon asking Question with Default.
% Fully manual version --> automatizable.

selectSolve(Question,Default,Solve) :-
	ask(Question,Default,SolveStr),
	myPhrase(conj(Solve),SolveStr),!.
