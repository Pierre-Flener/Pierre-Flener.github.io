%******************************************************************************
%*				 step1.pl				      *
%******************************************************************************

% step1(Pred,Exs,Variables,LA1)
%	Synthesis of LA1 from Pred, Exs, and Variables.
% Fully automatic version.

step1(Pred,Exs,Variables,LA1) :-
	Variables=variables(Params,_,_,_,_,_,_,_),
	Head=..[Pred|Params],
	equationsss(Exs,Params,Eqsss),
	LA1=iff(Head,or(undefined,undefined,undefined,Eqsss)).
