%******************************************************************************
%*				 step7.pl				      *
%******************************************************************************

% step7(Props,Variables,Positions,LA6,LA7)
%	Synthesis of LA7 from LA6, and Props.
%       Variables is the compound term of variables, where
%       the following components are used here:
%		AuxParams are the auxiliary parameters of Params;
%		DecVars are the heads and tails of IP;
%		IPtails are the tails among DecVars;
%	Positions is the compound term of parameter positions, where
%	the following component is used here:
%		PosAuxParams are the positions of AuxParams within Params.

step7(Props,Variables,Positions,LA6,LA7) :-
	LA6=iff(Head,or(MinCase,_,_,[])),
  % build the theory:
	MinCase=and(_,_,MinEqsss),
	functor(Head,Pred,_),
	assertProps(Props),
	propExs(MinEqsss,Pred,PropExs),
	retractEP(Head),
	algo2Clauses(LA6,LAclauses),
	loadPrimitives(PrimClauses),
	Theory=theory(LAclauses,PropExs,Props,PrimClauses),
  % build the initial goals:
	clauses2Goals(Props,Goals),
  % think aloud (if required):
	thinkMode(aloud(Steps,_)),
	(memberCheck(Steps,7) ->
		Think=aloud,
		write('Entering Step 7...'),nl,nl,
		append(LAclauses,PropExs,LAPE),
		append(LAPE,Props,LAPEP),
		ppTheory(LAPEP),
		write('The initial goals are:'),nl,nl,
		ppGoals(Goals),nl			;
		Think=quiet),
  % initialize the discriminants to unbound variables:
	length(LAclauses,N),	% (+,-)
	length(Discs,N),	% (-,+)
  % do the proofs and discriminant-extractions:
	proofs(Theory,Goals,Discs,Variables,Think,Positions,1),
  % generalize the discriminants:
  	Discs=[MinDisc|NMinDiscs],
	genDiscs(NMinDiscs,GenNMinDiscs,Variables),
  	GenDiscs=[MinDisc|GenNMinDiscs],
  % update LA6 into LA7, using the generalized discriminants:
	addDiscs(GenDiscs,Variables,LA6,LA7).


% propExs(Eqsss,Pred,PropExs)
%	PropExs are the property-examples among the examples "hidden" in Eqsss,
%	and this wrt the clauses currently asserted for predicate Pred.

propExs([],_,[]).
propExs([[Eqs1]|MinEqsss],Pred,[PropEx|PropExs]) :-
	equations(_,Values,Eqs1),
	Ex=..[Pred|Values],
	\+ call(Ex),!,
	PropEx=(Ex:-true),
	propExs(MinEqsss,Pred,PropExs).
propExs([[_]|MinEqsss],Pred,PropExs) :-
	propExs(MinEqsss,Pred,PropExs).


% loadPrimitives(PrimClauses)
%	PrimClauses are the clauses of the known predicates in the database.

loadPrimitives(PrimClauses) :-
	findall(Clause,
			( known(Head),
		  	  clause(Head,Body),
		 	  Clause=(Head:-Body) ),
		PrimNGclauses),
	var2grounds(PrimNGclauses,PrimClauses,[],_).


% proof(Theory,Goal,Discs,OldDiscHead,Variables,Think)
%	Prove/disprove the following theorem:  Theory |-- Goal,
%	and update Discs in case of successful proof,
%	using OldDiscHead and Variables;
%	Think aloud iff Think = aloud.

proof(Theory,Goal,Discs,OldDiscHead,Variables,Think) :-
	(Think=aloud ->				% think aloud (if required)
		write('Proving: '),ppGoal(Goal)	;
		true),
%	setof(solutions(FinalGoals,Substs,ClNbrs,Copiess),
		prove(Theory,Goal,[],_,_,Variables,Think,
			FinalGoals,Substs,ClNbrs,Copiess),!,
%	      Solutions),
%	extractDiscss(Solutions,Discs,OldDiscHead,Variables,Think),
	extractDiscs(FinalGoals,Substs,ClNbrs,Copiess,
			Discs,OldDiscHead,Variables,Think).


proofs(_,[],_,_,_,_,_) :- !.
proofs(Theory,[Goal|Goals],Discs,Variables,Think,Positions,P) :-
	Theory=theory(LAclauses,PropExs,Props,PrimClauses),
	effacePos(P,Props,ActualProps),
	append(PropExs,ActualProps,EPclauses),
	ActualTheory=theory(LAclauses,EPclauses,PrimClauses),
	makeHead(Goal,Positions,OldDiscHead),
	proof(ActualTheory,Goal,Discs,OldDiscHead,Variables,Think),
	Pplus1 is P + 1,
	proofs(Theory,Goals,Discs,Variables,Think,Positions,Pplus1).


% prove(Theory,Goal,PreSubst,PreClNbr,PreCopies,Variables,Think,
%		FinalGoals,FinalSubsts,FinalClNbrs,FinalCopiess)
%	A proof of  Theory |-- Goal  ends in FinalGoals;
%	PreSubst is the computed-answer-substitution obtained so far;
%	FinalSubsts are the final computed-answer-substitutions;
%	FinalClNbrs are the numbers of the clauses used in the first DCI steps;
%	FinalCopiess are the copies of DecVars used in the first DCI steps;
%	Variables is the compound term of variables;
%	Think aloud iff Think = aloud.

prove(_,Goal,Subst,ClNbr,Copies,_,Think,[Goal],[Subst],[ClNbr],[Copies]) :-
	Goal=if([],_),!,
	(Think=aloud ->				% think aloud (if required)
		write('Success!'),nl ;
		true).
prove(Theory,Goal,PreSubst,PreClNbr,PreCopies,Variables,Think,
		FinalGoals,FinalSubsts,FinalClNbrs,FinalCopiess) :-
	inference(Theory,Goal,PreClNbr,PreCopies,Variables,Think,
			IntGoals,IntSubsts,IntClNbrs,IntCopiess),
	compoSubsts(IntSubsts,PreSubst,PreSubsts),
	proves(Theory,IntGoals,PreSubsts,IntClNbrs,IntCopiess,Variables,Think,
			FinalGoals,FinalSubsts,FinalClNbrs,FinalCopiess).
prove(_,_,_,_,_,_,Think,_,_,_,_) :-
	(Think=aloud ->				% think aloud (if required)
		write('Backtracking...'),nl ;
		true),
	fail.


proves(_,[],[],[],[],_,_,[],[],[],[]) :- !.
proves(Theory,[Goal|Goals],[PreSubst|PreSubsts],[ClNbr|ClNbrs],[Copies|Copiess],
	Variables,Think,FinalGoals,FinalSubsts,FinalClNbrs,FinalCopiess) :-
	prove(Theory,Goal,PreSubst,ClNbr,Copies,Variables,Think,
		SomeFinalGoals,SomeSubsts,SomeClNbrs,SomeCopiess),
	proves(Theory,Goals,PreSubsts,ClNbrs,Copiess,Variables,Think,
		MoreFinalGoals,MoreSubsts,MoreClNbrs,MoreCopiess),
	append(SomeFinalGoals,MoreFinalGoals,FinalGoals),
	append(SomeSubsts,MoreSubsts,FinalSubsts),
	append(SomeClNbrs,MoreClNbrs,FinalClNbrs),
	append(SomeCopiess,MoreCopiess,FinalCopiess).


% inference(Theory,Goal,ClNbr,Copies,Vars,Think,NewGoals,Substs,ClNbrs,Copiess)
%	One inference-step of  Theory |-- Goal  results in NewGoals;
%	Substs are the computed-answer-substitutions;
%	ClNbrs are the numbers of the clauses used in the first DCI steps;
%	Copiess are the copies of DecVars used in the first DCI steps;
%	Vars is the compound term of variables;
%	Think aloud iff Think = aloud.

inference(Theory,Goal,ClNbr,Copies,_,Think,
		NewGoals,Substs,ClNbrs,Copiess) :-			% NFI
	Goal=if(OldConcl,OldHyp),
	compRule(OldHyp,SelAtom,PreNewHyp),
	resolveNFI(Theory,SelAtom,ClNbr,Copies,Think,
			Bodies,Substs,ClNbrs,Copiess),
	assembleNFI(Bodies,Substs,PreNewHyp,OldConcl,NewGoals),
	(Think=aloud ->				% think aloud (if required)
		ppGoals(NewGoals) ;
		true).
inference(Theory,Goal,ClNbr,Copies,Variables,Think,
		[NewGoal],[Subst],[NewClNbr],[NewCopies]) :-		% DCI
	Goal=if(OldConcl,OldHyp),
	compRule(OldConcl,SelAtom,PreNewConcl),
	resolveDCI(Theory,SelAtom,ClNbr,Copies,Variables,Think,
			Body,Subst,NewClNbr,NewCopies),
	assembleDCI(Body,Subst,PreNewConcl,OldHyp,NewGoal),
	(Think=aloud ->				% think aloud (if required)
		ppGoal(NewGoal) ;
		true).
inference(_,Goal,ClNbr,Copies,_,Think,
		[NewGoal],[Subst],[ClNbr],[Copies]) :-			% Sim
	Goal=if(OldConcl,OldHyp),
	compRuleSim(OldConcl,SelAtomConcl,Concl,OldHyp,SelAtomHyp,Hyp),
	decUnify(SelAtomConcl,SelAtomHyp,_,Subst),
	substitution(Concl,Subst,NewConcl),
	substitution(Hyp,Subst,NewHyp),
	NewGoal=if(NewConcl,NewHyp),
	(Think=aloud ->				% think aloud (if required)
		printPrimRule(Subst,'Sim',SelAtomConcl),
		ppGoal(NewGoal)				 ;
		true).


% compRule(Conj,SelAtom,RemConj)
%	Computation-rule for DCI/NFI: selection of an atom in a conjunction.
%	Invariant: permutation(Conj,[SelAtom|RemConj]), such that:
%	- SelAtom is the left-most atom in Conj with a primitive predicate
%		and an allowed input directionality,
%		iff there is such an atom in Conj;
%	- otherwise, SelAtom is the left-most atom in Conj
%		that has a non-primitive predicate,
%		iff there is such an atom in Conj;
% NB. Deterministic.
% NB. How to make this a fair computation rule???

compRule(Conj,SelAtom,RemConj) :-
	findPrim(Conj,SelAtom,RemConj),!.
compRule(Conj,SelAtom,RemConj) :-
	findNonPrim(Conj,SelAtom,RemConj).

findPrim([H|T],SelAtom,RemConj) :-
	primitive(H),
	directionality(H,Dir),
	(noSelect(H,ForbiddenDir),
	 Dir=ForbiddenDir ->
	 	fail	 ;
		true),
	SelAtom=H,!,
	RemConj=T.
findPrim([H|T],SelAtom,RemConj) :-
	findPrim(T,SelAtom,RemT),
	RemConj=[H|RemT].

findNonPrim([H|T],SelAtom,RemConj) :-
	primitive(H),!,
	findNonPrim(T,SelAtom,RemT),
	RemConj=[H|RemT].
findNonPrim([SelAtom|RemConj],SelAtom,RemConj).


% compRuleSim(Conj1,SelAtom1,RemConj1,Conj2,SelAtom2,RemConj2)
%	Computation-rule for Sim: selection of an atom in a conjunction.
%	Invariant:  permutation(Conj1,[SelAtom1|RemConj1])
%		and permutation(Conj2,[SelAtom2|RemConj2]),
%	such that SelAtom1 and SelAtom2 have the same predicate and arity.
% NB. Non-deterministic (redundant answers).

compRuleSim([SelAtom1|RemConj1],SelAtom1,RemConj1,
		[SelAtom2|RemConj2],SelAtom2,RemConj2) :-
	functor(SelAtom1,Pred,Arity),
	functor(SelAtom2,Pred,Arity).
compRuleSim(Conj1,SelAtom1,RemConj1,
		[FirstAtom2|Conj2],SelAtom2,[FirstAtom2|RemConj2]) :-
	compRuleSim(Conj1,SelAtom1,RemConj1,Conj2,SelAtom2,RemConj2).
compRuleSim([FirstAtom1|Conj1],SelAtom1,[FirstAtom1|RemConj1],
		Conj2,SelAtom2,RemConj2) :-
	compRuleSim(Conj1,SelAtom1,RemConj1,Conj2,SelAtom2,RemConj2).


% resolveDCI(Theory,SelAtom,ClNbr,Copies,Variables,Think,
%			Body,Subst,NewClNbr,NewCopies)
%	Resolve SelAtom in Theory, yielding Body and Subst;
%	NewClNbr is the number of the clause used in the first DCI step;
%	NewCopies are the copies of DecVars used in the first DCI step;
%	Variables is the compound term of variables;
%	Think aloud iff Think = aloud.
% Non-deterministic.

resolveDCI(_,SelAtom,ClNbr,Copies,_,Think,Body,Subst,ClNbr,Copies) :-
	primitive(SelAtom),			% primitive predicate
	directionality(SelAtom,Dir),		% that may be safely called
	safeCall(SelAtom,Dir),!,
	metaVarSet(SelAtom,MetaVars),
	ground2var(SelAtom,NGSelAtom,Vars),
	call(NGSelAtom),
	var2ground(Vars,Vals),
	makeSubst(MetaVars,Vals,Sub),
	simSubst(Sub,SimSub),
	quantify(SimSub,Subst,existential),
	deciding(Subst),
	Body=true,
	(Think=aloud ->				% think aloud (if required)
		printPrimRule(Subst,'DCI',SelAtom) ;
		true).
resolveDCI(Theory,SelAtom,ClNbr,Copies,_,Think,Body,Subst,ClNbr,Copies) :-
	primitive(SelAtom),!,			% primitive predicate
	Theory=theory(_,_,PrimClauses),		% that has to be DCI-resolved
	clauseDCI(PrimClauses,SelAtom,Body,Subst,_,_,_),
	(Think=aloud ->				% think aloud (if required)
		printPrimRule(Subst,'DCI',SelAtom) ;
		true).
resolveDCI(Theory,SelAtom,ClNbr,Copies,_,Think,Body,Subst,ClNbr,Copies) :-
	integer(ClNbr),!,			% non-primitive predicate
	Theory=theory(LAclauses,EPclauses,_),	%  of a non-initial goal
	clauseDCI(EPclauses,SelAtom,Body,Subst,Nbr,_,_),
	length(LAclauses,N),					% for tracing
	UsedClNbr is N + Nbr,					% for tracing
	(Think=aloud ->				% think aloud (if required)
		printRule(Subst,'DCI',UsedClNbr) ;
		true).
resolveDCI(Theory,SelAtom,ClNbr,Copies,Variables,Think,
			Body,Subst,NewClNbr,NewCopies) :-
	var(ClNbr),var(Copies),			% non-primitive predicate
	Theory=theory(LAclauses,_,_),		%   of the initial goal
	clauseDCI(LAclauses,SelAtom,Body,Subst,NewClNbr,NewCopies,Variables),
	(Think=aloud ->				% think aloud (if required)
		printRule(Subst,'DCI',NewClNbr) ;
		true).


% resolveNFI(Theory,SelAtom,ClNbr,Copies,Think,Bodies,Substs,ClNbrs,Copiess)
%	Resolve SelAtom in Theory, yielding Bodies and Substs;
%	Think aloud iff Think = aloud.

resolveNFI(_,SelAtom,ClNbr,Copies,Think,Bodies,Substs,ClNbrs,Copiess) :-
	primitive(SelAtom),			% primitive predicate
	directionality(SelAtom,Dir),		% that may be safely called
	safeCall(SelAtom,Dir),!,
	metaVarSet(SelAtom,MetaVars),
	ground2var(SelAtom,NGSelAtom,Vars),
	findall(solution(Body,Subst),
		 ( call(NGSelAtom),
		   var2ground(Vars,Vals),
		   makeSubst(MetaVars,Vals,Sub),
		   simSubst(Sub,SimSub),
		   quantify(SimSub,Subst,universal),
		   Body=true				),
		BodiesSubsts),
	length(BodiesSubsts,N),
	N>0,
	unzip2(BodiesSubsts,Bodies,Substs),
	init(ClNbr,Copies,N,ClNbrs,Copiess),
	(Think=aloud ->				% think aloud (if required)
		printPrimRules(Substs,'NFI',SelAtom) ;
		true).
resolveNFI(Theory,SelAtom,ClNbr,Copies,Think,Bodies,Substs,ClNbrs,Copiess) :-
	primitive(SelAtom),!,			% primitive predicate
	Theory=theory(_,_,PrimClauses),		% that has to be NFI-resolved
	findall(solution(Body,Subst),
		  clauseNFI(PrimClauses,SelAtom,Body,Subst,_),
		BodiesSubsts),
	length(BodiesSubsts,N),
	N>0,
	unzip2(BodiesSubsts,Bodies,Substs),
	init(ClNbr,Copies,N,ClNbrs,Copiess),
	(Think=aloud ->				% think aloud (if required)
		printPrimRules(Substs,'NFI',SelAtom) ;
		true).
%resolveNFI(Theory,SelAtom,ClNbr,Copies,Think,Bodies,Substs,ClNbrs,Copiess) :-
%	Theory=theory(LAclauses,EPclauses,_),	% non-primitive predicate
%	append(LAclauses,EPclauses,FullTheory),
%	findall(solution(Body,Subst,ClNbr),
%		  clauseNFI(FullTheory,SelAtom,Body,Subst,ClNbr),
%		BodiesSubstsClNbrs),
%	length(BodiesSubstsClNbrs,N),
%	N>0,
%	unzip3(BodiesSubstsClNbrs,Bodies,Substs,UsedClNbrs),
%	init(ClNbr,Copies,N,ClNbrs,Copiess),
%	(Think=aloud ->				% think aloud (if required)
%		printRules(Substs,'NFI',UsedClNbrs) ;
%		true).

unzip2([],[],[]).
unzip2([solution(HB,HS)|TL],[HB|TB],[HS|TS]) :-
	unzip2(TL,TB,TS).

unzip3([],[],[],[]).
unzip3([solution(HB,HS,HC)|TL],[HB|TB],[HS|TS],[HC|TC]) :-
	unzip3(TL,TB,TS,TC).

init(ClNbr,Copies,N,ClNbrs,Copiess) :-
	integer(ClNbr),!,
	plateau(N,ClNbr,ClNbrs),
	plateau(N,Copies,Copiess).
init(_,_,N,ClNbrs,Copiess) :-
	length(ClNbrs,N),	% (-,+)
	length(Copiess,N).	% (-,+)


% directionality(Atom,Dir)
%	Dir is the directionality of atom Atom.

directionality(Atom,Dir) :-
	Atom=..[_|Args],
	forms(Args,Dir).

form(Term,Form) :-
	metaVar(Term),!,
	Form=var.
form(Term,Form) :-
	metaGround(Term),!,
	Form=ground.
form(_,ngv).

forms([],[]).
forms([Term|Terms],[Form|Forms]) :-
	form(Term,Form),
	forms(Terms,Forms).


% safeCall(Atom,Dir)
%	Atom may be safely executed with directionality Dir.

safeCall(Atom,Dir) :-
	safeDir(Atom,SafeDir),
	satisfaction(Dir,SafeDir),!.

satisfaction([],[]).
satisfaction([Form|Dir],[SafeForm|SafeDir]) :-
	lessInst(Form,SafeForm),
	satisfaction(Dir,SafeDir).

lessInst(Form,Form) :- !.
lessInst(Form1,Form2) :-
	lessInstFact(Form1,Form3),
	lessInst(Form3,Form2).

lessInstFact(ground,gv).
lessInstFact(ground,novar).
lessInstFact(var,gv).
lessInstFact(var,noground).
lessInstFact(ngv,noground).
lessInstFact(ngv,novar).
lessInstFact(gv,any).
lessInstFact(novar,any).
lessInstFact(noground,any).


% assembleDCI(Body,Subst,PreNewConcl,OldHyp,NewGoal)
%	Assemble NewGoal from Body, Subst, PreNewConcl, and OldHyp.

assembleDCI(Body,Subst,PreNewConcl,OldHyp,NewGoal) :-	
	listComma(SufNewConcl,Body),	% (-,+)
	quantify(SufNewConcl,ExSufNewConcl,existential),
	substitution(PreNewConcl,Subst,SubPreNewConcl),
	append(SubPreNewConcl,ExSufNewConcl,NewConcl),
	substitution(OldHyp,Subst,NewHyp),
	NewGoal=if(NewConcl,NewHyp).


% assembleNFI(Bodies,Substs,PreNewHyp,OldConcl,NewGoals)
%	Assemble NewGoals from Bodies, Substs, PreNewHyp, and OldConcl.

assembleNFI([],[],_,_,[]).
assembleNFI([Body|Bodies],[Subst|Substs],PreNewHyp,OldConcl,
		[NewGoal|NewGoals]) :-
	listComma(SufNewHyp,Body),	% (-,+)
	quantify(SufNewHyp,UniSufNewHyp,universal),
	substitution(PreNewHyp,Subst,SubPreNewHyp),
	append(SubPreNewHyp,UniSufNewHyp,NewHyp),
	substitution(OldConcl,Subst,NewConcl),
	NewGoal=if(NewConcl,NewHyp),
	assembleNFI(Bodies,Substs,PreNewHyp,OldConcl,NewGoals).


% clauseDCI(Theory,Head,Body,Subst,N,Copies,Variables)
%	"Head :- Body" Subst is a fresh instance of the N-th clause of Theory,
%	where Subst is a deciding-substitution;
%	Copies are the copies of DecVars used in the first DCI step;
%	Variables is the compound term of variables.
% Ok for mode (+,+,-,-,-).

clauseDCI(Theory,Head,Body,Subst,N,Copies,Variables) :-
	metaVarSet(Head,Vars),
	clauseDCI(Theory,Head,Body,Sub,1,N,Copies,Variables),
	pruneSubst(Sub,Vars,Subst).

clauseDCI([Clause|_],Head,Body,Sub,N,N,Copies,Variables) :-
        Variables=variables(_,_,_,_,DecVars,_,_,_),
	copyTerm(Clause+DecVars,(HeadC:-BodyC)+UnquantCopies),
	decUnify(Head,HeadC,_,Sub),
	quantify(UnquantCopies,Copies,existential),
	substitution(BodyC,Sub,Body).
clauseDCI([_|Theory],Head,Body,Sub,I,N,Copies,Variables) :-
	Iplus1 is I + 1,
	clauseDCI(Theory,Head,Body,Sub,Iplus1,N,Copies,Variables).


% clauseNFI(Theory,Head,Body,Subst,N)
%	"Head :- Body" Subst is a fresh instance of the N-th clause of Theory,
%	where Subst is a substitution.
% Ok for mode (+,+,-,-,-).

clauseNFI(Theory,Head,Body,Subst,N) :-
	metaVarSet(Head,Vars),
	clauseNFI(Theory,Head,Body,Sub,1,N),
	pruneSubst(Sub,Vars,Subst).

clauseNFI([Clause|_],Head,Body,Sub,N,N) :-
	copyTerm(Clause,(HeadC:-BodyC)),
	unify(Head,HeadC,_,Sub),
	substitution(BodyC,Sub,Body).
clauseNFI([_|Theory],Head,Body,Sub,I,N) :-
	Iplus1 is I + 1,
	clauseNFI(Theory,Head,Body,Sub,Iplus1,N).


% makeHead(Goal,Positions,DiscHead)
%	Assemble (as far as possible) the discriminant-head atom DiscHead
%	that is common to all discriminants relative to the proof of Goal;
%	project onto the declared auxiliary parameters, using Positions.

makeHead(Goal,Positions,DiscHead):-
	Goal=if([Atom],_),
	Atom=..[Pred|Args],
	Positions=positions(_,PosAuxParams,_,_,_),
	select(PosAuxParams,Args,DiscArgs),
	name(Pred,[First|Rest]),
	uppify(First,UppFirst),
	append("disc",[UppFirst|Rest],DiscPredStr),
	name(DiscPred,DiscPredStr),
	DiscHead=..[DiscPred|DiscArgs].


% extractDisc(FinalGoal,Subst,DiscNbr,Copies,Discs,OldDiscHead,Variables,Think)
%	Add a new clause to the (DiscNbr)th discriminant of Discs,
%	using FinalGoal, Subst, Copies, and OldDiscHead,Variables;
%	Think aloud iff Think = aloud.
% Assumption: no extraction is necessary for the minimal case (DiscNbr=1),
%		because Solve is assumed to contain discriminants.

extractDisc(_,_,1,_,_,_,_,Think) :-
	!,
	(Think=aloud ->				% think aloud (if required)
		nl,nl ;
		true).
extractDisc(FinalGoal,Subst,DiscNbr,Copies,Discs,OldDiscHead,Variables,Think) :-
	DiscNbr>1,
	OldDiscHead=..[OldPred|OldArgs],
	name(OldPred,OldName),
	name(DiscNbr,NbrStr),
	append(OldName,NbrStr,NewName),
	name(NewPred,NewName),
	substitution(OldArgs,Subst,InstArgs),
	append(InstArgs,Copies,NewArgs),
	NewDiscHead=..[NewPred|NewArgs],
	substitution(Copies,Subst,InstCopies),
	equations(Copies,InstCopies,Eqs),
	FinalGoal=if([],Conclusion),
	append(Eqs,Conclusion,Atoms),
	listComma(Atoms,DiscBody),
	Clause=(NewDiscHead:-DiscBody),
        Variables=variables(_,_,_,_,DecVars,_,_,_),
	bindings2(Clause,Copies,DecVars,DiscClause),
	position(Disc,Discs,DiscNbr),
	addLast(Disc,DiscClause),
	(Think=aloud ->				% think aloud (if required)
		write('Extracting: '),ppClause(DiscClause),nl,nl ;
		true).

extractDiscs([],[],[],[],_,_,_,_).
extractDiscs([FinalGoal|FinalGoals],[Subst|Substs],[DiscNbr|DiscNbrs],
		[Copies|Copiess],Discs,OldDiscHead,Variables,Think) :-
	extractDisc(FinalGoal,Subst,DiscNbr,Copies,
			Discs,OldDiscHead,Variables,Think),
	extractDiscs(FinalGoals,Substs,DiscNbrs,Copiess,
			Discs,OldDiscHead,Variables,Think).

extractDiscss([],_,_,_,_).
extractDiscss([Solutions|Solutionss],Discs,OldDiscHead,Variables,Think) :-
	Solutions=solutions(FinalGoals,Substs,DiscNbrs,Copiess),
	extractDiscs(FinalGoals,Substs,DiscNbrs,Copiess,
				 Discs,OldDiscHead,Variables,Think),
	extractDiscss(Solutionss,Discs,OldDiscHead,Variables,Think).


% genDisc(Disc,GenDisc,Variables)
%	GenDisc is a generalization, by heuristics 13-4 and 13-5, of Disc.
%	Heuristic 13-3 is already applied during the discriminant extraction.

genDisc(Disc,Disc,_) :-
	var(Disc),!.
genDisc(Disc,GenDisc,Variables) :-
	heuristic4(Disc,IntDisc),
	heuristic5(IntDisc,GenDisc,Variables).

genDiscs([],[],_).
genDiscs([Disc|Discs],[GenDisc|GenDiscs],Variables) :-
	genDisc(Disc,GenDisc,Variables),
	genDiscs(Discs,GenDiscs,Variables).

heuristic4(Disc,GenDisc) :-	% to be written, using late AP detection,
	GenDisc=Disc.		% because user AP declaration is not foolproof

heuristic5(Disc,GenDisc,Variables) :-
	Variables=variables(_,_,_,_,_,_,IPtails,_),
	updates(IPtails,Disc,GenDisc).

update(IPtail,Disc,GenDisc) :-
	findMax(Disc,IPtail,MaxClause,MaxPos),
	MaxClause=(Head:-Body),
	generalize(Body,IPtail,GenBody),
	GenMaxClause=(Head:-GenBody),
	effacePos(MaxPos,Disc,SufDisc),
	GenDisc=[GenMaxClause|SufDisc].

updates([],Disc,Disc).
updates([IPtail|IPtails],Disc,GenDisc) :-
	update(IPtail,Disc,IntDisc),
	updates(IPtails,IntDisc,GenDisc).


% findMax(Disc,Var,MaxClause,MaxPos)
%	MaxClause is the (MaxPos)th clause of clause-set Disc,
%	and has the largest-sized value of variable Var
%	among the equations of the bodies of Disc.

findMax(Disc,Var,MaxClause,MaxPos) :-
	findMax(Disc,Var,-1,_,true,MaxClause,0,MaxPos,1).

findMax(Disc,_,MaxSize,MaxSize,MaxClause,MaxClause,MaxPos,MaxPos,_) :-
	var(Disc),!.
findMax([Clause|Clauses],Var,CurrMaxSize,MaxSize,
		CurrMaxClause,MaxClause,CurrMaxPos,MaxPos,CurrPos) :-
	NewPos is CurrPos + 1,
	getSize(Clause,Var,CurrSize),
	CurrSize > CurrMaxSize  ->
		findMax(Clauses,Var,CurrSize,MaxSize,
			Clause,MaxClause,CurrPos,MaxPos,NewPos)		   ;
		findMax(Clauses,Var,CurrMaxSize,MaxSize,
			CurrMaxClause,MaxClause,CurrMaxPos,MaxPos,NewPos).


% getSize(Clause,Var,Size)
%	Size is the size of the value that is unified with variable Var
%	within the equations of the body of clause Clause.

getSize(Clause,Var,Size) :-
	Clause=(_:-Body),
	locateEq(Body,Var,Val),
	size(Val,Size).

locateEq((Var=Val),Var,Val).
locateEq(((Var=Val),_),Var,Val) :- !.
locateEq((_,Atoms),Var,Val) :-
	locateEq(Atoms,Var,Val).


% generalize(Body,Var,GenBody)
%	GenBody is Body where the value that is unified with variable Var
%	is generalized to infinite size.

generalize(true,_,true).
generalize((Var=Val),Var,(Var=GenVal)) :-
	maximize(Val,GenVal).
generalize(((Var=Val),Atoms),Var,((Var=GenVal),Atoms)) :-
	!,maximize(Val,GenVal).
generalize((Atom,Atoms),Var,(Atom,GenAtoms)) :-
	generalize(Atoms,Var,GenAtoms).

% maximize(T,GenT)
%	GenT is an infinite-sized copy of inductively-defined term T.

maximize(0,V) :-
	brandNew(V,dontKnow).
maximize(s(N),s(GenN)) :-
	maximize(N,GenN).
maximize([],V) :-
	brandNew(V,dontKnow).
maximize([H|T],[H|GenT]) :-
	maximize(T,GenT).
maximize(T,T) :-
	T='$VAR'(_,_).


% addDiscs(Discs,Variables,LA6,LA7)
%	Merge the discriminants Discs into LA6, yielding LA7, using Variables.
% Assumption: there is no relevant discriminant for the minimal case.
% Assumption: there is at most one non-recursive case,
%		and its discriminant then has only one clause.

addDiscs(Discs,Variables,LA6,LA7) :-
	LA6=iff(Head,or(MinCase,NRecCase6,RecCase6,[])),
	Discs=[_|NMinDiscs],
	addDiscs1(NMinDiscs,Variables,NRecCase6,NRecCase7,RecDiscs),
	addDiscs2(RecDiscs,Variables,RecCase6,RecCase7),
	LA7=iff(Head,or(MinCase,NRecCase7,RecCase7,[])).

addDiscs1(Discs,_,undefined,undefined,Discs) :- !.
addDiscs1([Disc|RemDiscs],_,NRecCase,NRecCase,RemDiscs) :- var(Disc),!.
addDiscs1([[DiscClause|_]|RemDiscs],Variables,NRecCase,NewNRecCase,RemDiscs) :-
	NRecCase=and(NMinimal,Decompose,undefined,SolveNMin,NRecEqsss),
	makeDisc(DiscClause,Variables,Discriminate),
	NewNRecCase=and(NMinimal,Decompose,Discriminate,SolveNMin,NRecEqsss).

addDiscs2([],_,[],[]).
addDiscs2([Disc|Discs],Variables,[RecCase|RecCases],NewRecCases) :-
	addDisc(Disc,Variables,RecCase,SomeNewRecCases),
	addDiscs2(Discs,Variables,RecCases,OtherNewRecCases),
	append(SomeNewRecCases,OtherNewRecCases,NewRecCases).

addDisc(Disc,_,RecCase,[RecCase]) :-
	var(Disc),!.
addDisc(Disc,Variables,RecCase,NewRecCases) :-
	addDisc2(Disc,Variables,RecCase,NewRecCases).

addDisc2(Disc,_,_,[]) :-
	var(Disc),!.
addDisc2([DiscClause|DiscClauses],Variables,RecCase,[NewRecCase|NewRecCases]) :-
	RecCase=and(NMinimal,Decompose,undefined,Recur,ProcComp,RecEqsss),
	makeDisc(DiscClause,Variables,Discriminate),
	NewRecCase=and(NMinimal,Decompose,Discriminate,Recur,ProcComp,RecEqsss),
	addDisc2(DiscClauses,Variables,RecCase,NewRecCases).

makeDisc(DiscClause,Variables,Discriminate) :-
	DiscClause=(HeadD:-BodyD),
	listComma(SomeAtoms,BodyD), % (-,+)
	Variables=variables(_,_,AuxParams,_,_,_,_,_),
	length(AuxParams,N),
	HeadD=..[_|Args],
	firstM(N,Args,AuxVals),
	equations(AuxParams,AuxVals,Eqs),
	append(Eqs,SomeAtoms,Discriminate).
