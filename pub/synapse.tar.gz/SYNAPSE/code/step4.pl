%******************************************************************************
%*				 step4.pl				      *
%******************************************************************************

% step4(Exs,Props,Variables,Positions,LA3,LA4)
%	Synthesis of LA4 from LA3, Exs, and Props;
%       Variables is the compound term of variables, where
%       the following components are initialized here:
%		OtherTailss are the tailss of OtherParams;
%       and the following components are used here:
%		AuxParams are the auxiliary parameters of Params;
%		OtherParams are the other parameters of Params;
%               IPtails are the tails among DecVars;
%	Positions is the compound term of parameter positions, where
%	the following components are used here:
%		PosIP is the position of IP within Params;
%		PosAuxParams are the positions of AuxParams within Params;
%		PosOtherParams are the positions of OtherParams within Params;
%		PosIPtails are the positions of IPtails within DecVars.
% Fully automatic, deductive version.

step4(Exs,Props,Variables,Positions,LA3,LA4) :-
        Variables=variables(_,_,AuxParams,OtherParams,_,_,IPtails,_),
	LA3=iff(Head,or(MinCase,NRecCase3,undefined,[])),
	NRecCase3=and(NMinimal,Decompose,undefined,undefined,NRecEqsss3),
	tailVars(OtherParams,IPtails,OtherTailss),
	functor(Head,Pred,Arity),
	makeRecur(IPtails,Pred,Arity,Positions,AuxParams,OtherTailss,Recur),
	assertEP(Exs,Props),
	otherTailEqs(NRecEqsss3,Positions,Recur,OtherTailss,
			RecEqsss,NRecEqsss4),
	retractEP(Head),	
	initNRecCase(NRecEqsss4,NMinimal,Decompose,NRecCase4),
	initRecCase(RecEqsss,NMinimal,Decompose,Recur,RecCase),
	LA4=iff(Head,or(MinCase,NRecCase4,RecCase,[])),
        Variables=variables(_,_,_,_,_,_,_,OtherTailss).


% makeRecur(IPtails,Pred,Arity,Positions,AuxParams,OtherTailss,Recur)
%	Recur is a conjunction of recursive atoms (wrt Pred/Arity).

makeRecur([],_,_,_,_,[],[]).
makeRecur([IPtail|IPTs],Pred,Arity,Positions,AuxParams,
		[OtherTails|OTss],[RecAtom|RecAtoms]) :-
	Positions=positions(PosIP,PosAuxParams,PosOtherParams,_,_),
	functor(RecAtom,Pred,Arity),
	arg(PosIP,RecAtom,IPtail),
	args(PosAuxParams,RecAtom,AuxParams),
	args(PosOtherParams,RecAtom,OtherTails),
	makeRecur(IPTs,Pred,Arity,Positions,AuxParams,OTss,RecAtoms).


% otherTailEqs(Eqsss1,Positions,Recur,OtherTailss,Eqsss2,Eqsss3)
%	Eqsss2 is the elements of Eqsss1
%		for which all the recursive atoms hold,
%		plus equality atoms for the tails of the other parameters;
%	Eqsss3 is the elements of Eqsss1
%		for which at least one of the recursive atoms does not hold;
%	Positions, Recur, and OtherTailss are used for these computations.

otherTailEqs([],_,_,_,[],[]).
otherTailEqs([[Eqs1,Eqs3]|Eqsss1],Positions,Recur,OtherTailss,Eqsss2,Eqsss3) :-
	Positions=positions(_,PosAuxParams,_,_,PosIPtails),
	select(PosAuxParams,Eqs1,AuxParamEqs),
	equations(_,ValAuxParams,AuxParamEqs),
	otherTailEqs1(PosIPtails,Positions,Recur,
			OtherTailss,ValAuxParams,Eqs3,Eqs4),
	handle(Positions,Eqs1,Eqs3,Eqs4,Eqsss2,TEqsss2,Eqsss3,TEqsss3),
	otherTailEqs(Eqsss1,Positions,Recur,OtherTailss,TEqsss2,TEqsss3).

otherTailEqs1([],_,[],[],_,_,[]).
otherTailEqs1([PosIPtail|PIPTs],Positions,[RecAtom|RecAtoms],
		[OtherTails|OTss],ValAuxParams,Eqs3,Eqs4) :-
	Positions=positions(PosIP,PosAuxParams,PosOtherParams,_,_),
	ground2var(RecAtom,NGrecAtom,_),
	position((_=ValIPtail),Eqs3,PosIPtail),
	arg(PosIP,NGrecAtom,ValIPtail),
	args(PosAuxParams,NGrecAtom,ValAuxParams),
	args(PosOtherParams,NGrecAtom,NGotherTails),
	values(NGotherTails,OtherTails,NGrecAtom,ValOtherTails),
	continue(PIPTs,Positions,RecAtoms,[OtherTails|OTss],
			ValAuxParams,Eqs3,ValOtherTails,Eqs4).


% values(Vars,Names,Atom,Valuess)
%	Valuess are the values of variables Vars such that Atom holds;
%	Names are the names of the variables Vars.
% NB. [] means failure, whereas [[]] means success w/o instantiations.

values(Vars,_,Atom,Valuess) :-	% deductive oracle
	setof(Vars,Atom,NGvaluess),!,	% Quintus: setof/3 fails if failure
	var2ground(NGvaluess,Valuess).
%values(Vars,Names,Atom,Valuess) :-	% interactive oracle
%	write('Values of '),write(Names),write(' such that:'),nl,
%	Vars=Names,tab(22),print(Atom),nl,
%	ask('holds',"[]",ValuessStr),
%	myPhrase(list(Valuess),ValuessStr).
values(_,_,_,[]).			% the default answer is failure


% continue(PIPTs,Positions,Recs,[OtherTails|OTss],
%		ValAuxParams,Eqs3,ValOtherTails,Eqs4)
%	...

continue(_,_,_,_,_,_,[],undefined) :- !.	% failure
continue(PIPTs,Positions,RecAtoms,[[]|OTss],ValAuxParams,Eqs3,[[]],Eqs4) :-
	!,					% no  instantiations
	otherTailEqs1(PIPTs,Positions,RecAtoms,OTss,ValAuxParams,Eqs3,Eqs4).
continue(PIPTs,Positions,RecAtoms,[OtherTails|OTss],
		ValAuxParams,Eqs3,ValOtherTails,Eqs4) :-
	FirstEq4=in(OtherTails,ValOtherTails),
	otherTailEqs1(PIPTs,Positions,RecAtoms,OTss,ValAuxParams,Eqs3,MoreEqs4),
	append([FirstEq4],MoreEqs4,Eqs4).   % OK even if MoreEqs4=undefined (!)


% handle(Positions,Eqs1,Eqs3,Eqs4,Eqsss2,TEqsss2,Eqsss3,TEqsss3)
%	...

handle(_,Eqs1,Eqs3,Eqs4,Eqsss2,TEqsss2,Eqsss3,TEqsss3) :-
	Eqs4=undefined,!,		% Recur is not provable
	TEqsss2=Eqsss2,
	Eqsss3=[[Eqs1,Eqs3]|TEqsss3].
handle(Positions,Eqs1,Eqs3,Eqs4,Eqsss2,TEqsss2,Eqsss3,TEqsss3) :-
	extractHXTYZY(Positions,[Eqs1,Eqs3,Eqs4],Vals),
	admAlt(Vals,_),!,   % Recur is provable and has admissible alternatives
	Eqsss2=[[Eqs1,Eqs3,Eqs4]|TEqsss2],
	TEqsss3=Eqsss3.
handle(_,Eqs1,Eqs3,_,Eqsss2,TEqsss2,Eqsss3,TEqsss3) :-
	TEqsss2=Eqsss2,			% Recur is provable, but has no
	Eqsss3=[[Eqs1,Eqs3]|TEqsss3].	% admissible alternatives


% initNRecCase(NRecEqsss,NMinimal,Decompose,NRecCase)
%	NRecCase is ...

initNRecCase([],_,_,undefined).
initNRecCase([Eqss|Eqsss],NMinimal,Decompose,NRecCase) :-
	NRecCase=and(NMinimal,Decompose,undefined,undefined,[Eqss|Eqsss]).


% initRecCase(RecEqsss,NMinimal,Decompose,Recur,RecCase)
%	RecCase is ...

initRecCase(_,_,_,[],undefined).
initRecCase([Eqss|Eqsss],NMinimal,Decompose,Recur,RecCase) :-
	RecCase=[and(NMinimal,Decompose,undefined,Recur,
					undefined,[Eqss|Eqsss])].


% tailVars(Vars,L,TailVarss)
%	TailVarss are lists of variables obtained by:
%		prefixing the names of Vars by "T", and
%		suffixing them by N, for N ranging from 1 to |L|.
%	Exception: if |L|=1, then no suffixing is made.
% E.g. tailVars(["X","Y"],[_,_,_],[["TX1","TY1"],["TX2","TY2"],["TX3","TY3"]]).

tailVars(Vars,L,TailVarss) :-
	length(L,N),
	tailVars1(Vars,N,TailVarss).

tailVars1(Vars,N,[TailVars]) :-
	N=1,!,
	tailVars3(Vars,[],TailVars).
tailVars1(Vars,N,TailVarss) :-
	N>1,
	tailVars2(Vars,1,N,TailVarss).

tailVars2(_,I,N,[]) :-
	I>N.
tailVars2(Vars,I,N,[TailVars|TailVarss]) :-
	I=<N,
	name(I,Ichars),
	tailVars3(Vars,Ichars,TailVars),
	Iplus1 is I + 1,
	tailVars2(Vars,Iplus1,N,TailVarss).

tailVars3([],_,[]).
tailVars3([Var|Vars],Nchars,[TailVar|TailVars]) :-
	code('T',UppT),
	groundStr(Var,Name),
	append([UppT|Name],Nchars,TailName),
	groundStr(TailVar,TailName),
	tailVars3(Vars,Nchars,TailVars).
