%******************************************************************************
%*				 prettyPrint.pl				      *
%******************************************************************************


%%% Pretty-printing logic algorithms

% prettyPrint(ExpLA,Step)
%	Pretty-print ExpLA, stating that it results from step Step.

prettyPrint(ExpLA,Step) :-
	thinkMode(aloud(Steps,BothOrOne)),
	memberCheck(Steps,Step) ->
		(BothOrOne=none ->
			true ;
			(gamma(ExpLA,GenLA),
			 prettyPrintGen(GenLA,Step),
			 BothOrOne=both ->
				prettyPrintExp(ExpLA,Step) ;
				true))				;
		true.

prettyPrintGen(GenLA,Step) :-
	GenLA=iff(Head,Def),
	functor(Head,Pred,_),
	nl,write('LA'),write(Step),write('('),
	write(Pred),write(') is:'),nl,nl,
	ppHead(Head),
	Def=or(MinCase,NRecCase,RecCase,[]),
	ppMin(MinCase),
	ppNRec(NRecCase),
	ppRec(RecCase),
	nl.

prettyPrintExp(ExpLA,Step) :-
	ExpLA=iff(Head,Def),
	functor(Head,Pred,_),
	nl,write('exp(LA'),write(Step),write('('),
	write(Pred),write(')) is:'),nl,nl,
	ppHead(Head),
	Def=or(MinCase,NRecCase,RecCase,Eqsss),
	ppMin(MinCase),
	ppNRec(NRecCase),
	ppRec(RecCase),
	ppEqsss(Eqsss,0,none),
	nl.


% ppHead(Head)
%	Pretty-print Head.

ppHead(Head) :-
	print(Head),
	ppConn(iff),
	nl,nl.


% ppMin(MinCase)
%	Pretty-print MinCase.

ppMin(undefined).
ppMin(and(Minimal,Solve,Eqsss)) :-
	ppPredVar(Minimal,	0,	none),
	ppPredVar(Solve,	15,	and),
	ppEqsss(Eqsss,		31,	and).


% ppNRec(NRecCase)
%	Pretty-print NRecCase.

ppNRec(undefined).
ppNRec(and(NMinimal,Decompose,Discriminate,SolveNMin,Eqsss)) :-
	ppPredVar(NMinimal,	0,	or),
	ppPredVar(Decompose,	15,	and),
	ppPredVar(Discriminate,	15,	and),
	ppPredVar(SolveNMin,	15,	and),
	ppEqsss(Eqsss,		31,	and).


% ppRec(RecCase)
%	Pretty-print RecCase.

ppRec(undefined).
ppRec([]).
ppRec([and(NMinimal,Decompose,Discriminate,Recur,ProcComp,Eqsss)|RecCase]) :-
	ppPredVar(NMinimal,	0,	or),
	ppPredVar(Decompose,	15,	and),
	ppPredVar(Discriminate,	15,	and),
	ppPredVar(Recur,	15,	and),
	ppPredVar(ProcComp,	15,	and),
	ppEqsss(Eqsss,		31,	and),
	ppRec(RecCase).


% ppPredVar(PredVar,Indent,Connective)
%	Pretty-print PredVar,
%	preceded by Indent blank characters and Connective.

ppPredVar(undefined,_,_) :- !.
ppPredVar(Conjunction,Indent,Connective) :-
	tab(Indent),
	ppConn(Connective),
	ppConj(Conjunction),
	nl.


% ppEqsss(Eqsss,Indent,Connective)
%	Pretty-print Eqsss,
%	preceded by Indent blank characters and Connective.

ppEqsss([],_,_).
ppEqsss([Eqss|Eqsss],Indent,Connective) :-
	tab(Indent),
	ppConn(Connective),
	NewIndent is Indent + 3,
	ppEqss(Eqss,NewIndent,none),
	ppEqsss(Eqsss,NewIndent).

ppEqsss([],_).
ppEqsss([Eqss|Eqsss],Indent) :-
	tab(Indent),
	ppEqss(Eqss,Indent,or),
	ppEqsss(Eqsss,Indent).


% ppEqss(Eqss,Indent,Connective)
%	Pretty-print Eqss,
%	preceded by Indent blank characters and Connective.

ppEqss([],_,_).
ppEqss([Eqs|Eqss],Indent,Connective) :-
	ppConn(Connective),
	NewIndent is Indent + 3,
	ppEqs(Eqs,none),
	ppEqss(Eqss,NewIndent).

ppEqss([],_).
ppEqss([[]|Eqss],Indent) :-
	ppEqss(Eqss,Indent).
ppEqss([[Eq|Eqs]|Eqss],Indent) :-
	tab(Indent),
	ppEqs([Eq|Eqs],and),
	ppEqss(Eqss,Indent).
	

% ppEqs(Eqs,Connective)
%	Pretty-print Eqs,
%	preceded by Connective, if non-empty.

ppEqs(Eqs,Connective) :-
	ppConn(Connective),
	ppConj(Eqs),
	nl.


% ppConj(Conjunction)
%	Pretty-print Conjunction.

ppConj([]).
ppConj([Literal]) :-
	ppLit(Literal),!.
ppConj([Lit1,Lit2|Lits]) :-
	ppLit(Lit1),
	ppConn(and),
	ppConj([Lit2|Lits]).


% ppLit(Literal)
%	Pretty-print Literal.

ppLit(~(Atom)) :-			% not used
	!,
	ppConn(not),
	print(Atom).
ppLit(Atom) :-
	print(Atom).


% ppConn(Connective)
%	Pretty-print Connective.

ppConn(none) :-
	tab(3).
ppConn(not) :-
	write('~').
ppConn(iff) :-
	write(' <==> ').
ppConn(and) :-
	write(' & ').
ppConn(or) :-
	write(' v ').
ppConn(if) :-
	write(' <== ').


% gamma(LA,GenLA)
%	GenLA is LA without any trailing equality atoms.

gamma(LA,GenLA) :-
	LA=iff(Head,Def),
	GenLA=iff(Head,GenDef),
	Def=or(MinCase,NRecCase,RecCase,_),
	GenDef=or(GenMinCase,GenNRecCase,GenRecCase,[]),
	genMinCase(MinCase,GenMinCase),
	genNRecCase(NRecCase,GenNRecCase),
	genRecCase(RecCase,GenRecCase).

genMinCase(undefined,undefined).
genMinCase(MinCase,GenMinCase) :-
	MinCase=and(Minimal,Solve,_),
	GenMinCase=and(Minimal,Solve,[]).

genNRecCase(undefined,undefined).
genNRecCase(NRecCase,GenNRecCase) :-
	NRecCase=and(NMinimal,Decompose,Discriminate,SolveNMin,_),
	GenNRecCase=and(NMinimal,Decompose,Discriminate,SolveNMin,[]).

genRecCase(undefined,undefined).
genRecCase([],[]).
genRecCase([H|RecCase],[GenH|GenRecCase]) :-
	H=and(NMinimal,Decompose,Discriminate,Recur,ProcComp,_),
	GenH=and(NMinimal,Decompose,Discriminate,Recur,ProcComp,[]),
	genRecCase(RecCase,GenRecCase).


%%% Hooks for the print/1 built-in

% Hook for printing out ground Peano-integers as integers (for print/1).

portray(s(P)) :-
	ground(P),
	peano2Int(s(P),I),
	write(I).


% Hook for printing out meta-variables (for print/1).
% Existentially quantified meta-variables are prefixed by "?".
% The $VAR/1 functor gets special handling by the predefined write/1 procedure,
% e.g.  write('$VAR'('Foo'))    yields: Foo
% or    write('$VAR'(6))        yields: E       {this second feature
% or    write('$VAR'(27))       yields: A1        is not used here, though}.

portray('$VAR'(Name,Quant)) :-
	Quant=existential,!,
	write('?'),
	write('$VAR'(Name)).
portray('$VAR'(Name,_)) :-
	write('$VAR'(Name)).



%%% Pretty-printing theories, clauses, and goals

% ppTheory(Theory)
%	Pretty-print Theory.

ppTheory(Theory) :-
	write('Theory for the proofs:'),nl,nl,
	ppTheory(Theory,1).

ppTheory([],_) :-
	nl.
ppTheory([Clause|Theory],I) :-
	write('   Clause #'),write(I),write(' : '),
	ppClause(Clause),
	Iplus1 is I + 1,
	ppTheory(Theory,Iplus1).


% ppClause(Clause)
%	Pretty-print Clause.

ppClause(Clause) :-
	Clause=(Head:-true),!,
	print(Head),
	write('.'),
	nl.
ppClause(Clause) :-
	Clause=(Head:-Body),
	print(Head),
	write(' :- '),
	ppBody(Body),
	write('.'),
	nl.


% ppBody(Body)
%	Pretty-print Body.

ppBody(true) :- !.
ppBody((A,B)) :-
	!,ppLit(A),
	write(','),
	ppBody(B).
ppBody(A) :-
	ppLit(A).


% ppGoal(Goal)
%	Pretty-print Goal.

ppGoal(Goal) :-
	Goal=if(Concl,Hyp),
	ppConj(Concl),
	ppConn(if),
	ppConj(Hyp),
	nl.

ppGoals([]).
ppGoals([Goal|Goals]) :-
	ppGoal(Goal),
	ppGoals(Goals).



%%% Pretty-printing proof-trees

printPrimRule(Subst,Rule,Atom) :-
	functor(Atom,Pred,_),
	name(Pred,Str),length(Str,L),Lplus13 is L + 13,
	tab(Lplus13),write('|'),nl,
	write(' '),write(Rule),write(' on LA('),write(Pred),
	write(') | '),print(Subst),nl,
	tab(Lplus13),write('|'),nl.

printPrimRules([],_,_).
printPrimRules([Subst|Substs],Rule,Atom) :-
	printPrimRule(Subst,Rule,Atom),
	printPrimRules(Substs,Rule,Atom).

printRule(Subst,Rule,Nbr) :-
	tab(18),write('|'),nl,
	write(' '),write(Rule),write(' on clause #'),write(Nbr),
	write(' | '),print(Subst),nl,
	tab(18),write('|'),nl.

printRules([],_,[]).
printRules([Subst|Substs],Rule,[Nbr|Nbrs]) :-
	printRule(Subst,Rule,Nbr),
	printRules(Substs,Rule,Nbrs).
