%******************************************************************************
%*				 step3.pl				      *
%******************************************************************************

% step3(Variables,Positions,DefaultDecs,LA2,LA3)
%	Synthesis of LA3 from LA2;
%       Variables is the compound term of variables, where
%       the following components are initialized here:
%		DecVars are the heads and tails of IP;
%		IPheads are the heads among DecVars;
%		IPtails are the tails among DecVars;	
%       and the following component is used here:
%               IP is the induction parameter of Params;
%	Positions is the compound term of parameter positions, where
%	the following components are initialized here:
%		PosIPheads are the positions of IPheads within DecVars;
%		PosIPtails are the positions of IPtails within DecVars;
%	and the following component is used here:
%		PosIP is the position of IP within Params;
%	DefaultDecs are the default Decomposition operators.
% Fully manual version --> automatizable.
% NB. No test whether NMinimal is a pre-condition for Decompose.

step3(Variables,Positions,DefaultDecs,LA2,LA3) :-
        Variables=variables(_,IP,_,_,_,_,_,_),
	Positions=positions(PosIP,_,_,_,_),
	LA2=iff(Head,or(MinCase,NRecCase2,undefined,[])),
	NRecCase2=and(NMinimal,undefined,undefined,undefined,NRecEqsss2),
	selectDec(Decompose,IP,DefaultDecs,DecVars),
	partitionDecVars(DecVars,IPheads,PosIPheads,IPtails,PosIPtails),
	headTailEqs(NRecEqsss2,PosIP,Decompose,DecVars,NRecEqsss3),
	NRecCase3=and(NMinimal,Decompose,undefined,undefined,NRecEqsss3),
	LA3=iff(Head,or(MinCase,NRecCase3,undefined,[])),
        Variables=variables(_,_,_,_,DecVars,IPheads,IPtails,_),
	Positions=positions(_,_,_,PosIPheads,PosIPtails).


% selectDec(Decompose,IP,DefaultDecs,DecVars)
%	Select an instance Decompose of Decompose(IP,HIP*,TIP*);
%	IP is the induction parameter;
%	DefaultDecs are the default instances;
%	DecVars are the newly introduced variables;
% Decompose is assumed to be deterministic, given a ground value of the IP.
% The heads of the induction parameter, say X, are written as "HX1", "HX2", ...
% The tails of the induction parameter, say X, are written as "TX1", "TX2", ...
% Do NOT use anonymous variables in Decompose!

selectDec(Decompose,IP,DefaultDecs,DecVars) :-
	asks('Decompose',DefaultDecs,DecString),
	myPhrase(conj(Decompose),DecString),
	metaVarSet(Decompose,AllDecVars),
	deleteAll(IP,AllDecVars,DecVars).


% partitionDecVars(DecVars,IPheads,PosIPheads,IPtails,PosIPtails)
%	PosIPheads (PosIPtails) are the positions of the variables IPheads
%	(IPtails) among DecVars whose names start with "H" ("T").

partitionDecVars(DecVars,IPheads,PosIPheads,IPtails,PosIPtails) :-
	partitionDecVars(DecVars,IPheads,PosIPheads,IPtails,PosIPtails,1).

partitionDecVars([],[],[],[],[],_).
partitionDecVars([H|DecVars],[H|IPHs],[P|PIPHs],IPtails,PosIPtails,P) :-
	code('H',UppH),
	groundStr(H,[UppH|_]),!,	% dangerous assumption!
	Pplus1 is P + 1,
	partitionDecVars(DecVars,IPHs,PIPHs,IPtails,PosIPtails,Pplus1).
partitionDecVars([T|DecVars],IPheads,PosIPheads,[T|IPTs],[P|PIPTs],P) :-
	code('T',UppT),
	groundStr(T,[UppT|_]),		% dangerous assumption!
	Pplus1 is P + 1,
	partitionDecVars(DecVars,IPheads,PosIPheads,IPTs,PIPTs,Pplus1).


% headTailEqs(Eqsss1,PosIP,Decompose,DecVars,Eqsss2)
%	Eqsss2 is Eqsss1 plus equality atoms for the heads and tails of the IP;
%	PosIP, Decompose, and DecVars are used for these computations.

headTailEqs([],_,_,_,[]).
headTailEqs([[Eqs1]|Eqsss1],PosIP,Decompose,DecVars,[[Eqs1,Eqs3]|Eqsss2]) :-
	position((IP=ValueIP),Eqs1,PosIP),	% (-,+,+)
	binding(Decompose,IP,ValueIP,InstDecompose),
	ground2var(InstDecompose,NGInstDecompose,NGVars),
	listComma(NGInstDecompose,Conj),   % conjunctions are repr. as lists
	setof(NGVars,Conj,[ConjValues]),
	equations(DecVars,ConjValues,Eqs3),
	headTailEqs(Eqsss1,PosIP,Decompose,DecVars,Eqsss2).
