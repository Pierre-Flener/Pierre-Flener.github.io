%******************************************************************************
%*				 grammar.pl				      *
%******************************************************************************


% myPhrase(PhraseType,List)
%	Deterministic version of the built-in phrase/2.

myPhrase(PhraseType,List) :-
	phrase(PhraseType,List),!.


%%% Definite Clause Grammar for parsing procedure declarations.

proc(Pred,Params) --> preFunct(Pred) , "(" , variables(Params) , ").".

preFunct(F)	--> low(C) , string(Cs) , {name(F,[C|Cs])}.

variables(LV)	--> variable(V) , {LV=[V]}.
variables(LV)	--> variable(V) , "," , variables(Vs) , {LV=[V|Vs]}.

variable(V)	--> upp(C) , string(Cs) , {name(Var,[C|Cs]) ,
						V='$VAR'(Var,dontKnow)}.
variable(V)	--> "_" , {V='$VAR'('_',dontKnow)}.

string(S)	--> [], {S=[]}.
string(S)	--> any(C) , string(Cs) , {S=[C|Cs]}.

any(C)		--> num(C) , !.
any(C)		--> upp(C) , !.
any(C)		--> low(C) , !.

num(C)		--> [C] , {code('0',Zero) , code('9',Nine) , Zero=<C , C=<Nine}.
upp(C)		--> [C] , {code('A',UppA) , code('Z',UppZ) , UppA=<C , C=<UppZ}.
low(C)		--> [C] , {code('a',LowA) , code('z',LowZ) , LowA=<C , C=<LowZ}.



%%% Definite Clause Grammar for parsing terms.

term(T)		--> nInfix(T).
term(T)		--> infix(T).

nInfix(T)	--> constant(T).
nInfix(T)	--> variable(T).
nInfix(T)	--> preFunct(F) , "(" , terms(Ts), ")" , {T=..[F|Ts]}.
nInfix(T)	--> list(T).
nInfix(T)	--> "(" , term(T) , ")".

infix(T)	--> nInfix(T1) , inFunct(F) , term(T2) , {T=..[F,T1,T2]}.

constant(A)	--> atomC(N) , {name(A,N)}.
constant(P)	--> integerC(N) , {name(I,N) , int2Peano(I,P)}.

inFunct(F)	--> "="   , {F='=' }.
inFunct(F)	--> "\="  , {F='\='}.	% unsound inequality
inFunct(F)	--> "~="  , {F='~='}.	% suspicious inequality
inFunct(F)	--> "=/=" , {F='=/='}.	% attempt at sound inequality
inFunct(F)	--> ">"   , {F=gt}.
inFunct(F)	--> "<"   , {F=lt}.
inFunct(F)	--> ">="  , {F=ge}.
inFunct(F)	--> "<="  , {F=le}.

atomC(A)	--> low(C) , string(Cs) , {A=[C|Cs]}.

integerC(I)	--> num(N) , {I=[N]}.
integerC(I)	--> num(N) , integerC(Ns) , {I=[N|Ns]}.

list(L)		--> "[]" , {L=[]}.
list(L)		--> "[" , terms(L) , "]".
list(L)		--> "[" , terms(Hs) , "|" , variable(V) , "]", {append(Hs,V,L)}.

terms(LT)	--> term(T) , {LT=[T]}.
terms(LT)	--> term(T) , "," , terms(Ts), {LT=[T|Ts]}.



%%% Definite Clause Grammar for parsing Horn clauses.

% Used for reading examples and properties.

hornClause(C)	--> term(Head) , "." , {C=(Head:-true)}.
hornClause(C)	--> term(Head) , ":-" , goals(Body) , "." , {C=(Head:-Body)}.

goals(Gs)	--> term(T) , {Gs=T}.
goals(Gs)	--> term(T) , "," , goals(Ts) , {Gs=(T,Ts)}.



%%% Definite Clause Grammar for parsing (non-empty) conjunctions.

% Used for reading instances of predicate variables,
% namely: non-empty list (conjunction) of term.

conj(C)		--> term(T) , {C=[T]}.
conj(C)		--> term(T) , "&" , conj(Ts), {C=[T|Ts]}.
