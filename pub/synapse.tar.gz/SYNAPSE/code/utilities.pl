%******************************************************************************
%*				 utilities.pl				      *
%******************************************************************************


% addLast(L,E)
%	Add element E to open-ended list L.

addLast(L,E) :-
	var(L),!,
	L=[E|_].
addLast(L,E) :-
	L=[_|T],
	addLast(T,E).


% args(Ns,T,As)
%	As are the arguments at positions Ns in term T.

args([],_,[]).
args([N|Ns],T,[A|As]) :-
	arg(N,T,A),
	args(Ns,T,As).


% ask(Question,Default,Answer)
%	Write out Question followed by Default (unless Default is empty);
%	read an entire line from the current input stream into Line.
%	If the input stream is a file, and its EOF-marker is reached,
%	then that file is closed, and Line is read from `stdin' instead
%	(this feature allows, e.g., prefix scenarios).
%	If Line is empty, then Answer is Default and is written out,
%	otherwise Answer is Line and is written out
%	if the input stream is a file.

asks(Question,[Default|_],Answer) :-
	ask(Question,Default,Answer) -> true ; !,fail.
asks(Question,[_|Defaults],Answer) :-
	asks(Question,Defaults,Answer).

ask(Question,Default,Answer) :-
	write(Question),
	writeDef(Default),
	write(' : '),
	(Default~="",
	 autoMode(automatic) ->
		!,Line=Default  ;
		readLine(Line)),
	handleDef(Line,Default,Answer),
	nl,
	(Answer="back" -> !,fail ; true).
ask(Question,Default,Answer) :-
	ask(Question,Default,Answer).

writeDef([]).
writeDef([D|Ds]) :-
	write(' {'),
	writeString([D|Ds]),
	write('}').

writeString([]).
writeString([C|Cs]) :-
	put(C),
	writeString(Cs).

readLine(L) :-
	at_end_of_file,!,
	seen,
	readLine(L).
readLine([]) :-
	at_end_of_line,!,
	skip_line.
readLine([C|Cs]) :-
	get(C),
	readLine(Cs).

handleDef([],Answer,Answer) :-
	writeString(Answer),
	nl.
handleDef([A|As],_,[A|As]) :-
	echo([A|As]).

echo(Answer) :-
	seeing(File),
	File~=user,!,
	writeString(Answer),
	nl.
echo(_) :-
	seeing(user).


% assertEP(Exs,Props)
%	Assert the examples Exs and the properties Props in non-ground form.

assertEP(Exs,Props) :-
	assertExs(Exs),
	assertProps(Props).

assertExs([]).
assertExs([Ex|Exs]) :-
	assert(Ex),
	assertExs(Exs).

assertProps([]).
assertProps([Prop|Props]) :-
	ground2var(Prop,NGProp,_),
	assert(NGProp),
	assertProps(Props).


% retractEP(Head)
%	Retract all clauses relative the predicate/arity of Head.

retractEP(Head) :-
	functor(Head,Pred,Arity),
	abolish(Pred/Arity).


% code(Character,Code)
%	Character has decimal code Code.

code(',',44).
code('-',45).
code('0',48).
code('9',57).
code('A',65).
code('H',72).
code('T',84).
code('Z',90).
code('[',91).
code(']',93).
code('_',95).
code('a',97).
code('z',122).


% deleteAll(E,L,R)
%	R is list L without all (if any) of its occurrences of term E.
% OK for modes (+,+,?).

deleteAll(_,[],[]) :- !.
deleteAll(E,[E|TL],R) :-
	!,deleteAll(E,TL,R).
deleteAll(E,[HL|TL],[HL|TR]) :-
	deleteAll(E,TL,TR).


% deleteAlls(L1,L2,L)
%	L is list L2 without all its occurrences of the terms of list L1.
% N.B. deleteAlls([E],L,R) <==> deleteAll(E,L,R).

deleteAlls([],L,L).
deleteAlls([HL1|TL1],L2,L) :-
	deleteAll(HL1,L2,TL2),
	deleteAlls(TL1,TL2,L).


% efface(E,L,R)
%	R is list L without its first, existing occurrence of term E.
% OK for modes (+,+,?).

efface(E,[E|R],R) :- !.
efface(E,[HL|TL],[HL|TR]) :-
%	E~=HL,
	efface(E,TL,TR).


% effacePos(P,L,R)
%	R is list L without its P-th term.
% OK for modes (+,+,?).

effacePos(1,[_|R],R) :- !.
effacePos(P,[HL|TL],[HL|TR]) :-
	P>1,
	Pminus1 is P-1,
	effacePos(Pminus1,TL,TR).


% equations(Vars,Values,Eqs)
%	Eqs is the list of equality atoms involving the encoded variables
%	of Vars and the encoded values of Values.
% Eg. equations(["A","B"],[1,2],["A"=1,"B"=2]).
% OK for modes (+,+,-) and (-,-,+).

equations([],[],[]) :- !.
equations([Var|Vars],[Value|Values],[(Var=Value)|Eqs]) :-
	equations(Vars,Values,Eqs).


% equations2(Varss,Valuesss,Eqs)
%	Eqs is the list of member atoms involving the encoded variables
%	of Varss and the encoded values-lists of Valuesss.
%	The functor used in these equality atoms is "in/2".
% Eg. equations2([["A","B"],["C"]],[[[1],[2,3]],[[4,5,6]]],
%			[in(["A","B"],[[1],[2,3]]),in(["C"],[[4,5,6]])]).

equations2([],[],[]) :- !.
equations2([Vars|Varss],[Valuess|Valuesss],[in(Vars,Valuess)|Eqs]) :-
	equations2(Varss,Valuesss,Eqs).


% equationss(Varss,Valuess,Eqs)
%	Eqs is the list of equality atoms involving the encoded variables
%	of Varss and the encoded values of Valuess.
% Eg. equationss([["A","B"],["C","D"]],[[1,2],[3,4]],["A"=1,"B"=2,"C"=3,"D"=4]).

equationss([],[],[]).
equationss([Vars|Varss],[Values|Valuess],Eqs) :-
	equations(Vars,Values,SomeEqs),
	equationss(Varss,Valuess,MoreEqs),
	append(SomeEqs,MoreEqs,Eqs).


% equationsss(Exs,Vars,Eqsss)
%	Eqsss is the list of lists of lists of equality atoms
%	involving the encoded variables of Vars
%	and the encoded values of Exs.
% Eg. equations([p(1,2),p(3,4)],["A","B"],[[["A"=1,"B"=2]],[["A"=3,"B"=4]]]).

equationsss([],_,[]).
equationsss([Ex|Exs],Vars,[[Eqs]|Eqsss]) :-
	Ex=(Head:-true),
	Head=..[_|Values],
	equations(Vars,Values,Eqs),
	equationsss(Exs,Vars,Eqsss).


% extract(Eqs,Vals,Ps)
%	Vals are the values of the equations at positions Ps in Eqs.

extract(Eqs,Vals,Ps) :-
	select(Ps,Eqs,RelevantEqs),
	equations(_,Vals,RelevantEqs).	% possibility of loop-merging


% extractHXTYZY(Positions,Eqss,Vals)
%	Vals is the val(HX,TY,Z,Y) value-quadruple from Eqss.

extractHXTYZY(Positions,[Eqs1,Eqs3,Eqs4],Vals) :-
	Positions=positions(_,PosAuxParams,PosOtherParams,PosIPheads,_),
	extract(Eqs3,HXvals,PosIPheads),
	extract(Eqs1,Zvals,PosAuxParams),
	extract(Eqs1,Yvals,PosOtherParams),
	equations2(_,TYvalsss,Eqs4),
	Vals=val(HXvals,TYvalsss,Zvals,Yvals).


% firstM(M,L,F)
%	F is the list of the first M elements of list L.

firstM(0,_,[]) :- !.
firstM(M,[HL|TL],[HL|TF]) :-
	M>0,
	Mminus1 is M - 1,
	firstM(Mminus1,TL,TF).
	

% inclusion(Xs,Ys)
%	The list of terms Xs is included in the list of terms Ys.

inclusion([],_).
inclusion([X|Xs],Ys) :-
	memberCheck(Ys,X),
	inclusion(Xs,Ys).


% int2Peano(I,P)
%	P is the Peano-integer version of integer I.

int2Peano(0,0).
int2Peano(I,P) :-
	I>0,
	Iminus1 is I - 1,
	int2Peano(Iminus1,PredP),
	P=s(PredP).


% peano2Int(P,I)
%	I is the integer version of Peano-integer P.

peano2Int(0,0).
peano2Int(s(PredP),I) :-
	peano2Int(PredP,Iminus1),
	I is Iminus1 + 1.


% iota(N,L)
%	L is [1,2,...,N].
% OK for modes (+,+) and (+,-).

iota(N,L) :-
	iota(N,L,[]).

iota(N,L,A) :-
	N>0,!,
	Nminus1 is N-1,
	iota(Nminus1,L,[N|A]).
iota(0,L,L).


% listComma(L,C)
%	C is a "comma-ed" version of atom-list L.
% Eg. listComma([a,b,c],(a,b,c)).
% Eg. listComma([d],d).
% Eg. listComma([],true).
% OK for modes (+,?) and (-,+).

listComma([H1,H2|TL],(H1,TC)) :-
	!,listComma([H2|TL],TC).
listComma([],true) :- !.
listComma([H],H).


% member(L,E)
%	List L has E as an element.
%	Succeeds as many times as L has elements.

%member([E|_],E).
%member([_|TL],E) :-
%	member(TL,E).

member([E],E) :- !.
member([E,_|_],E).
member([_,H|T],E) :-
	member([H|T],E).


% members(Ls,Es)
%	Lists Ls have Es as elements.

members([],[]).
members([L|Ls],[E|Es]) :-
	member(L,E),
	members(Ls,Es).


% memberCheck(L,E)
%	List L has E as an element.
%	Succeeds once at most.

memberCheck([HL|_],E) :-
	HL==E,!.
memberCheck([_|TL],E) :-
	memberCheck(TL,E).


% open(SpecNameStr)
%	Open the specification file named SpecNameStr for reading.
%	Prepare reading from keyboard (how?) if SpecNameStr is "user".

open("user") :-
	see(user),!.
open(SpecNameStr) :-
	name(Spec,SpecNameStr),
	on_exception(_,see(specs(Spec)),fail).


% ordDiff(L1,L2,L)
%	L is L1 \ L2, where all parameters are ordered lists of integers.
% N.B. ordDiff(L,[E],R) <==> efface(E,L,R).

ordDiff(L,[],L) :- !.
ordDiff([HL1|TL1],[HL1|TL2],L) :-
	!,ordDiff(TL1,TL2,L).
ordDiff([HL1|TL1],[HL2|TL2],[HL1|TL]) :-
	HL1<HL2,
	ordDiff(TL1,[HL2|TL2],TL).


% plateau(N,T,P)
%	List P is a plateau of N (>0) elements equal to term T.

plateau(1,T,[T]) :- !.
plateau(N,T,[T|P]) :-
	N>1,
	Nminus1 is N - 1,
	plateau(Nminus1,T,P).


% position(E,L,P)
%	Term E first occurs in list L at position P.
% OK for modes (+,+,?) and (-,+,+).

position(E,[E|_],1) :- !.
position(E,[_|TL],P) :-
	var(P),!,
	position(E,TL,Pminus1),
	P is Pminus1 + 1.
position(E,[_|TL],P) :-
	Pminus1 is P - 1,
	position(E,TL,Pminus1).


% positions(E,L,Ps)
%	Element E first occurs in list L at positions Ps.
% Behaves as: setof(P,position(E,L,P),Ps).
% OK for modes (+,+,?) and (-,+,+).
% Not used.

positions(E,L,Ps) :-
	positions(E,L,Ps,1).

positions(_,[],[],_).
positions(E,[E|TL],[P|Ps],P) :-
	Pplus1 is P+1,
	positions(E,TL,Ps,Pplus1).
positions(E,[HL|TL],Ps,P) :-
	E~=HL,
	Pplus1 is P+1,
	positions(E,TL,Ps,Pplus1).


% reverse(L,R)
%	List R is the reverse of list L.

reverse(L,R) :-
	reverse(L,R,[]).

reverse([],R,R).
reverse([HL|TL],R,A) :-
	reverse(TL,R,[HL|A]).


% select(P,L,S)
%	S is the list of elements at ordered positions P in L.
% OK for modes (+,+,?), (+,-,+), and (-,+,+).
% N.B. select([P],L,[S]) <==> position(S,L,P).

select(P,L,S) :-
	select(P,L,S,1).

select([],_,[],_) :- !.
select([HP|TP],[HL|TL],[HL|TS],HP) :-
	!,PosPlus1 is HP + 1,
	select(TP,TL,TS,PosPlus1).
select([HP|TP],[_|TL],LS,Pos) :-
	PosPlus1 is Pos + 1,
	select([HP|TP],TL,LS,PosPlus1).


% setIntersection(As,Bs,Is)
%	Set Is is the intersection of sets As and Bs.
% Not used.

setIntersection([],_,[]).
setIntersection([A|As],Bs,[A|Is]) :-
	memberCheck(Bs,A),!,		% can be optimized by deleting
	setIntersection(As,Bs,Is).	% A from Bs yielding NewBs.
setIntersection([_|As],Bs,Is) :-
	setIntersection(As,Bs,Is).


% shortestLists(Ls,ShoLs)
%	ShoLs contains all the elements of the list of lists Ls
%	whose first elements are of the shortest length among all.
% Hypothesis: none of these lists has more than 9999 elements.

shortestLists(Ls,ShoLs) :-
	shortestLists(Ls,9999,[],ShoLs).

shortestLists([],_,ShoLs,ShoLs).
shortestLists([L|Ls],Min,_,ShoLs) :-
	L=[L1|_],
	length(L1,N1),
	N1<Min,!,
	shortestLists(Ls,N1,[L],ShoLs).
shortestLists([L|Ls],Min,Int,ShoLs) :-
	L=[L1|_],
	length(L1,N1),
	N1=Min,!,
	shortestLists(Ls,Min,[L|Int],ShoLs).
shortestLists([_|Ls],Min,Int,ShoLs) :-
%	L=[L1|_],
%	length(L1,N1),
%	N1>Min,
	shortestLists(Ls,Min,Int,ShoLs).


% twoDiffMembers(Ls,X,Y)
%	X and Y are two different terms of list Ls.
% Not used.

twoDiffMembers([X,Y],X,Y).
twoDiffMembers([A,Y,Z|T],A,B) :-
	member([Y,Z|T],B).
twoDiffMembers([_,Y,Z|T],A,B) :-
	twoDiffMembers([Y,Z|T],A,B).


% uppify(Char,UppChar)
%	UppChar is the uppercase translation of the lowercase character Char.

uppify(Char,UppChar) :-
	UppChar is Char - 32.


