%******************************************************************************
%*				 primitives.pl				      *
%******************************************************************************

:- dynamic '=/='/2.
:- dynamic int/1, list/1.
:- dynamic add/3, mult/3.
:- dynamic odd/1, even/1.
%:- dynamic member/2.
:- dynamic lt/2, gt/2, le/2, ge/2.
:- dynamic partition/4, halves/3.


%%% Constructive inequality (an attempt at sound inequality for inductive types)

'=/='([],[_|_]).
'=/='([_|_],[]).
'=/='([A|_],[B|_]) :-
	A\=B.
'=/='(0,s(_)).
'=/='(s(_),0).
'=/='(s(A),s(B)) :-
	'=/='(A,B).


%%% Type-checking primitives that may be used in the bodies of properties

% int(N)
%	N is a Peano-integer.

int(0).
int(s(_)).			% for pseudo-integers
%int(s(N)) :- int(N).


% list(L)
%	L is a list.

list([]).
list([_|_]).			% for pseudo-lists
%list([_|T]) :- list(T).



%%% Primitives for Peano integers that may be used in the bodies of properties

% add(A,B,S)
%	S is the sum of Peano-integers A and B.
% OK for all directionalities, except (-,-,-).

add(0,B,B).
add(s(A),B,s(S)) :-
	add(A,B,S).


% mult(A,B,P)
%	P is the product of Peano-integers A and B.
% OK for (+,+,-) only. (why?)

mult(0,_,0).
mult(s(A),B,P) :-
	mult(A,B,Int),
	add(Int,B,P).


% odd(P)
%	Peano-integer P is odd.

odd(s(0)).
odd(s(s(P))) :-
	odd(P).


% even(P)
%	Peano-integer P is even.

even(0).
even(s(s(P))) :-
	even(P).



%%% Primitives for lists that may be used in the bodies of properties

% member(L,E)
%	

%member([E|_],E).
%member([_|TL],E) :-
%	member(TL,E).



%%% Primitives for Peano integers that are obtained by parsing of properties

% lt(A,B)
%	Peano-integer A is strictly less (<) than Peano-integer B.

lt(0,s(_)).
lt(s(A),s(B)) :-
	lt(A,B).


% gt(A,B)
%	Peano-integer A is strictly greater (>) than Peano-integer B.

gt(A,B) :- lt(B,A).


% le(A,B)
%	Peano-integer A is less or equal (<=) to Peano-integer B.

le(A,A).
le(A,B) :- lt(A,B).


% ge(A,B)
%	Peano-integer A is greater or equal (>=) to Peano-integer B.

ge(A,B) :- le(B,A).



%%% Decomposition primitives that are recognized by SYNAPSE

% partition(L,H,S,B)
%	S is the elements of integer-list T that are <  than Peano-integer H;
%	B is the elements of integer-list T that are >= than Peano-integer H;

partition([],_,[],[]).
partition([H|T],P,[H|S],B) :-
	lt(H,P),
	partition(T,P,S,B).
partition([H|T],P,S,[H|B]) :-
	ge(H,P),
	partition(T,P,S,B).


% halves(L,F,S)
%	F is the first half of list L; S is the corresponding suffix of L.
%	If L is of uneven length, then the element in the middle goes into S.

halves(L,F,S) :-
	halves(L,L,F,S).

halves(L,[],[],L).
halves(L,[_],[],L).
halves([HL11|TL1],[_,_|TTL2],[HL11|TF],S) :-
	halves(TL1,TTL2,TF,S).



%%% List of known primitives

% primitive(Atom)
%	The most-general atom Atom has a known primitive predicate.

primitive(Atom) :-
	sysPrim(Atom),!.
primitive(Atom) :-
	known(Atom).

sysPrim(_'='_).		% equality (unifiability)
sysPrim(_'\='_).	% unsound inequality:
			% no substitution can be found to make X and Y the same
sysPrim(_'~='_).	% suspicious inequality:
			% X is not identical to Y now, and never will be
sysPrim(length(_,_)).	% length of a list
sysPrim(append(_,_,_)).	% concatenation of two lists

known('=/='(_,_)).
known(int(_)).
known(list(_)).
known(add(_,_,_)).
known(mult(_,_,_)).
known(odd(_)).
known(even(_)).
%known(member(_,_)).
known(lt(_,_)).
known(gt(_,_)).
known(le(_,_)).
known(ge(_,_)).
known(partition(_,_,_,_)).
known(halves(_,_,_)).


%%% List of input directionalities for safe calls of the primitives;
%%% there may be several input directionalities for each primitive;
%%% all unlisted input directionalities lead to DCI/NFI resolution.

safeDir(_'='_,[any,any]).
safeDir(_'\='_,[any,any]).
safeDir(_'~='_,[any,any]).
safeDir(length(_,_),[any,any]).
safeDir(append(_,_,_),[any,any,any]).
safeDir('=/='(_,_),[ground,ground]).
safeDir(int(_),[ground]).
safeDir(list(_),[ground]).
safeDir(add(_,_,_),[ground,ground,any]).
safeDir(mult(_,_,_),[ground,ground,any]).
safeDir(odd(_),[ground]).
safeDir(even(_),[ground]).
%safeDir(member(_,_),[ground,any]).
safeDir(lt(_,_),[ground,ground]).
safeDir(gt(_,_),[ground,ground]).
safeDir(le(_,_),[ground,ground]).
safeDir(ge(_,_),[ground,ground]).
safeDir(partition(_,_,_,_),[ground,ground,any,any]).
safeDir(halves(_,_,_),[ground,any,any]).



%%% List of input directionalities for forbidden selection for
%%% DCI/NFI call/resolution of the known primitives;

noSelect('=/='(_,_),[var,var]).
noSelect(add(_,_,_),[var,var,var]).
noSelect(mult(_,_,_),[var,var,var]).
noSelect(odd(_),[var]).
noSelect(even(_),[var]).
noSelect(lt(_,_),[var,var]).
noSelect(gt(_,_),[var,var]).
noSelect(le(_,_),[var,var]).
noSelect(ge(_,_),[var,var]).
