%******************************************************************************
%*				   meta.pl				      *
%******************************************************************************

% Package for handling terms with encoded meta-variables.
% The chosen ground representation uses the binary functor '$VAR',
% whose first argument is either some atom (if the variable is user-named),
% or some integer in the interval strictly between 0 and the currently
% asserted (by a varCounter/1 fact) value, prefixed by "_" (if the variable
% is system-named), and whose second argument is either "universal" (if it is
% a universally quantified variable), or "existential" (if it is an
% existentially quantified variable), or "dontKnow" (if the actual
% quantification of the variable is unknown or irrelevant).

% A substitution S is represented as a list [V1/t1,V2/t2,...,Vn/tn], where
% n>=0, "/" is an infix binary functor, the Vi are pairwisely different
% object-level variables, the ti are object-level terms, every ti is
% different from its Vi, every Vi/ti is a binding of object-level term ti
% to object-level variable Vi, and S = {Vn/tn} o ... o {V2/t2} o {V1/t1},
% where o/2 denotes composition of functions.  This convention allows the
% same implementation of the act of instantiating a term by a substitution
% as when considering that the substitution {V1/t1,V2/t2,...,Vn/tn} is
% idempotent: the bindings may be applied incrementally!


% initMetaVar
%	To be called prior to any creation of encoded terms.

initMetaVar :-
	abolish(varCounter/1),		% not strictly necessary, but useful.
	assert(varCounter(1)).


% brandNew(Var,Quant)
%	Var is a brand-new meta-variable that is quantified by Quant.

brandNew(Var,Quant) :-
	retract(varCounter(N)),
	name(N,Nchars),
	code('_',Underscore),
	name(Name,[Underscore|Nchars]),
	Var='$VAR'(Name,Quant),
	Nplus1 is N + 1,
	assert(varCounter(Nplus1)).


% metaVar(T)
%	Term T is a meta-variable.

metaVar('$VAR'(_,_)).


% metaGround(T)
%	Term T is a ground meta-term.

metaGround(T) :-
	\+ metaVar(T),
	T=..[_|Args],
	metaGrounds(Args).

metaGrounds([]).
metaGrounds([H|T]) :-
	metaGround(H),
	metaGrounds(T).


% size(T,S)
%       Term T is of size S  (see Definition 12-1).

size(T,S) :-
        metaVar(T),!,
        S=1000.		% this is a reasonable enough approximation of maxint
size(0,0) :- !.
size(s(T),S) :-
        size(T,Sminus1),!,
        S is Sminus1 + 1.
size([],0) :- !.
size([_|T],S) :-
        size(T,Sminus1),!,
        S is Sminus1 + 1.
size(_,undefined).


% groundStr(V,S)
%	S is the string corresponding to the atom of the ground representation
%	of the meta-variable V.

groundStr(V,S) :-
	var(V),!,
	name(Name,S),
	V='$VAR'(Name,dontKnow).
groundStr(V,S) :-
	V='$VAR'(Name,_),
	name(Name,S).


varList2Str(Vars,String) :-
	varList2Str_bis(Vars,TailString),
	code('[',OpenSqBracket),
	String=[OpenSqBracket|TailString].

varList2Str_bis([],"]").
varList2Str_bis([Var],Str) :-
	!,groundStr(Var,VarStr),
	append(VarStr,"]",Str).
varList2Str_bis([Var1,Var2|Vars],String) :-
	groundStr(Var1,Var1Str),
	varList2Str_bis([Var2|Vars],Str),
	code(',',Comma),
	append(Var1Str,[Comma|Str],String).


% ground2var(T1,T2,Vars)
%	T1 is a ground representation of a term, and
%	T2 is the non-ground representation thereof, and
%	Vars is the set of variables in T2,
%	as they first appear in T2 from left to right.

ground2var(T1,T2,Vars) :-
	ground2vars([T1],[T2],[],Vars,[],_).

ground2vars([],[],Vars,Vars,Inj,Inj).
ground2vars([T1|Ts1],[T2|Ts2],Vars,NewVars,Inj,NewInj) :-
	T1='$VAR'('_',_),!,		% anonymous meta-variables are converted
	brandNew('$VAR'(Name,_),_),	%    into different variables
	injection1(Name,T2,Vars,IntVars,Inj,IntInj),
	ground2vars(Ts1,Ts2,IntVars,NewVars,IntInj,NewInj).
ground2vars([T1|Ts1],[T2|Ts2],Vars,NewVars,Inj,NewInj) :-
	T1='$VAR'(Name,_),!,
	injection1(Name,T2,Vars,IntVars,Inj,IntInj),
	ground2vars(Ts1,Ts2,IntVars,NewVars,IntInj,NewInj).
ground2vars([T1|Ts1],[T2|Ts2],Vars,NewVars,Inj,NewInj) :-
	T1=..[F|As1],
	ground2vars(As1,As2,Vars,IntVars,Inj,IntInj),
	T2=..[F|As2],
	ground2vars(Ts1,Ts2,IntVars,NewVars,IntInj,NewInj).

injection1(Name,Var,[],[Var],[],[inj(Name,Var)]) :- !.
injection1(Name,Var,[Var|Vars],[Var|Vars],
		[inj(Name,Var)|Inj],[inj(Name,Var)|Inj]) :- !.
injection1(Name,Var,[Var1|Vars],[Var1|NewVars],
		[inj(Name1,Var1)|Inj],[inj(Name1,Var1)|NewInj]) :-
	injection1(Name,Var,Vars,NewVars,Inj,NewInj).


% var2ground(T1,T2)
%	T1 is a non-ground representation of a term, and
%	T2 is a ground representation thereof.

var2ground(T1,T2) :-
	var2ground(T1,T2,[],_).

var2ground(T1,T2,L,NewL) :-
	var(T1),!,
	injection2(T2,T1,L,NewL).
var2ground(T1,T2,L,NewL) :-
	T1=..[F|Ts1],
	var2grounds(Ts1,Ts2,L,NewL),
	T2=..[F|Ts2].

var2grounds([],[],L,L).
var2grounds([T1|Ts1],[T2|Ts2],L,NewL) :-
	var2ground(T1,T2,L,IntL),
	var2grounds(Ts1,Ts2,IntL,NewL).

injection2(NGvar,Var,[],[inj(NGvar,Var)]) :-
	!,brandNew(NGvar,dontKnow).
injection2(NGvar,Var,[inj(NGvar,Var1)|Injs],[inj(NGvar,Var1)|Injs]) :-
	Var==Var1,!.
injection2(NGvar,Var,[inj(NGvar1,Var1)|Injs],[inj(NGvar1,Var1)|NewInjs]) :-
	injection2(NGvar,Var,Injs,NewInjs).


% copyTerm(T1,T2)
%	T2 is a brand-new copy of encoded term T1;
%	anonymous meta-variables are replaced by different new meta-variables.

copyTerm(T1,T2) :-
	copyTerms([T1],[T2],[],_).

copyTerms([],[],Inj,Inj).
copyTerms([T1|Ts1],[T2|Ts2],Inj,NewInj) :-
	T1='$VAR'('_',Quant),!,
	brandNew(T2,Quant),
	copyTerms(Ts1,Ts2,Inj,NewInj).
copyTerms([T1|Ts1],[T2|Ts2],Inj,NewInj) :-
	T1='$VAR'(Name,Quant),!,
	injection3(Name,Quant,T2,Inj,IntInj),
	copyTerms(Ts1,Ts2,IntInj,NewInj).
copyTerms([T1|Ts1],[T2|Ts2],Inj,NewInj) :-
	T1=..[F|As1],
	copyTerms(As1,As2,Inj,IntInj),
	T2=..[F|As2],
	copyTerms(Ts1,Ts2,IntInj,NewInj).

injection3(Name,Quant,Var,[],[inj(Name,Var)]) :-
	!,brandNew(Var,Quant).
injection3(Name,_,Var,[inj(Name,Var)|Inj],[inj(Name,Var)|Inj]) :- !.
injection3(Name,Quant,Var,[inj(Name1,Var1)|Inj],[inj(Name1,Var1)|NewInj]) :-
	injection3(Name,Quant,Var,Inj,NewInj).


% unify(T1,T2,GCI,MGU)
%	GCI is the greatest-common-instance of encoded terms T1 and T2,
%	and MGU is the corresponding most-general-unifier.
% NB. No occurs-check.
% Not used.

unify(T1,T2,GCI,MGU) :-
	metaVar(T1),!,			% T1 is a variable
	GCI=T2,
	MGU=[T1/T2].
unify(T1,T2,GCI,MGU) :-
%	\+ metaVar(T1),			% T1 is not a variable,
	metaVar(T2),!,			% but T2 is a variable
	GCI=T1,
	MGU=[T2/T1].
unify(T1,T2,GCI,MGU) :-
%	\+ metaVar(T1),
%	\+ metaVar(T2),			% T1 and T2 are not variables
	T1=..[F|Ts1],
	T2=..[F|Ts2],			% but T1 and T2 have the same functor
	unifys(Ts1,Ts2,GCIs,MGU),
	GCI=..[F|GCIs].

unifys([],[],[],[]).
unifys([T1|Ts1],[T2|Ts2],[GCI|GCIs],MGU) :-
	unify(T1,T2,OldGCI,SomeMGU),
	substitution(Ts1,SomeMGU,NewTs1),
	substitution(Ts2,SomeMGU,NewTs2),
	unifys(NewTs1,NewTs2,GCIs,MoreMGU),
	substitution(OldGCI,MoreMGU,GCI),
	substitution(SomeMGU,MoreMGU,NewSomeMGU),	% for idempotent mgu
%	NewSomeMGU=SomeMGU,			    % for non-idempotent mgu
	append(NewSomeMGU,MoreMGU,MGU).


% decUnify(T1,T2,GCI,MGU)
%	GCI is the greatest-common-decided-instance of encoded terms T1 and T2,
%	and MGU is the corresponding most-general-deciding-unifier-for-T1.
% NB. No occurs-check.

decUnify(T1,T2,GCI,MGU) :-
	T1='$VAR'(_,Quant),
	Quant~=universal,!,		% T1 is a non-universal variable
	GCI=T2,
	MGU=[T1/T2].
decUnify(T1,T2,GCI,MGU) :-
	T2='$VAR'(_,Quant),
	Quant~=universal,!,		% T2 is a non-universal variable
	GCI=T1,
	MGU=[T2/T1].
decUnify(T1,T2,GCI,MGU) :-
	T1='$VAR'(Name,universal),
	T2='$VAR'(Name,universal),!,	% T1 and T2 are the same univ. variable
	GCI=T1,
	MGU=[].
decUnify(T1,T2,GCI,MGU) :-
	T1=..[F|Ts1],			% T1 and T2 are not variables
	T2=..[F|Ts2],			% but T1 and T2 have the same functor
	F~='$VAR',
	decUnifys(Ts1,Ts2,GCIs,MGU),
	GCI=..[F|GCIs].

decUnifys([],[],[],[]).
decUnifys([T1|Ts1],[T2|Ts2],[GCI|GCIs],MGU) :-
	decUnify(T1,T2,OldGCI,SomeMGU),
	substitution(Ts1,SomeMGU,NewTs1),
	substitution(Ts2,SomeMGU,NewTs2),
	decUnifys(NewTs1,NewTs2,GCIs,MoreMGU),
	substitution(OldGCI,MoreMGU,GCI),
	substitution(SomeMGU,MoreMGU,NewSomeMGU),	% for idempotent mgu
%	NewSomeMGU=SomeMGU,			    % for non-idempotent mgu
	append(NewSomeMGU,MoreMGU,MGU).


% msg(T1,T2,MSG)
%	MSG is the most-specific-generalization of encoded terms T1 and T2.

msg(T1,T2,MSG) :-
	msg(T1,T2,MSG,[],_).

msg(T1,T2,MSG,Inj,NewInj) :-
	comparable(T1,T2),!,
	T1=..[F|As1],
	T2=..[F|As2],
	msgs(As1,As2,MSGs,Inj,NewInj),
	MSG=..[F|MSGs].
msg(T1,T2,MSG,Inj,NewInj) :-
	injection(Inj,T1,T2,MSG,NewInj).

msgs([],[],[],Inj,Inj).
msgs([A|As],[B|Bs],[M|Ms],Inj,NewInj) :-
	msg(A,B,M,Inj,IntInj),
	msgs(As,Bs,Ms,IntInj,NewInj).

comparable(T1,T2) :-
	functor(T1,F,N),
	functor(T2,F,N),
	(F,N)~=('$VAR',2).

injection([],T1,T2,V,[inj(T1,T2,V)]) :-
	brandNew(V,dontKnow).
injection([inj(T1,T2,V)|Inj],T1,T2,V,[inj(T1,T2,V)|Inj]) :- !.
injection([inj(T3,T4,W)|Inj],T1,T2,V,[inj(T3,T4,W)|NewInj]) :-
%	(T1,T2)~=(T3,T4),
	injection(Inj,T1,T2,V,NewInj).


% substitution(T1,Subst,T2)
%	T2 is T1 Subst, where Subst is a substitution.

substitution(T1,[],T1) :- !.
substitution(T1,[V/T|Subst],T2) :-
	binding(T1,V,T,IntT),
	substitution(IntT,Subst,T2).


% binding(T1,V,T,T2)
%	T2 is T1{V/T}.

binding(V,V,T,T) :- !.			% T1 = V
binding(T1,V,T,T2) :-			% T1 ~= V, but T1 is not a variable
	T1~=V,
	T1=..[F|Ts1],
	F~='$VAR',!,
	bindings(Ts1,V,T,Ts2),
	T2=..[F|Ts2].
binding(T,_,_,T).			% T1 ~= V, and T1 is a variable 

bindings([],_,_,[]).
bindings([T1|Ts1],V,T,[T2|Ts2]) :-
	binding(T1,V,T,T2),
	bindings(Ts1,V,T,Ts2).


% bindings2(T1,Vs,Ts,T2)
%	T2 is T1{Vs/Ts}.
% NB. Only to be used when no element of Ts contains an element of Vs,
%	because the bindings are done sequentially rather than in parallel.
%	In other words, the substitution behind Vs and Ts must be idempotent.

bindings2(T1,[],[],T1) :- !.
bindings2(T1,[V|Vs],[T|Ts],T2) :-
	binding(T1,V,T,IntT),
	bindings2(IntT,Vs,Ts,T2).


% replace(T1,S,T,T2)
%	T2 is T1 where all occurrences of term S have been replaced by term T.
% NB. The code is exactly the same as the code of binding/4.

replace(S,S,T,T) :- !.			% T1 = S
replace(T1,S,T,T2) :-			% T1 ~= S, but T1 is not a variable
	T1~=S,
	T1=..[F|Ts1],
	F~='$VAR',!,
	replaces(Ts1,S,T,Ts2),
	T2=..[F|Ts2].
replace(T,_,_,T).			% T1 ~= S, and T1 is a variable 

replaces([],_,_,[]).
replaces([T1|Ts1],S,T,[T2|Ts2]) :-
	replace(T1,S,T,T2),
	replaces(Ts1,S,T,Ts2).


% compoSubst(S1,S2,S)
%	S is the composition of substitutions S1 and S2.
%	See [Lloyd 87], page 21.

compoSubst(S1,S2,S) :-
	applyRHS(S1,S2,PreS),
	makeSubst(Vars1,_,S1),
	trimSubst(S2,Vars1,SufS),
	append(PreS,SufS,S).

applyRHS([],_,[]).
applyRHS([Var/Val|S1],S2,[Var/NewVal|S]) :-
	substitution(Val,S2,NewVal),
	NewVal~=Var,!,
	applyRHS(S1,S2,S).
applyRHS([_|S1],S2,S) :-
	applyRHS(S1,S2,S).


% compoSubsts(L,S,R)
%	R is the list of the compositions of the elements of
%	substitution-list L to substitution S.

compoSubsts([],_,[]).
compoSubsts([HL|TL],S,[HR|TR]) :-
	compoSubst(S,HL,HR),
	compoSubsts(TL,S,TR).


% makeSubst(Vars,Vals,Subst)
%	Subst is the list of equality atoms involving the encoded variables
%	of Vars and the encoded values of Vals.
% Eg. makeSubst(["A","B"],[1,2],["A"/1,"B"/2]).
% OK for modes (+,+,-) and (-,-,+).

makeSubst([],[],[]) :- !.
makeSubst([Var|Vars],[Val|Vals],[(Var/Val)|Subst]) :-
	makeSubst(Vars,Vals,Subst).


% simSubst(Subst,NewSubst)
%	Subst is a substitution;
%	NewSubst is Subst where
%		"X"/"Y" bindings (with "X" univ/exist quantified
%			and "Y" dontKnow quantified) have been deleted;
%		"X"/"Y" bindings (with "X" universally quantified
%			and "Y" existentially quantified) have been reversed;
%		and where "Y"/"X" has been applied to the rest of Subst.
% NB. All LHS of Subst are assumed to be universally/existentially quantified.

simSubst(Subst,NewSubst) :-
	simSubst([],Subst,SimSub),
	reverse(SimSub,NewSubst).

simSubst(NewSubst,[],NewSubst) :- !.
simSubst(Pre,[Var/Val|Suf],NewSubst) :-
	metaVar(Var),			% Var is a  univ/exist  variable
	Val='$VAR'(_,dontKnow),!,	% Val is a  dontKnow    variable
	binding(Pre,Val,Var,NewPre),
	binding(Suf,Val,Var,NewSuf),	
	simSubst(NewPre,NewSuf,NewSubst).
simSubst(Pre,[Var/Val|Suf],NewSubst) :-
	Var='$VAR'(_,universal),	% Var is a  universal   variable
	Val='$VAR'(_,existential),!,	% Val is an existential variable
	binding(Pre,Val,Var,NewPre),
	binding(Suf,Val,Var,NewSuf),	
	simSubst([Val/Var|NewPre],NewSuf,NewSubst).
simSubst(Pre,[Var/Val|Suf],NewSubst) :-
	simSubst([Var/Val|Pre],Suf,NewSubst).


% pruneSubst(Subst,Vars,NewSubst)
%	NewSubst is Subst where all bindings that do not bind a variable
%	from Vars have been deleted.

pruneSubst([],_,[]).
pruneSubst([Var/Val|Subst],Vars,[Var/Val|NewSubst]) :-
	memberCheck(Vars,Var),!,
	pruneSubst(Subst,Vars,NewSubst).
pruneSubst([_|Subst],Vars,NewSubst) :-
	pruneSubst(Subst,Vars,NewSubst).


% trimSubst(Subst,Vars,NewSubst)
%	NewSubst is Subst where all bindings that bind a variable
%	from Vars have been deleted.

trimSubst([],_,[]).
trimSubst([Var/_|Subst],Vars,NewSubst) :-
	memberCheck(Vars,Var),!,
	trimSubst(Subst,Vars,NewSubst).
trimSubst([Binding|Subst],Vars,[Binding|NewSubst]) :-
	trimSubst(Subst,Vars,NewSubst).


% deciding(Subst)
%	The substitution Subst is a deciding substitution (i.e. it only
%	binds existential variables).

deciding([]).
deciding([('$VAR'(_,existential)/_)|Subst]) :-
	deciding(Subst).


% subTerm(S,T)
%	Encoded term S is a sub-term of encoded term T.

subTerm(T,T) :- !.
subTerm(S,T) :-
	T=..[F|Ts],
	F~='$VAR',
	subTerms(S,Ts).

subTerms(S,[T|_]) :-
	subTerm(S,T),!.
subTerms(S,[_|Ts]) :-
	subTerms(S,Ts).


% metaVarList(T,Vars).
%	Vars is the list of variables in encoded term T (repetitions included),
%	as they appear in T from left to right.
% Not used.

metaVarList(T,Vars) :-
	metaVarList(T,Vars,[]).

metaVarList(T,[T|Vars],Vars) :-
	metaVar(T),!.
metaVarList(T,Vars,Acc) :-
	T=..[_|Ts],
	metaVarLists(Ts,Vars,Acc).

metaVarLists([],Vars,Vars).
metaVarLists([T|Ts],Vars,Acc) :-
	metaVarLists(Ts,Acc1,Acc),
	metaVarList(T,Vars,Acc1).


% metaVarSet(T,Vars).
%	Vars is the set of meta-variables in encoded term T,
%	as they first appear in T from left to right.
% NB. Anonymous meta-vars are INCORRECTLY considered equal.

metaVarSet(T,Vars) :-
	metaVarSet(T,RVars,[]),
	reverse(RVars,Vars).

metaVarSet(T,Vars,Acc) :-
	metaVar(T),
	memberCheck(Acc,T),!,
	Vars=Acc.
metaVarSet(T,Vars,Acc) :-
	metaVar(T),!,
	Vars=[T|Acc].
metaVarSet(T,Vars,Acc) :-
	T=..[_|Ts],
	metaVarSets(Ts,Vars,Acc).

metaVarSets([],Vars,Vars).
metaVarSets([T|Ts],Vars,Acc) :-
	metaVarSet(T,TVars,Acc),
	metaVarSets(Ts,Vars,TVars).


% consSet(T,Cons).
%	Cons is the set of constants in encoded term T,
%	as they first appear in T from left to right.
% Not used.

consSet(T,Cons) :-
	consSet(T,RCons,[]),
	reverse(RCons,Cons).

consSet(T,Cons,Acc) :-
	atomic(T),
	memberCheck(Acc,T),!,
	Cons=Acc.
consSet(T,Cons,Acc) :-
	atomic(T),!,
	Cons=[T|Acc].
consSet(T,Cons,Acc) :-
	metaVar(T),!,
	Cons=Acc.
consSet(T,Cons,Acc) :-
	T=..[_|Ts],
	consSets(Ts,Cons,Acc).

consSets([],Cons,Cons).
consSets([T|Ts],Cons,Acc) :-
	consSet(T,TCons,Acc),
	consSets(Ts,Cons,TCons).


% functorSet(T,Cons,Functors).
%	Cons is the set of constants (arity=0)in encoded term T,
%	Functors is the set of functor/arity (arity>0) in encoded term T,
%	as they first appear in T from left to right.

functorSet(T,Cons,Functors) :-
	functorSet(T,RCons,[],RFunctors,[]),
	reverse(RCons,Cons),
	reverse(RFunctors,Functors).

functorSet(T,Cons,ConsAcc,Functors,FunctorsAcc) :-
	atomic(T),
	memberCheck(ConsAcc,T),!,
	Cons=ConsAcc,
	Functors=FunctorsAcc.
functorSet(T,Cons,ConsAcc,Functors,FunctorsAcc) :-
	atomic(T),!,
	Cons=[T|ConsAcc],
	Functors=FunctorsAcc.
functorSet(T,Cons,ConsAcc,Functors,FunctorsAcc) :-
	metaVar(T),!,
	Cons=ConsAcc,
	Functors=FunctorsAcc.
functorSet(T,Cons,ConsAcc,Functors,FunctorsAcc) :-
	T=..[Functor|Ts],
	functor(T,Functor,Arity),
	memberCheck(FunctorsAcc,Functor/Arity),!,
	functorSets(Ts,Cons,ConsAcc,Functors,FunctorsAcc).
functorSet(T,Cons,ConsAcc,Functors,FunctorsAcc) :-
	T=..[Functor|Ts],
	functor(T,Functor,Arity),
	functorSets(Ts,Cons,ConsAcc,Functors,[Functor/Arity|FunctorsAcc]).

functorSets([],Cons,Cons,Functors,Functors).
functorSets([T|Ts],Cons,ConsAcc,Functors,FunctorsAcc) :-
	functorSet(T,TCons,ConsAcc,TFunctors,FunctorsAcc),
	functorSets(Ts,Cons,TCons,Functors,TFunctors).


% compatible(A,B,M)
%	Encoded atom A is compatible with encoded atom B, and M is msg(A,B).
% Tailored for SYNAPSE: divide-and-conquer atoms only.

compatible(A,B,M) :-
	msg(A,B,M),
	admissible(M).


% admissible(A)
%	Encoded atom A is admissible.
% Tailored for SYNAPSE: divide-and-conquer atoms only.

admissible(val(_,[],_,_)) :- !.
admissible(val(_,[TYs|TYss],Zs,Ys)) :-
	admissibles(val(_,TYs,Zs,Ys)),
	admissible(val(_,TYss,Zs,Ys)).
	
admissibles(val(_,[],_,[])) :- !.
admissibles(val(_,[TY|TYs],Zs,[Y|Ys])) :-
	leaves(TY,InLeaves),
	leaves(zy(Zs,Y),OutLeaves),
	inclusion(InLeaves,OutLeaves),
	admissibles(val(_,TYs,Zs,Ys)).


% leaves(T,Ls)
%	Ls is the list of leaves (constituents) of encoded term T
%	(repetitions included), as they appear in T from left to right.
% NB. Computing the *set* of leaves would be nicer... (but less efficient).

leaves(T,Ls) :-
	leaves(T,Ls,[]).

leaves(T,[T|Ls],Ls) :-
	metaVar(T),!.
leaves(T,[T|Ls],Ls) :-
	atomic(T),!.
leaves(T,Ls,Acc) :-
	T=..[_|Ts],
	leaves1(Ts,Ls,Acc).

leaves1([],Ls,Ls).
leaves1([T|Ts],Ls,Acc) :-
        leaves1(Ts,Acc1,Acc),
        leaves(T,Ls,Acc1).


% admAlt(GenEx,AdmAlt)
%	GenEx is a general example, and
%	AdmAlt is an admissible alternative of GenEx.
% NB. Tailored for SYNAPSE: divide-and-conquer general examples only.
% NB. Assumption: general examples are given in shorthand notation,
%			and are assumed to be single atoms.

admAlt(val(HXs,TYsss,Zs,Ys),AdmAlt) :-
	members(TYsss,TYss),
	admInst(val(HXs,TYss,Zs,Ys),AdmAlt).


% admInst(Atom,AdmInst)
%	Atom is an atom, and AdmInst is an admissible instance of Atom.
% NB. Tailored for SYNAPSE: divide-and-conquer atoms only;
%			    moreover, at most the TYss field has variables,
%			    and it *must* therefore be grounded.

admInst(Atom,AdmInst) :-
	Atom=val(_,TYss,Zs,Ys),
	metaVarSet(TYss,TYssVars),
	append(Zs,Ys,ZsYs),
	functorSets(ZsYs,ZsYsCons,[],ZsYsFunctors,[]),
	groundify(TYssVars,Atom,ZsYsCons,ZsYsFunctors,AdmInst),
	admissible(AdmInst).


% groundify(Vars,T,Cons,Functors,NewT)
%	Apply a grounding substitution \sigma to term T, yielding NewT,
%	such that the domain of \sigma is the set Vars, and
%	such that the range  of \sigma uses at most
%		the constants of the set Cons and
%		the functors of the set Functors.

groundify([],T,_,_,T).
%groundify([Var|Vars],T,Cons,_,NewT) :-			% minimal hypothesis
%	member(Cons,Val),
%	binding(T,Var,Val,IntT),
%	groundify(Vars,IntT,Cons,_,NewT).
groundify([Var|Vars],T,Cons,Functors,NewT) :-		% interactive version
	write('What are possible values of '),print([Var|Vars]),nl,
	write('using the constants '),write(Cons),
	write(' and the functors '),write(Functors),nl,
	write('such that '),print(T),write(' is admissible? : '),
	readLine(Line),
	handleDef(Line,"",ValsStr),
	myPhrase(list(Vals),ValsStr),
	bindings2(T,[Var|Vars],Vals,NewT).
%groundify([Var|Vars],T,Cons,Functors,NewT) :-		% full version
% NB. build a term refinement generator, based on type knowledge (?)
%		and on a given Herbrand universe.


% simplify(Eqs,SimEqs)
%	Eqs is a conjunction of equations, and SimEqs is Eqs where:
%	 - all equations of the form "X"="Y" have been deleted
%		after application of the forward substitution {"Y"/"X"},
%		provided "Y" is system-defined;
%	 - every equation "X"="t" triggers the forward "substitution" {"t"/"X"},
%		provided "t" is not a system-defined variable.
%	The RHS terms of each equation are known to involve only
%	existential variables.

simplify([],[]).
simplify([Var=Val|Eqs],SimEqs) :-
	groundStr(Val,Name),		% Val *is* a variable
	code('_',Underscore),
	Name=[Underscore|_],!,		% Val is a *system-defined* variable
	binding(Eqs,Val,Var,NewEqs),
	simplify(NewEqs,SimEqs).
simplify([Var=Val|Eqs],[Var=Val|SimEqs]) :-	% Val is not a system-variable
	replaces(Eqs,Val,Var,NewEqs),
	simplify(NewEqs,SimEqs).


% algo2Clauses(LA,Clauses)
%	Clauses are definite clauses for the logic algorithm LA.

algo2Clauses(LA,Clauses) :-
	LA=iff(Head,or(MinCase,NRecCase,RecCase,_)),
	case2Clauses(MinCase,Head,MinClauses),
	case2Clauses(NRecCase,Head,NRecClauses),
	case2Clauses(RecCase,Head,RecClauses),
	append(NRecClauses,RecClauses,NMinClauses),
	append(MinClauses,NMinClauses,Clauses).

case2Clauses(undefined,_,[]) :- !.		% undefined case
case2Clauses(Case,Head,Clauses) :-		% case w/o sub-cases
	Case=..[and|Instances],!,
	instances2Body(Instances,Atoms),
	listComma(Atoms,Body),		% (+,-)
	Clauses=[(Head:-Body)].
case2Clauses(Cases,Head,Clauses) :-		% case w/  sub-cases
	cases2Clauses(Cases,Head,Clauses).

cases2Clauses([],_,[]).
cases2Clauses([Case|Cases],Head,[Clause|Clauses]) :-
	case2Clauses(Case,Head,[Clause]),
	cases2Clauses(Cases,Head,Clauses).

instance2Body(undefined,[]).
instance2Body([true],[]) :- !.
instance2Body([Atom|Atoms],[Atom|Atoms]).

instances2Body([_],[]) :- !.		% the final Eqsss are not translated
instances2Body([I1,I2|Is],Atoms) :-	% all other instances are translated
	instance2Body(I1,SomeAtoms),
	instances2Body([I2|Is],MoreAtoms),
	append(SomeAtoms,MoreAtoms,Atoms).


% clause2Goal(Clause,Goal)
%	Goal is the implicative goal for the definite clause Clause.

clause2Goal(Clause,Goal) :-
	Clause=(Head:-Body),
	Conclusion=[Head],
	listComma(Hypothesis,Body),		% (-,+)
	quantify(if(Conclusion,Hypothesis),Goal,universal).

clauses2Goals([],[]).
clauses2Goals([Clause|Clauses],[Goal|Goals]) :-
	clause2Goal(Clause,Goal),
	clauses2Goals(Clauses,Goals).


% quantify(T1,T2,Quant)
%	T2 is encoded term T1, where all meta-variables that have a "dontKnow"
%	quantifier are re-declared as being quantified as indicated by Quant,
%	where Quant is either "existential" or "universal".

quantify(T1,T2,Quant) :-
	quantifys([T1],[T2],Quant).

quantifys([],[],_).
quantifys([T1|Ts1],[T2|Ts2],Quant) :-
	T1='$VAR'(Name,dontKnow),!,
	T2='$VAR'(Name,Quant),
	quantifys(Ts1,Ts2,Quant).
quantifys([T1|Ts1],[T2|Ts2],Quant) :-
	T1=..[F|As1],
	quantifys(As1,As2,Quant),
	T2=..[F|As2],
	quantifys(Ts1,Ts2,Quant).
