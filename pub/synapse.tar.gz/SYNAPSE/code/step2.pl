%******************************************************************************
%*				 step2.pl				      *
%******************************************************************************

% step2(Variables,LA1,LA2,Positions,DefaultDecs)
%	Synthesis of LA2 from LA1;
%	Variables is the compound term of variables, where
%	the following components are initialized here:
%		IP is the induction parameter of Params;
%		AuxParams are the auxiliary parameters of Params;
%		OtherParams are the other parameters of Params;
%	and the following component is used here:
%		Params are all the parameters;
%	Positions is the compound term of parameter positions, where
%	the following components are initialized here:
%		PosIP is the position of IP within Params;
%		PosAuxParams are the positions of AuxParams within Params;
%		PosOtherParams are the positions of OtherParams within Params;
%	DefaultDecs are the default Decomposition operators for Step 3.
% Fully manual version --> automatizable.
% NB. No test whether both forms really are complementary,
%	nor whether they each cover at least one example,
%	nor whether they actually involve the IP.

step2(Variables,LA1,LA2,Positions,DefaultDecs) :-
	Variables=variables(Params,_,_,_,_,_,_,_),
	LA1=iff(Head,or(undefined,undefined,undefined,Eqsss)),
	guessDefAux(Eqsss,DefAuxParamStr),
	selectAux(Params,DefAuxParamStr,AuxParams,PosAuxParams),
	deleteAlls(AuxParams,Params,NonAuxParams),
	selectIP(Params,NonAuxParams,IP,PosIP),
	otherParams(PosIP,PosAuxParams,Params,OtherParams,PosOtherParams),
	guessDefaults(Eqsss,PosIP,DefaultMin,DefaultNMin,DefaultDecs),
	selectForm('Minimal',DefaultMin,Minimal),
	selectForm('NonMinimal',DefaultNMin,NMinimal),
	formPartition(Eqsss,PosIP,Minimal,MinEqsss,NRecEqsss),
	MinCase=and(Minimal,undefined,MinEqsss),
	NRecCase=and(NMinimal,undefined,undefined,undefined,NRecEqsss),
	LA2=iff(Head,or(MinCase,NRecCase,undefined,[])),
	Variables=variables(_,IP,AuxParams,OtherParams,_,_,_,_),
	Positions=positions(PosIP,PosAuxParams,PosOtherParams,_,_).


% guessDefAux(Eqsss,DefAuxParamStr)
%	Guess the default auxiliary parameters DefAuxParamStr via
%	type inference from the first equations of Eqsss.

guessDefAux(Eqsss,DefAuxParamStr) :-
	Eqsss=[[Eqs]|_],
	equations(Params,Values,Eqs), % (-,-,+)
	guess(Params,Values,DefAuxParams),
	varList2Str(DefAuxParams,DefAuxParamStr).

guess([],[],[]).
guess([Param|Params],[Value|Values],[Param|DefAuxParams]) :-
	type(Value,nonInductive),!,
	guess(Params,Values,DefAuxParams).
guess([_|Params],[_|Values],DefAuxParams) :-
	guess(Params,Values,DefAuxParams).

type(T,Type) :-
	int(T),!,
	Type=int.
type(T,Type) :-
	list(T),!,
	Type=list.
type(_,nonInductive).


% selectAux(Params,DefAuxParamStr,AuxParams,PosAuxParams)
%	Select the names AuxParams and positions PosAuxParams
%	of the auxiliary parameters among Params,
%	using DefAuxParamStr as default list.
% NB. The names must be given in the order of the procedure declaration.

selectAux(Params,DefAuxParamStr,AuxParams,PosAuxParams) :-
	ask('List of auxiliary parameters',DefAuxParamStr,AuxStr),
	myPhrase(list(AuxParams),AuxStr),
	select(PosAuxParams,Params,AuxParams),!.


% selectIP(Params,NonAuxParams,IP,PosIP)
%	Select an induction parameter and return its name IP and
%	its position PosIP within Params; a default IP is
%	non-deterministically selected from NonAuxParams.

selectIP(Params,NonAuxParams,IP,PosIP) :-
	findall(DefIPstr,				% determine default IPs
		  ( member(NonAuxParams,DefIP),
		    groundStr(DefIP,DefIPstr)	),
		DefIPstrs),
	asks('Induction parameter',DefIPstrs,IPstr),	% ask for IP
	myPhrase(variable(IP),IPstr),
	position(IP,Params,PosIP).


% otherParams(PosIP,PosAuxParams,Params,OtherParams,PosOtherParams)
%	Determine the names and positions of the other parameters.

otherParams(PosIP,PosAuxParams,Params,OtherParams,PosOtherParams) :-
	length(Params,Arity),
	iota(Arity,AllPos),
	efface(PosIP,AllPos,PosNIPs),
	ordDiff(PosNIPs,PosAuxParams,PosOtherParams),
	select(PosOtherParams,Params,OtherParams).


% selectForm(Question,Default,Form)
%	Select Form for the IP upon asking Question with Default;
% Form is assumed to be deterministic, given a ground value of the IP.
% Fully manual version --> automatizable with type heuristics, etc.

selectForm(Question,Default,Form) :-
	ask(Question,Default,FormStr),
	myPhrase(conj(Form),FormStr),!.


% formPartition(Eqsss,Pos,Form,Eqsss1,Eqsss2)
%	Eqsss1 (Eqsss2) is the elements of Eqsss whose Pos-th argument 
%	"satisfies" ("does not satisfy") Form.

formPartition([],_,_,[],[]).
formPartition([[Eqs]|Eqsss],Pos,Form,[[Eqs]|Eqsss1],Eqsss2) :-
	position((IP=ValueIP),Eqs,Pos),	% (-,+,+)
	binding(Form,IP,ValueIP,InstForm),
	ground2var(InstForm,NGInstForm,_),
	listComma(NGInstForm,Conj),	% conjunctions are repr. as lists
	call(Conj),!,
	formPartition(Eqsss,Pos,Form,Eqsss1,Eqsss2).
formPartition([[Eqs]|Eqsss],Pos,Form,Eqsss1,[[Eqs]|Eqsss2]) :-
	formPartition(Eqsss,Pos,Form,Eqsss1,Eqsss2).


% guessDefaults(Eqsss,PosIP,DefaultMin,DefaultNMin,DefaultDecs)
%	Guess the default minimal form DefaultMin,
%	and the default non-minimal form DefaultNMin,
%	and the default decomposition operators DefaultDecs,
%	using Eqsss and PosIP.

guessDefaults(Eqsss,PosIP,DefaultMin,DefaultNMin,DefaultDecs) :-
	Eqsss=[[Eqs]|_],			% find value of IP in 1st ex.
	position((IP=ValueIP),Eqs,PosIP),
	groundStr(IP,IPstr),
	guessDefaults2(ValueIP,IPstr,DefaultMin,DefaultNMin,DefaultDecs).

guessDefaults2([],IPstr,DefaultMin,DefaultNMin,DefaultDecs) :-		% list
	append(IPstr,"=[]",DefaultMin),
	append(IPstr,"=[_|_]",DefaultNMin),
	findall(DefaultDec,listDefaultDec(IPstr,DefaultDec),DefaultDecs).
guessDefaults2([_|_],IPstr,DefaultMin,DefaultNMin,DefaultDecs) :-	% list
	append(IPstr,"=[_]",DefaultMin),
	append(IPstr,"=[_,_|_]",DefaultNMin),
	findall(DefaultDec,listDefaultDec(IPstr,DefaultDec),DefaultDecs).
guessDefaults2(0,IPstr,DefaultMin,DefaultNMin,DefaultDecs) :-	% Peano integer
	append(IPstr,"=0",DefaultMin),
	append(IPstr,"=s(_)",DefaultNMin),
	findall(DefaultDec,peanoDefaultDec(IPstr,DefaultDec),DefaultDecs).
guessDefaults2(s(_),IPstr,DefaultMin,DefaultNMin,DefaultDecs) :-% Peano integer
	append(IPstr,"=s(0)",DefaultMin),
	append(IPstr,"=s(s(_))",DefaultNMin),
	findall(DefaultDec,peanoDefaultDec(IPstr,DefaultDec),DefaultDecs).

listDefaultDec(IPstr,DefaultDec) :-	% X=[HX|TX]
	append(IPstr,"]",Part1),
	append("|T",Part1,Part2),
	append(IPstr,Part2,Part3),
	append("=[H",Part3,Part4),
	append(IPstr,Part4,DefaultDec).

listDefaultDec(IPstr,DefaultDec) :-	% halves(X,TX1,TX2)
	append(IPstr,"2)",Part1),
	append("1,T",Part1,Part2),
	append(IPstr,Part2,Part3),
	append(",T",Part3,Part4),
	append(IPstr,Part4,Part5),
	append("halves(",Part5,DefaultDec).

listDefaultDec(IPstr,DefaultDec) :-	% X=[HX|T] & partition(T,HX,TX1,TX2)
	append(IPstr,"2)",Part1),
	append("1,T",Part1,Part2),
	append(IPstr,Part2,Part3),
	append(",T",Part3,Part4),
	append(IPstr,Part4,Part5),
	append("|T]&partition(T,H",Part5,Part6),
	append(IPstr,Part6,Part7),
	append("=[H",Part7,Part8),
	append(IPstr,Part8,DefaultDec).	

peanoDefaultDec(IPstr,DefaultDec) :-	% X=s(TX) & HX=X
	append("=",IPstr,Part1),
	append(IPstr,Part1,Part2),
	append(")&H",Part2,Part3),
	append(IPstr,Part3,Part4),
	append("=s(T",Part4,Part5),
	append(IPstr,Part5,DefaultDec).
