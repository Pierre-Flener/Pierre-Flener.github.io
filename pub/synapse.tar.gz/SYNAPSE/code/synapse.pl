%******************************************************************************
%*				 synapse.pl				      *
%******************************************************************************

%%% Initializations

:- [library(not)].

:- [step1,step2,step3,step4,step5,step6,step7,
	meta,utilities,primitives,prettyPrint,grammar].

:- dynamic file_search_path/2.
:- multifile file_search_path/2.
file_search_path(specs,'~/Synapse/EPspecs').
file_search_path(scenarios,'~/Synapse/scenarios').

:- dynamic thinkMode/1, autoMode/1.
:- assert(thinkMode(aloud([4],noExp))),
   assert(autoMode(manual)).				% default modes


% +--------------------------------------------------------------------------+
% |   SYNAPSE - SYNthesis of logic Algorithms from PropertieS and Examples   |
% +--------------------------------------------------------------------------+


%%% User commands

i :-							% interactive version
	initMetaVar,
	autoMode(Auto),
	setMode(manual),	% force manual mode
	getSpec(Pred,Params,Exs,Props),
	setMode(Auto),		% restore original mode
	synthesis(Pred,Params,Exs,Props).

s :-							% scenario version
	initMetaVar,
	autoMode(Auto),
	setMode(manual),	% force manual mode
	getSpec(Pred,Params,Exs,Props),
	ask('Scenario',"int-L",ScenarioStr),
	name(Pred,PredStr),
	code('-',Hyphen),
	append(PredStr,[Hyphen|ScenarioStr],ScenarioFileStr),
	name(ScenarioFile,ScenarioFileStr),
	on_exception(_,see(scenarios(ScenarioFile)),fail),!,
	setMode(Auto),		% restore original mode
	synthesis(Pred,Params,Exs,Props),
	seen.

setMode(thinkQuiet) :-
	retractall(thinkMode(aloud(_,_))),
	assert(thinkMode(aloud([],none))).
setMode(thinkAloud(Steps,BothOrOne)) :-
	retractall(thinkMode(aloud(_,_))),
	assert(thinkMode(aloud(Steps,BothOrOne))).
setMode(manual) :-
	retractall(autoMode(_)),
	assert(autoMode(manual)).
setMode(automatic) :-
	retractall(autoMode(_)),
	assert(autoMode(automatic)).


%%% Top level predicates

% getSpec(Pred,Params,Exs,Props)
%	Get a specification whose predicate is Pred, parameters are Params,
%	examples are Exs, and properties are Props.

getSpec(Pred,Params,Exs,Props) :-
	ask('Specification file',"user",SpecFileStr),
	open(SpecFileStr),
	getProcDcl(Pred,Params),
	getExs(Exs),
	getProps(Props),
	seen,!.


% getProcDcl(Pred,Params)
%	Get a procedure declaration involving predicate Pred
%	and parameters Params.

getProcDcl(Pred,Params) :-
	ask('Procedure declaration',"",ProcDclStr),
	myPhrase(proc(Pred,Params),ProcDclStr).


% getExs(Exs)
%	Get examples Exs.
%	Halt when an empty line is read.
%	Integers are stored as Peano-integers.

getExs(Exs) :-
	ask('Example ',"",ExStr),
	handleEx(ExStr,Exs).

handleEx("",[]) :- !.
handleEx(ExStr,[Ex|Exs]) :-
	myPhrase(hornClause(Ex),ExStr),
	getExs(Exs).


% getProps(Props)
%	Get properties Props.
%	Halt when an empty line is read.
%	Integers are stored as Peano-integers.

getProps(Props) :-
	ask('Property',"",PropStr),
	handleProp(PropStr,Props).

handleProp("",[]) :- !.
handleProp(PropStr,[Prop|Props]) :-
	myPhrase(hornClause(Prop),PropStr),
	getProps(Props).


% synthesis(Pred,Params,Exs,Props)
%	Synthesis of a logic algorithm from Pred, Params, Exs, and Props.

synthesis(Pred,Params,Exs,Props) :-

	Variables=variables(Params,_,_,_,_,_,_,_),

	step1(Pred,Exs,Variables,ExpLA1),
	prettyPrint(ExpLA1,1),

	step2(Variables,ExpLA1,ExpLA2,Positions,DefaultDecs),
	prettyPrint(ExpLA2,2),

	step3(Variables,Positions,DefaultDecs,ExpLA2,ExpLA3),
	prettyPrint(ExpLA3,3),

	step4(Exs,Props,Variables,Positions,ExpLA3,ExpLA4),
	prettyPrint(ExpLA4,4),

	step5(ExpLA4,ExpLA5),
	prettyPrint(ExpLA5,5),

	step6(Variables,Positions,ExpLA5,ExpLA6),
	prettyPrint(ExpLA6,6),

	step7(Props,Variables,Positions,ExpLA6,ExpLA7),
	
	gamma(ExpLA7,LA),
	prettyPrintGen(LA,''),

	write('Backtracking...'),nl,
	fail.

synthesis(_,_,_,_) :-
	write('No (more) solutions.'),nl.
