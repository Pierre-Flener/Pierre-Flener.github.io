%******************************************************************************
%*				 step6.pl				      *
%******************************************************************************

% step6(Variables,Positions,LA5,LA6)
%	Synthesis of LA6 from LA5;
%       Variables is the compound term of variables, where
%       the following components are used here:
%               AuxParams are the auxiliary parameters of Params;
%               OtherParams are the other parameters of Params;
%               IPheads are the heads among DecVars;
%               OtherTailss are the tailss of OtherParams;
%	Positions is the compound term of parameter positions, where
%	the following components are used here:
%		PosAuxParams are the positions of AuxParams within Params;
%		PosOtherParams are the positions of OtherParams within Params;
%		PosIPHeads are the positions of IPheads within DecVars.
% MSG Method only.

step6(_,_,LA5,LA6) :-
	LA5=iff(_,or(_,_,undefined,[])),!,
	LA6=LA5.

step6(Variables,Positions,LA5,LA6) :-
        Variables=variables(_,_,_,_,_,_,_,OtherTailss),
	LA5=iff(Head,or(MinCase,NRecCase,RecCase5,[])),
	RecCase5=[and(NMinimal,Decompose,undefined,Recur,undefined,RecEqsss)],
	findall([Partition,MSGs],
		cliques(RecEqsss,OtherTailss,Positions,Partition,MSGs),
		Solutions),
	shortestLists(Solutions,ShoSolutions),
	member(ShoSolutions,[ShoPartition,ShoMSGs]),
	makePCs(ShoMSGs,Variables,ProcComps),
	splitRecCase(ShoPartition,ProcComps,NMinimal,Decompose,Recur,RecCase6),
	LA6=iff(Head,or(MinCase,NRecCase,RecCase6,[])).


% cliques(Eqsss,OtherTailss,Positions,Partition,MSGs)
%	Partition is an admissible partition of list Eqsss into cliques;
%	MSGs are the corresponding most-specific-generalizations.

cliques(Eqsss,OtherTailss,Positions,Partition,MSGs) :-
	cliques(Eqsss,OtherTailss,Positions,Partition,[],MSGs,[]).

cliques([],_,_,Part,Part,MSGs,MSGs).
cliques([Eqss|Eqsss],OtherTailss,Positions,Part,AccPart,MSGs,AccMSGs) :-
	extractHXTYZY(Positions,Eqss,Vals),
	admAlt(Vals,AdmVals),
	AdmVals=val(_,AdmTYvalss,_,_),
	equationss(OtherTailss,AdmTYvalss,AdmEqs4),
	Eqss=[Eqs1,Eqs2,_],
	AdmEqss=[Eqs1,Eqs2,AdmEqs4],
	classification(AccPart,AdmVals,AdmEqss,NewAccPart,AccMSGs,NewAccMSGs),
	cliques(Eqsss,OtherTailss,Positions,Part,NewAccPart,MSGs,NewAccMSGs).


% classification(Part,Vals,Eqss,NewPart,MSGs,NewMSGs)
%	NewPart is partition Part with Eqss added to the clique
%		Vals is compatible with;
%	NewMSGs is the corresponding update of MSGs.
% NB. Is fully deterministic (and should be so).
% NB. Simplified implementation: I here assume that compatibility is
%					an equivalence relation.

classification([],Vals,Eqss,[[Eqss]],[],[Vals]).
classification([HP|TP],Vals,Eqss,[NewHP|TP],[MSG|MSGs],[NewMSG|MSGs]) :-
	compatible(Vals,MSG,NewMSG),!,
	append(HP,[Eqss],NewHP).
classification([HP|TP],Vals,Eqss,[HP|NewTP],[MSG|MSGs],[MSG|NewMSGs]) :-
	classification(TP,Vals,Eqss,NewTP,MSGs,NewMSGs).


% makePCs(MSGs,Variables,ProcComps)
%	ProcComps are Variables=MSGs.

makePCs([],_,[]).
makePCs([val(HXvals,TYvalss,Zvals,Yvals)|MSGs],
			Variables,[ProcComp|ProcComps]) :-
        Variables=variables(_,_,AuxParams,OtherParams,_,IPheads,_,OtherTailss),
	equations(IPheads,HXvals,EqsHX),
	equationss(OtherTailss,TYvalss,EqsTY),
	equations(AuxParams,Zvals,EqsZ),
	equations(OtherParams,Yvals,EqsY),
	append(EqsHX,EqsTY,EqsHXTY),
	append(EqsHXTY,EqsZ,EqsHXTYZ),
	append(EqsHXTYZ,EqsY,EqsHXTYZY),
	simplify(EqsHXTYZY,ProcComp),
	makePCs(MSGs,Variables,ProcComps).


% splitRecCase(Partition,ProcComps,NMinimal,Decompose,Recur,RecCase)
%	RecCase is the new recursive case, built from the discovered sub-cases.

splitRecCase([],[],_,_,_,[]).
splitRecCase([Eqsss|Partition],[ProcComp|ProcComps],NMinimal,Decompose,Recur,
		[SubCase|SubCases]) :-
	SubCase=and(NMinimal,Decompose,undefined,Recur,ProcComp,Eqsss),
	splitRecCase(Partition,ProcComps,NMinimal,Decompose,Recur,SubCases).
