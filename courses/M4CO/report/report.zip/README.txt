README.txt            this file
appendix.tex          useful examples of technical writing with LaTeX; loaded into demoReport.pdf
checklist.pdf         excerpt from Topics 2 & 3, to be used for the Checklist sections of assignment & project reports
demoReport.pdf        showcase of expectation on assignment & project reports
macros.tex            loads useful packages and defines useful new commands; loaded by project-report.tex
mznlisting.tex        prescribes how MiniZinc syntax is typeset and defines \mzninline and \mzninlinebar; loaded by project-report.tex
mzn-python-demo.zip   compression of demo on how to use MiniZinc-Python interface
project-report.tex    template report, to be used for the project
project-report.pdf    compilation of project-report.tex
project-results.tex   loaded by project-report.tex
project-skeleton.mzn  template MiniZinc model, to be used for the project
report.zip            compression of all other files in this folder
