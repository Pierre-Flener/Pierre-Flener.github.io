Download *all* these files into the *same* folder, make a copy of
demo-M4CO.tex for each assignment or the project, and edit each copy
by following the assignment & project guidelines in assignment?.pdf &
https://pierre-flener.github.io/courses/COCP/project, and by following
the instructions given as comments marked with %% within that .tex
file.
