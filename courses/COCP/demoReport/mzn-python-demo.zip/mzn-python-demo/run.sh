#!/bin/bash
module load gurobi
MINIZINC_DIR="/it/kurs/consprog/minizinc"
export PATH=$PATH:$MINIZINC_DIR/MiniZincIDE/bin/
export PYTHONPATH=$PYTHON_PATH:$MINIZINC_DIR/python3.6/site-packages/
SOURCE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
python3 $SOURCE_DIR/app.py "$@"
