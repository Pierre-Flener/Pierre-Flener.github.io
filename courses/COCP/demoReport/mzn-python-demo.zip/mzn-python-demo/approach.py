import minizinc
import os
from pprint import pprint

# The path of the model file:
model_path = os.path.abspath("magicSeries.mzn")

# Load the model:
model = minizinc.Model(model_path)

# Select the solver (backend). Here Gecode.
# This can be changed to any of the other backends (i.e. fzn-oscar-cbls).
backend = minizinc.Solver.lookup("org.gecode.gecode")

# Create an instance of the backend-model pair:
instance = minizinc.Instance(backend, model)

# Supply the instance with problem data:
instance["n"] = 5

# solve the instance and retrieve the results:
result = instance.solve()

# pretty print the result object
pprint(vars(result))

# Output the solution if any:
if result.solution is None:
  print("UNSAT")
else:
  print("SAT\nMagic: " + str(result['Magic']))
