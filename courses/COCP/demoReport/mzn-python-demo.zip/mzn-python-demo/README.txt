This small example shows how to run MiniZinc models via Python.

To run it on a Linux host, type

  bash run.sh

Folder structure:
  * README.txt
    - this file
  * magicSeries.mzn
    - a MiniZinc model for the Magic Series problem
  * approach.py
    - Python code that runs MagicSeries.mzn for n = 5
  * run.sh
    - sets up path variables in order to find MiniZinc and the
      MiniZinc-Python library before running the approach.py script
    - all command-line arguments supplied to run.sh will be passed
      to approach.py

If you have installed MiniZinc and the MiniZinc-Python package on your
own computer, then you should be able to execute approach.py directly
(note that we will not help you with installing Python, Python
packages, MiniZinc, or MiniZinc backends).

To run your own approach of addressing the project you chose, change
approach.py to your liking: change to your models; read command-line
arguments; etc.
