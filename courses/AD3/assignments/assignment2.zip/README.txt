It is recommended to rename assignment1-report.tex into Ti-A2.tex,
where i is your team number.

Edit the .tex files by following their instructions given as comments
that start with '%%'.
